import { EvasaoTurnoData, EvasaoDisciplinaData, RetencaoDisciplinaData, RetencaoTurnoData, RetencaoModalidadeData } from './../models/chart_data_types';
import { SomaEvasao } from './../models/retencao.model';
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";
import { Historico } from "../models/historico.model";
import { EvasaoProfessorData } from '../models/chart_data_types';
import { AlunoDisciplinas } from '../models/aluno_disciplinas.model';

@Injectable({
  providedIn: "root",
})
export class HistoricoService {
  BASE_URL = `${environment.BASE_URL}historico/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  listar(): Observable<Historico[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Historico[]>(url, this.httpOptions);
  }

  buscarPorAnos(id: number | undefined): Observable<string[]> {
    const url = `${this.BASE_URL}?id_curso=${id}&anos`;
    return this.httpClient.get<string[]>(url, this.httpOptions);
  }

  buscarHistoricoPorCurso(id: number | undefined): Observable<Historico[]> {
    const url = `${this.BASE_URL}?id_curso=${id}`;
    return this.httpClient.get<Historico[]>(url, this.httpOptions);
  }

  buscarHistoricosDosAlunos(pageSize: number = 10): Observable<Historico[]> {
    const url = `${this.BASE_URL}${pageSize}/`;
    return this.httpClient.get<Historico[]>(url, this.httpOptions);
  }

  buscarSomaEvasao(id: number): Observable<SomaEvasao[]> {
    const url = `${this.BASE_URL}?id_curso=${id}&soma_evasao`;
    return this.httpClient.get<SomaEvasao[]>(url, this.httpOptions);
  }

  buscaEvasaoProfessor(id: number):Observable<EvasaoProfessorData[]>{
    const url = `${this.BASE_URL}?id_curso=${id}&evasao_professor`;
    return this.httpClient.get<EvasaoProfessorData[]>(url, this.httpOptions);
  }

  buscaEvasaoTurno(id: number):Observable<EvasaoTurnoData[]>{
    const url = `${this.BASE_URL}?id_curso=${id}&evasao_turno`;
    return this.httpClient.get<EvasaoTurnoData[]>(url, this.httpOptions);
  }

  buscaEvasaoDisciplina(id: number):Observable<EvasaoDisciplinaData[]>{
    const url = `${this.BASE_URL}?id_curso=${id}&evasao_disciplina`;
    return this.httpClient.get<EvasaoDisciplinaData[]>(url, this.httpOptions);
  }

  buscaRetencaoDisciplina(id: number):Observable<RetencaoDisciplinaData[]>{
    const url = `${this.BASE_URL}?id_curso=${id}&retencao_disciplina`;
    return this.httpClient.get<RetencaoDisciplinaData[]>(url, this.httpOptions);
  }

  buscaRetencaoTurno(id: number):Observable<RetencaoTurnoData[]>{
    const url = `${this.BASE_URL}?id_curso=${id}&retencao_turno`;
    return this.httpClient.get<RetencaoTurnoData[]>(url, this.httpOptions);
  }

  buscaRetencaoModalidade(id: number):Observable<RetencaoModalidadeData[]>{
    const url = `${this.BASE_URL}?id_curso=${id}&retencao_modalidade`;
    return this.httpClient.get<RetencaoModalidadeData[]>(url, this.httpOptions);
  }

  chi(aluno: string) {
    const url = `${this.BASE_URL}${aluno}/`;
    return this.httpClient.post(url, this.httpOptions);
  }

  remover(id: number | undefined) {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.delete(url, this.httpOptions);
  }

  buscarDisciplinasPorModalidade(idModalidade: number):Observable<AlunoDisciplinas[]>{
    const url = `${this.BASE_URL}?id_modalidade=${idModalidade}`;
    return this.httpClient.get<AlunoDisciplinas[]>(url, this.httpOptions);
  }

  buscarDisciplinasPorAnos(anoIni: number, anoFim: number):Observable<AlunoDisciplinas[]>{
    const url = `${this.BASE_URL}?ano_ini=${anoIni}&ano_fim=${anoFim}`;
    return this.httpClient.get<AlunoDisciplinas[]>(url, this.httpOptions);
  }
}
