import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";
import { Usuario } from "../models/usuario.model";
import { map } from "rxjs/internal/operators/map";


@Injectable({
  providedIn: "root",
})
export class UsuarioService {
  BASE_URL = `${environment.BASE_URL}user/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  cadastrar(usuario: Usuario): Observable<Usuario> {
    const url = this.BASE_URL;
    return this.httpClient.post<Usuario>(url, usuario, this.httpOptions);
  }

  listar(): Observable<Usuario[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Usuario[]>(url, this.httpOptions);
  }

  buscarPorId(id: number): Observable<Usuario> {
    const url = `${this.BASE_URL}?id=${id}`;
    return this.httpClient.get<Usuario>(url, this.httpOptions);
  }

  buscarPorCPF(cpf: string): Observable<Usuario> {
    const url = `${this.BASE_URL}buscar_por_cpf/?cpf=${cpf}`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    return this.httpClient.get<Usuario[]>(url, httpOptions).pipe(
      map(response => response[0])
    );
  }

  enviarEmailNovaSenha(email: string, nova_senha: string): void {
    const url = `${this.BASE_URL}enviar_email/`;
    const payload = { email, nova_senha };
    this.httpClient.post(url, payload).subscribe(
      () => {
        console.log('E-mail enviado com sucesso!');
      },
      (error) => {
        console.error('Erro ao enviar e-mail:', error);
      }
    );
  }

  atualizar(usuario: Usuario): Observable<Usuario> {
    const url = `${this.BASE_URL}${usuario.id}/`;
    return this.httpClient.put<Usuario>(url, usuario, this.httpOptions);
  }

  atualizarCursosDoUsuario(usuario: Usuario): Observable<Usuario> {
    const url = `${this.BASE_URL}${usuario.id}/`;
    return this.httpClient.put<Usuario>(url, usuario, this.httpOptions);
  }

  remover(id: number | undefined) {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.delete(url, this.httpOptions);
  }
}
