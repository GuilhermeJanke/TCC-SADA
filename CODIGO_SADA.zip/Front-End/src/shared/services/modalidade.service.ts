import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";
import { Modalidade } from "../models/modalidade.model";
import {
  AprovadosData,
  ReprovadosData,
  ReprovadosModalidadeData,
} from "../models/chart_data_types";

@Injectable({
  providedIn: "root",
})
export class ModalidadeService {
  BASE_URL = `${environment.BASE_URL}modalidade/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  cadastrar(modalidade: Modalidade): Observable<Modalidade> {
    const url = this.BASE_URL;
    return this.httpClient.post<Modalidade>(url, modalidade, this.httpOptions);
  }

  listar(): Observable<Modalidade[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Modalidade[]>(url, this.httpOptions);
  }

  buscarModalidadePorCurso(id: number | undefined): Observable<Modalidade[]> {
    const url = `${this.BASE_URL}?id_curso=${id}`;
    return this.httpClient.get<Modalidade[]>(url, this.httpOptions);
  }

  buscarAprovadosPorModalidade(id: number): Observable<AprovadosData[]> {
    const url = `${this.BASE_URL}?aprovados&id_curso=${id}`;
    return this.httpClient.get<AprovadosData[]>(url, this.httpOptions);
  }

  buscarAprovadosPorModalidadeData(id: number, anoIni: number, anoFim: number): Observable<AprovadosData[]> {
    const url = `${this.BASE_URL}?aprovados_data&id_curso=${id}&data_inicio=${anoIni}&data_fim=${anoFim}`;
    return this.httpClient.get<AprovadosData[]>(url, this.httpOptions);
  }

  buscarReprovadosPorModalidade(id: number): Observable<ReprovadosModalidadeData> {
    const url = `${this.BASE_URL}?reprovados_modalidade=${id}`;
    return this.httpClient.get<ReprovadosModalidadeData>(url, this.httpOptions);
  }

  buscarReprovados(id: number): Observable<ReprovadosData[]> {
    const url = `${this.BASE_URL}?reprovados&id_curso=${id}`;
    return this.httpClient.get<ReprovadosData[]>(url, this.httpOptions);
  }

  buscarReprovadosData(id: number, anoIni: number, anoFim: number): Observable<ReprovadosData[]> {
    const url = `${this.BASE_URL}?reprovados_data&id_curso=${id}&data_inicio=${anoIni}&data_fim=${anoFim}`;
    return this.httpClient.get<ReprovadosData[]>(url, this.httpOptions);
  }

  atualizar(id: number, modalidade: Modalidade): Observable<Modalidade> {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.put<Modalidade>(url, modalidade, this.httpOptions);
  }

  remover(id: number | undefined) {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.delete(url, this.httpOptions);
  }
}
