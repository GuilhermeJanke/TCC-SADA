import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";
import { Matriz } from "../models/matriz.model";
import { Disciplina } from "../models/disciplina.model";

@Injectable({
  providedIn: "root",
})
export class MatrizService {
  BASE_URL = `${environment.BASE_URL}matriz/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  listar(): Observable<Matriz[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Matriz[]>(url, this.httpOptions);
  }

  buscarPorId(id: number): Observable<Matriz> {
    const url = `${this.BASE_URL}?id=${id}`;
    return this.httpClient.get<Matriz>(url, this.httpOptions);
  }

  buscarMatrizPorCurso(id: number | undefined): Observable<Matriz[]> {
    const url = `${this.BASE_URL}?id_curso=${id}`;
    return this.httpClient.get<Matriz[]>(url, this.httpOptions);
  }

  buscarDisciplinasDaMatriz(id: number): Observable<Disciplina[]> {
    const url = `${this.BASE_URL}/${id}/disciplinas`;
    return this.httpClient.get<Disciplina[]>(url, this.httpOptions);
  }

  atualizar(id: number, matriz: Matriz): Observable<Matriz> {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.put<Matriz>(url, matriz, this.httpOptions);
  }

  remover(id: number | undefined) {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.delete(url, this.httpOptions);
  }
}
