import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";
import { Aluno } from "../models/aluno.model";
import { Horas, IntegralizacaoData } from "../models/chart_data_types";

@Injectable({
  providedIn: "root",
})
export class AlunoService {
  BASE_URL = `${environment.BASE_URL}aluno/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  listarAlunos(): Observable<Aluno[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Aluno[]>(url, this.httpOptions);
  }

  buscarPorId(id: number | undefined): Observable<Aluno> {
    const url = `${this.BASE_URL}?id=${id}`;
    return this.httpClient.get<Aluno>(url, this.httpOptions);
  }

  buscarPorHoras(id: number | undefined): Observable<Horas> {
    const url = `${this.BASE_URL}?id=${id}&horas`;
    return this.httpClient.get<Horas>(url, this.httpOptions);
  }

  buscarPorIdCurso(id: number | undefined): Observable<Aluno[]> {
    const url = `${this.BASE_URL}?id_curso=${id}`;
    return this.httpClient.get<Aluno[]>(url, this.httpOptions);
  }

  buscarIntegralizacao(
    id: number | undefined
  ): Observable<IntegralizacaoData[]> {
    const url = `${this.BASE_URL}?id_curso=${id}&integralizar`;
    return this.httpClient.get<IntegralizacaoData[]>(url, this.httpOptions);
  }

  remover(id: number | undefined) {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.delete(url, this.httpOptions);
  }
}
