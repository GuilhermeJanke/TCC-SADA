import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";
import { Turma } from "../models/turma.model";
import { Porcentagens, Quartis } from "../models/chart_data_types";

@Injectable({
  providedIn: "root",
})
export class TurmaService {
  BASE_URL = `${environment.BASE_URL}turma/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  listar(): Observable<Turma[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Turma[]>(url, this.httpOptions);
  }

  buscarTurmaPorCurso(id: number | undefined): Observable<Turma[]> {
    const url = `${this.BASE_URL}?id_curso=${id}`;
    return this.httpClient.get<Turma[]>(url, this.httpOptions);
  }

  buscarPorTurnos(id: number | undefined): Observable<string[]> {
    const url = `${this.BASE_URL}?id_curso=${id}&turnos`;
    return this.httpClient.get<string[]>(url, this.httpOptions);
  }

  buscarPorcentagens(
      selectedTurma,
      selectedDisciplina,
      selectedTurno,
      selectedAno,
      selectedProfessor
    ): Observable<Porcentagens> {
    const url = `${this.BASE_URL}?selectedTurma=${selectedTurma}&selectedDisciplina=${selectedDisciplina}&selectedTurno=${selectedTurno}&selectedAno=${selectedAno}&selectedProfessor=${selectedProfessor}`;
    return this.httpClient.get<Porcentagens>(url, this.httpOptions);
  }

  buscarQuartis(
    selectedTurma,
    selectedDisciplina,
    selectedTurno,
    selectedAno,
    selectedProfessor
  ): Observable<Quartis> {
    const url = `${this.BASE_URL}?selectedTurma=${selectedTurma}&selectedDisciplina=${selectedDisciplina}&selectedTurno=${selectedTurno}&selectedAno=${selectedAno}&selectedProfessor=${selectedProfessor}&quartil`;
    return this.httpClient.get<Quartis>(url, this.httpOptions);
  }

  buscarPorcentagensModalidade(
    selectedTurma,
    selectedModalidade,
    selectedTurno,
    selectedAno,
    selectedProfessor
  ): Observable<Porcentagens> {
    const url = `${this.BASE_URL}?selectedTurma=${selectedTurma}&selectedModalidade=${selectedModalidade}&selectedTurno=${selectedTurno}&selectedAno=${selectedAno}&selectedProfessor=${selectedProfessor}`;
    return this.httpClient.get<Porcentagens>(url, this.httpOptions);
  }

  buscarQuartisModalidade(
    selectedTurma,
    selectedModalidade,
    selectedTurno,
    selectedAno,
    selectedProfessor
  ): Observable<Quartis> {
    const url = `${this.BASE_URL}?selectedTurma=${selectedTurma}&selectedModalidade=${selectedModalidade}&selectedTurno=${selectedTurno}&selectedAno=${selectedAno}&selectedProfessor=${selectedProfessor}&quartil`;
    return this.httpClient.get<Quartis>(url, this.httpOptions);
  }

  remover(id: number | undefined) {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.delete(url, this.httpOptions);
  }
}
