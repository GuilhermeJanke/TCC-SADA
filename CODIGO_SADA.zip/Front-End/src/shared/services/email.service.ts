const nodemailer = require('nodemailer');

function enviarEmailNovaSenha(email, novaSenha) {
  const transporter = nodemailer.createTransport({
    service: 'seu_provedor_de_email',
    auth: {
      user: 'seu_email',
      pass: 'sua_senha'
    }
  });

  const mailOptions = {
    from: 'seu_email',
    to: email,
    subject: 'Nova Senha',
    text: `Sua nova senha é: ${novaSenha}`
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error('Erro ao enviar o email:', error);
    } else {
      console.log('Email enviado:', info.response);
    }
  });
}

module.exports = {
  enviarEmailNovaSenha
};
