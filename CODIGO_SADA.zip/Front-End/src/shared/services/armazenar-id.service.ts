import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class ArmazenarIdService {
  private readonly CURSO_KEY = "id_curso";

  getCursoID(): string {
    return localStorage.getItem(this.CURSO_KEY);
  }

  setCursoID(id: string): void {
    localStorage.setItem(this.CURSO_KEY, id);
  }

  deleteCursoID(): void {
    localStorage.removeItem(this.CURSO_KEY);
  }
}


