import { EvasaoTurnoData, EvasaoDisciplinaData, RetencaoDisciplinaData, RetencaoTurnoData, RetencaoModalidadeData, Horas } from './../models/chart_data_types';
import { HistoricoService } from './historico.service';
import { Injectable } from "@angular/core";
import { ModalidadeService } from "./modalidade.service";
import { AlunoService } from "./aluno.service";
import { ArmazenarIdService } from "./armazenar-id.service";
import {
  AprovadosData,
  ReprovadosModalidadeData,
  ReprovadosData,
  IntegralizacaoData,
  EvasaoProfessorData
} from "../models/chart_data_types";
import * as Chart from "chart.js";
import { Aluno } from '../models';

@Injectable({
  providedIn: "root",
})
export class ChartService {

  id_curso = parseInt(this.armazenarIdService.getCursoID());
  chartInstance: Chart;
  chart11: Chart;
  chart12: Chart;

  constructor(
    private modalidadeService: ModalidadeService,
    private alunoService: AlunoService,
    private armazenarIdService: ArmazenarIdService,
    private historicoService: HistoricoService
  ) { }

  chartIntegralizacao(chart: HTMLCanvasElement) {
    this.alunoService.buscarIntegralizacao(this.id_curso).subscribe({
      next: (lista: IntegralizacaoData[]) => {
        new Chart(chart, {
          type: "scatter",
          data: {
            datasets: [
              {
                data: lista,
                backgroundColor: "rgba(54, 162, 235, 0.6)",
              },
            ],
          },
          options: {
            legend: { display: false },
            responsive: true,
            scales: {
              xAxes: [
                {
                  ticks: {
                    callback: function (value, index, values) {
                      if (Number.isInteger(value)) {
                        return "Período " + value;
                      }
                      return '';
                    },
                  },
                },
              ],
              yAxes: [
                {
                  stacked: true,
                  ticks: {
                    callback: function (value) {
                      return value + "h";
                    },
                  },
                },
              ],
            },
          },
        });
      },
    });
  }

  chartReprovadosPorModalidade(id: number, chart2: HTMLCanvasElement) {
    if (this.chartInstance != undefined || this.chartInstance != null) {
      this.chartInstance.destroy();
    }

    this.modalidadeService.buscarReprovadosPorModalidade(id).subscribe({
      next: (res: ReprovadosModalidadeData) => {
        let rf = (res[0].reprovados_frequencia / res[0].total_alunos) * 100;
        let rn = (res[0].reprovados_nota / res[0].total_alunos) * 100;

        const xValues = ["Reprovados Por Frequência", "Reprovados Por Nota"];
        const yValues = [rf, rn];
        const barColors = [
          "rgba(255, 206, 86, 0.6)",
          "rgba(54, 162, 235, 0.6)",
        ];

        this.chartInstance = new Chart(chart2, {
          type: "bar",
          data: {
            labels: xValues,
            datasets: [
              {
                backgroundColor: barColors,
                data: yValues,
              },
            ],
          },
          options: {
            legend: { display: false },
            responsive: true,
            scales: {
              yAxes: [
                {
                  stacked: true,
                  ticks: {
                    callback: function (value) {
                      return value + "%";
                    },
                  },
                },
              ],
            },
          },
        });
      },
    });
  }

  chartReprovados(chart3: HTMLCanvasElement) {
    if (this.chartInstance != undefined || this.chartInstance != null) {
      this.chartInstance.destroy();
    }

    this.modalidadeService.buscarReprovados(this.id_curso).subscribe({
      next: (lista: ReprovadosData[]) => {
        const data = lista.map((item) => {
          let ap = (item.reprovados / item.total_alunos) * 100;

          const red = Math.floor(Math.random() * 256);
          const green = Math.floor(Math.random() * 256);
          const blue = Math.floor(Math.random() * 256);

          return {
            xValues: item.modalidade,
            yValues: [ap],
            barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
          };
        });

        const { xValues, barColors, yValues } = data.reduce(
          (acc, curr) => ({
            xValues: [...acc.xValues, curr.xValues],
            barColors: [...acc.barColors, curr.barColors],
            yValues: [...acc.yValues, ...curr.yValues],
          }),
          { xValues: [], barColors: [], yValues: [] }
        );

        this.chartInstance = new Chart(chart3, {
          type: "bar",
          data: {
            labels: xValues,
            datasets: [
              {
                backgroundColor: barColors,
                data: yValues,
              },
            ],
          },
          options: {
            legend: { display: false },
            responsive: true,
            scales: {
              yAxes: [
                {
                  stacked: true,
                  ticks: {
                    callback: function (value) {
                      return value + "%";
                    },
                  },
                },
              ],
            },
          },
        });
      },
    });
  }

  chartReprovadosData(chart3: HTMLCanvasElement, anoIni: number, anoFim: number) {
    if (this.chartInstance != undefined || this.chartInstance != null) {
      this.chartInstance.destroy();
    }

    this.modalidadeService.buscarReprovadosData(this.id_curso, anoIni, anoFim).subscribe({
      next: (lista: ReprovadosData[]) => {
        const data = lista.map((item) => {
          let ap = (item.reprovados / item.total_alunos) * 100;

          const red = Math.floor(Math.random() * 256);
          const green = Math.floor(Math.random() * 256);
          const blue = Math.floor(Math.random() * 256);

          return {
            xValues: item.modalidade,
            yValues: [ap],
            barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
          };
        });

        const { xValues, barColors, yValues } = data.reduce(
          (acc, curr) => ({
            xValues: [...acc.xValues, curr.xValues],
            barColors: [...acc.barColors, curr.barColors],
            yValues: [...acc.yValues, ...curr.yValues],
          }),
          { xValues: [], barColors: [], yValues: [] }
        );

        this.chartInstance = new Chart(chart3, {
          type: "bar",
          data: {
            labels: xValues,
            datasets: [
              {
                backgroundColor: barColors,
                data: yValues,
              },
            ],
          },
          options: {
            legend: { display: false },
            responsive: true,
            scales: {
              yAxes: [
                {
                  stacked: true,
                  ticks: {
                    callback: function (value) {
                      return value + "%";
                    },
                  },
                },
              ],
            },
          },
        });
      },
    });
  }

  chartAprovadosPorModalidade(chart4: HTMLCanvasElement) {
    if (this.chartInstance != undefined || this.chartInstance != null) {
      this.chartInstance.destroy();
    }

    this.modalidadeService.buscarAprovadosPorModalidade(this.id_curso).subscribe({
      next: (lista: AprovadosData[]) => {
        const data = lista.map((item) => {
          let ap = (item.aprovados / item.total_alunos) * 100;

          const red = Math.floor(Math.random() * 256);
          const green = Math.floor(Math.random() * 256);
          const blue = Math.floor(Math.random() * 256);

          return {
            xValues: item.modalidade,
            yValues: [ap],
            barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
          };
        });

        const { xValues, barColors, yValues } = data.reduce(
          (acc, curr) => ({
            xValues: [...acc.xValues, curr.xValues],
            barColors: [...acc.barColors, curr.barColors],
            yValues: [...acc.yValues, ...curr.yValues],
          }),
          { xValues: [], barColors: [], yValues: [] }
        );

        this.chartInstance = new Chart(chart4, {
          type: "bar",
          data: {
            labels: xValues,
            datasets: [
              {
                backgroundColor: barColors,
                data: yValues,
              },
            ],
          },
          options: {
            legend: { display: false },
            responsive: true,
            scales: {
              yAxes: [
                {
                  stacked: true,
                  ticks: {
                    callback: function (value) {
                      return value + "%";
                    },
                  },
                },
              ],
            },
          },
        });
      },
    });
  }

  chartAprovadosPorModalidadeData(chart4: HTMLCanvasElement, anoIni: number, anoFim: number) {
    if (this.chartInstance != undefined || this.chartInstance != null) {
      this.chartInstance.destroy();
    }

    this.modalidadeService.buscarAprovadosPorModalidadeData(this.id_curso, anoIni, anoFim).subscribe({
      next: (lista: AprovadosData[]) => {
        const data = lista.map((item) => {
          let ap = (item.aprovados / item.total_alunos) * 100;

          const red = Math.floor(Math.random() * 256);
          const green = Math.floor(Math.random() * 256);
          const blue = Math.floor(Math.random() * 256);

          return {
            xValues: item.modalidade,
            yValues: [ap],
            barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
          };
        });

        const { xValues, barColors, yValues } = data.reduce(
          (acc, curr) => ({
            xValues: [...acc.xValues, curr.xValues],
            barColors: [...acc.barColors, curr.barColors],
            yValues: [...acc.yValues, ...curr.yValues],
          }),
          { xValues: [], barColors: [], yValues: [] }
        );

        this.chartInstance = new Chart(chart4, {
          type: "bar",
          data: {
            labels: xValues,
            datasets: [
              {
                backgroundColor: barColors,
                data: yValues,
              },
            ],
          },
          options: {
            legend: { display: false },
            responsive: true,
            scales: {
              yAxes: [
                {
                  stacked: true,
                  ticks: {
                    callback: function (value) {
                      return value + "%";
                    },
                  },
                },
              ],
            },
          },
        });
      },
    });
  }

  chartEvasaoProfessor(chart5: HTMLCanvasElement) {
    this.historicoService.buscaEvasaoProfessor(this.id_curso)
      .subscribe({
        next: (lista: EvasaoProfessorData[]) => {
          const data = lista.map((item) => {
            const red = Math.floor(Math.random() * 256);
            const green = Math.floor(Math.random() * 256);
            const blue = Math.floor(Math.random() * 256);

            return {
              xValues: item.professor,
              yValues: [item.ocorrencias],
              barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
            };
          });

          const { xValues, barColors, yValues } = data.reduce(
            (acc, curr) => ({
              xValues: [...acc.xValues, curr.xValues],
              barColors: [...acc.barColors, curr.barColors],
              yValues: [...acc.yValues, ...curr.yValues],
            }),
            { xValues: [], barColors: [], yValues: [] }
          );

          new Chart(chart5, {
            type: "bar",
            data: {
              labels: xValues,
              datasets: [
                {
                  backgroundColor: barColors,
                  data: yValues,
                },
              ],
            },
            options: {
              legend: { display: false },
              responsive: true,
              scales: {
                yAxes: [
                  {
                    stacked: true,
                  },
                ],
              },
            },
          });
        },
      });
  }

  chartEvasaoTurno(chart6: HTMLCanvasElement) {
    this.historicoService.buscaEvasaoTurno(this.id_curso)
      .subscribe({
        next: (lista: EvasaoTurnoData[]) => {
          const data = lista.map((item) => {
            const red = Math.floor(Math.random() * 256);
            const green = Math.floor(Math.random() * 256);
            const blue = Math.floor(Math.random() * 256);

            return {
              xValues: item.turno,
              yValues: [item.ocorrencias],
              barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
            };
          });

          const { xValues, barColors, yValues } = data.reduce(
            (acc, curr) => ({
              xValues: [...acc.xValues, curr.xValues],
              barColors: [...acc.barColors, curr.barColors],
              yValues: [...acc.yValues, ...curr.yValues],
            }),
            { xValues: [], barColors: [], yValues: [] }
          );

          new Chart(chart6, {
            type: "bar",
            data: {
              labels: xValues,
              datasets: [
                {
                  backgroundColor: barColors,
                  data: yValues,
                },
              ],
            },
            options: {
              legend: { display: false },
              responsive: true,
              scales: {
                yAxes: [
                  {
                    stacked: true,
                  },
                ],
              },
            },
          });
        },
      });
  }

  chartEvasaoDisciplina(chart6: HTMLCanvasElement) {
    this.historicoService.buscaEvasaoDisciplina(this.id_curso)
      .subscribe({
        next: (lista: EvasaoDisciplinaData[]) => {
          const data = lista.map((item) => {
            const red = Math.floor(Math.random() * 256);
            const green = Math.floor(Math.random() * 256);
            const blue = Math.floor(Math.random() * 256);

            return {
              xValues: item.disciplina,
              yValues: [item.ocorrencias],
              barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
            };
          });

          const { xValues, barColors, yValues } = data.reduce(
            (acc, curr) => ({
              xValues: [...acc.xValues, curr.xValues],
              barColors: [...acc.barColors, curr.barColors],
              yValues: [...acc.yValues, ...curr.yValues],
            }),
            { xValues: [], barColors: [], yValues: [] }
          );

          new Chart(chart6, {
            type: "bar",
            data: {
              labels: xValues,
              datasets: [
                {
                  backgroundColor: barColors,
                  data: yValues,
                },
              ],
            },
            options: {
              legend: { display: false },
              responsive: true,
              scales: {
                yAxes: [
                  {
                    stacked: true,
                  },
                ],
              },
            },
          });
        },
      });
  }

  chartRetencaoDisciplina(chart6: HTMLCanvasElement) {
    this.historicoService.buscaRetencaoDisciplina(this.id_curso)
      .subscribe({
        next: (lista: RetencaoDisciplinaData[]) => {
          // Ordenar a lista pelo campo "quantidade"
          lista.sort((a, b) => b.quantidade - a.quantidade);

          const data = lista.map((item) => {
            const red = Math.floor(Math.random() * 256);
            const green = Math.floor(Math.random() * 256);
            const blue = Math.floor(Math.random() * 256);

            return {
              xValues: item.disciplina,
              yValues: [item.quantidade],
              barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
            };
          });

          const { xValues, barColors, yValues } = data.reduce(
            (acc, curr) => ({
              xValues: [...acc.xValues, curr.xValues],
              barColors: [...acc.barColors, curr.barColors],
              yValues: [...acc.yValues, ...curr.yValues],
            }),
            { xValues: [], barColors: [], yValues: [] }
          );

          new Chart(chart6, {
            type: "bar",
            data: {
              labels: xValues,
              datasets: [
                {
                  backgroundColor: barColors,
                  data: yValues,
                },
              ],
            },
            options: {
              legend: { display: false },
              responsive: true,
              scales: {
                yAxes: [
                  {
                    stacked: true,
                  },
                ],
              },
            },
          });
        },
      });
  }

  chartRetencaoTurno(chart6: HTMLCanvasElement) {
    this.historicoService.buscaRetencaoTurno(this.id_curso)
      .subscribe({
        next: (lista: RetencaoTurnoData[]) => {
          lista.sort((a, b) => b.quantidade - a.quantidade);
          const data = lista.map((item) => {
            const red = Math.floor(Math.random() * 256);
            const green = Math.floor(Math.random() * 256);
            const blue = Math.floor(Math.random() * 256);

            return {
              xValues: item.turno,
              yValues: [item.quantidade],
              barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
            };
          });

          const { xValues, barColors, yValues } = data.reduce(
            (acc, curr) => ({
              xValues: [...acc.xValues, curr.xValues],
              barColors: [...acc.barColors, curr.barColors],
              yValues: [...acc.yValues, ...curr.yValues],
            }),
            { xValues: [], barColors: [], yValues: [] }
          );

          new Chart(chart6, {
            type: "bar",
            data: {
              labels: xValues,
              datasets: [
                {
                  backgroundColor: barColors,
                  data: yValues,
                },
              ],
            },
            options: {
              legend: { display: false },
              responsive: true,
              scales: {
                yAxes: [
                  {
                    stacked: true,
                  },
                ],
              },
            },
          });
        },
      });
  }

  chartRetencaoModalidade(chart10: HTMLCanvasElement) {
    this.historicoService.buscaRetencaoModalidade(this.id_curso)
      .subscribe({
        next: (lista: RetencaoModalidadeData[]) => {
          lista.sort((a, b) => b.quantidade - a.quantidade);
          const data = lista.map((item) => {
            const red = Math.floor(Math.random() * 256);
            const green = Math.floor(Math.random() * 256);
            const blue = Math.floor(Math.random() * 256);

            return {
              xValues: item.modalidade,
              yValues: [item.quantidade],
              barColors: `rgba(${red}, ${green}, ${blue}, 0.6)`,
            };
          });

          const { xValues, barColors, yValues } = data.reduce(
            (acc, curr) => ({
              xValues: [...acc.xValues, curr.xValues],
              barColors: [...acc.barColors, curr.barColors],
              yValues: [...acc.yValues, ...curr.yValues],
            }),
            { xValues: [], barColors: [], yValues: [] }
          );

          new Chart(chart10, {
            type: "bar",
            data: {
              labels: xValues,
              datasets: [
                {
                  backgroundColor: barColors,
                  data: yValues,
                },
              ],
            },
            options: {
              legend: { display: false },
              responsive: true,
              scales: {
                yAxes: [
                  {
                    stacked: true,
                  },
                ],
              },
            },
          });
        },
      });
  }

  chartQuartil(chart: HTMLCanvasElement, data) {
    if (this.chart11) {
      this.chart11.destroy();
    }

    let xValues = Object.keys(data)
    let yValues = (Object as any).values(data)
    let barColors = [
      '#f8b195',
      '#f67280',
      '#c06c84',
      '#6c5b7b'
    ]

    this.chart11 = new Chart(chart, {
      type: "bar",
      data: {
        labels: xValues,
        datasets: [
          {
            backgroundColor: barColors,
            data: yValues,
          },
        ],
      },
      options: {
        legend: { display: false },
        responsive: true,
        scales: {
          yAxes: [
            {
              stacked: true,
            },
          ],
        },
      },
    });
  }

  chartPorcentagemDesempenho(chart: HTMLCanvasElement, data) {
    if (this.chart12) {
      this.chart12.destroy();
    }

    let xValues = Object.keys(data)
    let yValues = (Object as any).values(data)
    let barColors = [
      'rgba(75, 192, 255)',
      'rgba(255, 99, 99)',
      'rgba(255, 89, 52)',
      'rgba(255, 159, 64)'
    ]

    this.chart12 = new Chart(chart, {
      type: "bar",
      data: {
        labels: xValues,
        datasets: [
          {
            backgroundColor: barColors,
            data: yValues,
          },
        ],
      },
      options: {
        legend: { display: false },
        responsive: true,
        scales: {
          yAxes: [
            {
              stacked: true,
            },
          ],
        },
      },
    });
  }

  chartAprovacaoNaturezaDisciplina(chart: HTMLCanvasElement, id_aluno) {
    this.alunoService.buscarPorHoras(id_aluno)
      .subscribe({
        next: (data: Horas) => {
          let xValues = ["Obrigatória", "Optativa"]
          let yValues = (Object as any).values(data)
          let barColors = [
            'rgba(75, 192, 255)',
            'rgba(255, 159, 64)'
          ]

          this.chart12 = new Chart(chart, {
            type: "bar",
            data: {
              labels: xValues,
              datasets: [
                {
                  backgroundColor: barColors,
                  data: yValues,
                },
              ],
            },
            options: {
              legend: { display: false },
              responsive: true,
              scales: {
                yAxes: [
                  {
                    stacked: true,
                    ticks: {
                      callback: function (value) {
                        return value + "%";
                      },
                    },
                  },
                ],
              },
            },
          });
        },
      });
  }

  chartAprovacaoReprovacaoCancelamento(chart: HTMLCanvasElement, aluno: Aluno) {
    let xValues = [
      "Aprovações",
      "Reprovações Por Nota",
      "Reprovações Por Frequência",
      "Cancelamentos"
    ]
    let yValues = [
      aluno.total_disciplinas_aprovadas,
      aluno.total_disciplinas_repovada_nota,
      aluno.total_disciplinas_repovada_freq,
      aluno.total_disciplinas_canceladas
    ]
    let barColors = [
      'rgba(75, 192, 255)',
      'rgba(255, 159, 64)',
      'rgba(255, 89, 52)',
      'rgba(255, 159, 64)'
    ]

    this.chart12 = new Chart(chart, {
      type: "bar",
      data: {
        labels: xValues,
        datasets: [
          {
            backgroundColor: barColors,
            data: yValues,
          },
        ],
      },
      options: {
        legend: { display: false },
        responsive: true,
        scales: {
          yAxes: [
            {
              stacked: true,
              ticks: {
                callback: function (value) {
                  return value + "%";
                },
              },
            },
          ],
        },
      },
    });
  }
}
