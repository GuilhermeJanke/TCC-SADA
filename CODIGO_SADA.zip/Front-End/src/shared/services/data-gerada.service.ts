import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataGeradaService {

  data_atual:string;
  constructor() { }

  getDataAtualEsemestre() {
    const data = new Date();
    const ano = data.getFullYear();
    const mes = data.getMonth() + 1;
    let semestre = "";

    if (mes <= 6) {
      semestre = "1";
    } else {
      semestre = "2";
    }
    this.data_atual = `${ano}.${semestre}`;
    return this.data_atual;
  }
}
