import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Usuario } from "../../shared/models/usuario.model";
import { Login } from "../../shared/models/login.model";
import { LoginResponse } from "../models/login-response.model";
import { environment } from "../../environments/environment";

const LS_CHAVE: string = "usuarioLogado";
const LS_CHAVE_TOKEN: string = "usuarioLogadoToken";

@Injectable({
  providedIn: "root",
})
export class LoginService {
  BASE_URL: string = environment.BASE_URL + "token";

  constructor(private httpClient: HttpClient) {}

  public get usuarioLogado(): Usuario {
    let usu = localStorage[LS_CHAVE];
    return usu ? JSON.parse(localStorage[LS_CHAVE]) : null;
  }
  public set usuarioLogado(usuario: Usuario) {
    localStorage[LS_CHAVE] = JSON.stringify(usuario);
  }

  public get userToken(): string {
    let token = localStorage[LS_CHAVE_TOKEN];
    return token;
  }

  public set userToken(token: string) {
    localStorage[LS_CHAVE_TOKEN] = token.trim();
  }

  logout() {
    delete localStorage[LS_CHAVE];
    delete localStorage[LS_CHAVE_TOKEN];
  }

  login(login: Login): Observable<LoginResponse> {
    return this.httpClient.post<LoginResponse>(this.BASE_URL, {
      username: login.login,
      password: login.senha,
    });
  }
}
