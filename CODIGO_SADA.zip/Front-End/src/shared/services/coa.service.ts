import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { LoginService } from './login.service';
import { Observable, forkJoin } from 'rxjs';
import { Aluno, AtendimentoCoa } from '../models';
import { switchMap, map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class CoaService {
  BASE_URL = `${environment.BASE_URL}atendimento/`;
  BASE_URL_ALUNO = `${environment.BASE_URL}aluno/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  cadastrar(coa: AtendimentoCoa, anexos: File[]): Observable<AtendimentoCoa> {
    const url = this.BASE_URL;
    const formData = new FormData();

    // Adicione os dados do formulário ao FormData
    formData.append("descricao", coa.descricao);
    formData.append("data_atendimento", coa.data_atendimento.toString());
    formData.append("aluno", coa.aluno.id.toString());

    for (const professor of coa.professor) {
      formData.append("professor", professor.id.toString());
    }

    formData.append("situacao", coa.situacao.toString());

    // Adicione os anexos ao FormData
    for (let i = 0; i < anexos.length; i++) {
      formData.append('anexo', anexos[i]);
    }

    return this.httpClient.post<AtendimentoCoa>(url, formData, this.httpOptions);
  }

  listar(): Observable<AtendimentoCoa[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<AtendimentoCoa[]>(url, this.httpOptions);
  }

  listarAtendimentos(): Observable<AtendimentoCoa[]> {
    const url = `${this.BASE_URL}`;
    return this.httpClient.get<AtendimentoCoa[]>(url, this.httpOptions).pipe(
      switchMap((atendimentos: AtendimentoCoa[]) => {
        const alunoObservables = atendimentos.map((atendimento: AtendimentoCoa) =>
          this.httpClient.get<Aluno>(`${this.BASE_URL_ALUNO}${atendimento.aluno}/`)
        );
        return forkJoin(alunoObservables).pipe(
          map((alunos: Aluno[]) => {
            atendimentos.forEach((atendimento: AtendimentoCoa, index: number) => {
              atendimento.aluno = alunos[index];
            });
            return atendimentos;
          })
        );
      })
    );
  }



  atualizarSituacao(atendimentoId: number): Observable<AtendimentoCoa> {
    const url = `${this.BASE_URL}${atendimentoId}/`;

    // Crie um novo objeto FormData
    const formData = new FormData();
    // Adicione o campo 'situacao' ao FormData
    formData.append('situacao', 'false');

    return this.httpClient.patch<AtendimentoCoa>(url, formData, this.httpOptions);
  }


  remover(id: number | undefined): Observable<any> {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.delete(url, this.httpOptions);
  }

  buscarIntegralizacao(
    id: number | undefined
  ): Observable<any> {
    const url = `${this.BASE_URL}?aluno_id=${id}`;
    return this.httpClient.get<any>(url, this.httpOptions);
  }
}
