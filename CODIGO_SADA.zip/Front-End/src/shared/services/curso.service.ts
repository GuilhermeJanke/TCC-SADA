import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";
import { Curso } from "../models/curso.model";

@Injectable({
  providedIn: "root",
})
export class CursoService {
  BASE_URL = `${environment.BASE_URL}curso/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  cadastrar(curso: Curso): Observable<Curso> {
    const url = this.BASE_URL;
    return this.httpClient.post<Curso>(url, curso, this.httpOptions);
  }

  listar(): Observable<Curso[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Curso[]>(url, this.httpOptions);
  }

  buscarPorNome(cursoNome: string): Observable<Curso[]> {
    const url = `${this.BASE_URL}/?nome=${cursoNome}`;
    return this.httpClient.get<Curso[]>(url, this.httpOptions);
  }

  buscarPorId(id_curso: number): Observable<Curso> {
    const url = `${this.BASE_URL}?id=${id_curso}`;
    return this.httpClient.get<Curso>(url, this.httpOptions);
  }

  atualizar(curso: Curso): Observable<Curso> {
    const url = `${this.BASE_URL}${curso.id}/`;
    return this.httpClient.put<Curso>(url, curso, this.httpOptions);
  }

  remover(id: number | undefined) {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.delete(url, this.httpOptions);
  }
}
