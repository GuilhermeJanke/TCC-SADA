import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpRequest } from "@angular/common/http";
import { LoginService } from "./login.service";

@Injectable({
  providedIn: "root",
})
export class UploadFileService {
  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  upload(files: Set<File>, url: string) {
    const formData = new FormData();
    files.forEach((file) => formData.append("file", file, file.name));

    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: `Bearer ${this.loginService.userToken}`,
      }),
    };

    return this.httpClient.post(url, formData, {
      ...httpOptions,
      observe: "events",
      reportProgress: true,
    });
  }
}
