import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";
import { Disciplina } from "../models/disciplina.model";

@Injectable({
  providedIn: "root",
})
export class DisciplinaService {
  BASE_URL = `${environment.BASE_URL}disciplina/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  listar(): Observable<Disciplina[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Disciplina[]>(url, this.httpOptions);
  }

  buscarPorIdCurso(id_curso: number): Observable<Disciplina[]> {
    const url = `${this.BASE_URL}?id_curso=${id_curso}`;
    return this.httpClient.get<Disciplina[]>(url, this.httpOptions);
  }

  buscarDisciplinaMatriz(matrizId: number): Observable<Disciplina[]> {
    const url = `${this.BASE_URL}?matriz=${matrizId}`;
    return this.httpClient.get<Disciplina[]>(url, this.httpOptions);
  }

  buscarDisciplinaMatrizModalidade(
    matrizId: number,
    modalidadeId: number | null
  ): Observable<Disciplina[]> {
    let url: string;

    modalidadeId
      ? (url = `${this.BASE_URL}?matriz=${matrizId}&modalidade=${modalidadeId}`)
      : (url = `${this.BASE_URL}?matriz=${matrizId}&modalidade=null`);

    return this.httpClient.get<Disciplina[]>(url, this.httpOptions);
  }

  atualizar(id: number, disciplina: Disciplina): Observable<Disciplina> {
    const url = `${this.BASE_URL}${id}/`;
    return this.httpClient.put<Disciplina>(url, disciplina, this.httpOptions);
  }
}
