import { Professor } from './../models/professor.model';
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { LoginService } from "./login.service";
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class ProfessorService {
  BASE_URL = `${environment.BASE_URL}professor/`;

  constructor(
    private httpClient: HttpClient,
    private loginService: LoginService
  ) {}

  httpOptions = {
    headers: new HttpHeaders({
      Authorization: `Bearer ${this.loginService.userToken}`,
    }),
  };

  listar(): Observable<Professor[]> {
    const url = this.BASE_URL;
    return this.httpClient.get<Professor[]>(url, this.httpOptions);
  }

  buscarPorIdCurso(id_curso: number): Observable<Professor[]> {
    const url = `${this.BASE_URL}?id_curso=${id_curso}`;
    return this.httpClient.get<Professor[]>(url, this.httpOptions);
  }
}
