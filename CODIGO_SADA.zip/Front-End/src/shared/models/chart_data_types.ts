export interface AprovadosData {
  modalidade: string;
  aprovados: number;
  total_alunos: number;
}
export interface ReprovadosModalidadeData {
  reprovados_frequencia: number;
  reprovados_nota: number;
  total_alunos: number;
}

export interface ReprovadosData {
  modalidade: string;
  reprovados: number;
  total_alunos: number;
}

export interface IntegralizacaoData {
  x: number;
  y: number;
  grr:string;
}

export interface EvasaoProfessorData {
  professor: string;
  ocorrencias: number;
}

export interface EvasaoTurnoData {
  turno: string;
  ocorrencias: number;
}

export interface EvasaoDisciplinaData{
  disciplina: string;
  ocorrencias: number;
}

export interface RetencaoTurnoData{
  turno: string;
  quantidade: number;
}

export interface RetencaoDisciplinaData{
  disciplina: string;
  quantidade: number;
}

export interface RetencaoModalidadeData{
  modalidade: string;
  quantidade: number;
}

export interface Porcentagens{
  mediaNotas: number,
  porcentagemAprovados: number,
  porcentagemCancelados: number,
  alunosReprovados: number,
  aprovados: number,
  rep_nota: number,
  rep_freq: number,
  cancelados: number
}

export interface Quartis{
  quartil_0_25: number,
  quartil_26_50: number,
  quartil_51_75: number,
  quartil_76_100: number
}

export interface Horas{
  obrigatoria: number,
  optativa: number
}
