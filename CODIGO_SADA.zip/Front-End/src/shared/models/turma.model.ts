import { Curso } from "./curso.model";
import { Disciplina } from "./disciplina.model";
import { Professor } from "./professor.model";

export class Turma {
  constructor(
    public id?: number,
    public nome?: string,
    public departamento?: string,
    public ano?: string,
    public periodo?: string,
    public turno?: string,
    public disciplina?: Disciplina,
    public professor?: Professor,
    public curso?: Curso
  ) {}
}
