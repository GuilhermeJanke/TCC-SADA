import { Curso } from "./curso.model";
import { Pessoa } from "./pessoa.model";

export class Professor extends Pessoa {
  constructor(
    public id?: number,
    public nome?: string,
    public cpf?: string,
    public email?: string,
    public telefone?: string,
    public curso?: Curso[]
  ) {
    super(id, nome, cpf, email, telefone, curso);
  }
}
