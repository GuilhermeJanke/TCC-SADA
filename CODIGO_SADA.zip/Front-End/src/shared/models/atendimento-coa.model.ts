import { Aluno } from "./aluno.model";
import { Professor } from "./professor.model";

export class AtendimentoCoa {
  constructor(
    public id?: number,
    public descricao?: string,
    public data_atendimento?: Date,
    public aluno?: Aluno,
    public professor?: Professor[],
    public situacao?: Boolean,
    public anexo?: string
  ) {}
}
