export interface SomaEvasao {
  SomaEvasao: number;
  SomaTrancamento: number;
  SomaRegistroAtivo: number;
  SomaConclusaoFormatura: number;
}
