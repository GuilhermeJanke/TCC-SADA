import { Curso } from "./curso.model";
import { Pessoa } from "./pessoa.model";

export class Aluno extends Pessoa {

  indiceRisco: any;
  
  constructor(
    public id?: number,
    public nome?: string,
    public cpf?: string,
    public email?: string,
    public telefone?: string,
    public curso?: Curso[],
    public grr?: string,
    public potencial_retencao?: string,
    public potencial_evasao?: string,
    public potencial_jubilamento?: string,
    public ch_integralizada?: number,
    public periodo_atual?: number,
    public ira?: number,
    public risco?: number,
    public curriculo_aluno?: string,
    public total_disciplinas_aprovadas?: number,
    public total_disciplinas_repovada_freq?: number,
    public total_disciplinas_repovada_nota?: number,
    public total_disciplinas_canceladas?: number
  ) {
    super(id, nome, cpf, email, telefone, curso);
  }
}
