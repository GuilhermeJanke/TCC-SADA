export class AlunoDisciplinas {
    constructor(
        public idAluno: number,
        public disciplina: string
    ){}
}