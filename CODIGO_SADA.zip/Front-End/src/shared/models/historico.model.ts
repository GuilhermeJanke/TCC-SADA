import { Aluno } from "./aluno.model";
import { Disciplina } from "./disciplina.model";
import { Turma } from "./turma.model";

export class Historico {
  indiceRisco: any;
  constructor(
    public id?: number,
    public periodo?: string,
    public ano?: string,
    public data_atualizacao?: string,
    public ch?: number,
    public nota?: number,
    public frequencia?: number,
    public status?: string,
    public tipo?: string,
    public observacao?: string,
    public natureza?: string,
    public situacao_aluno?: string,
    public curriculo_atual?: string,
    public nome?: string,
    public matricula?: string,
    public coordenacao?: string,
    public semestre?: string,
    public aluno?: Aluno,
    public disciplina?: Disciplina,
    public turma?: Turma
  ) {}
}
