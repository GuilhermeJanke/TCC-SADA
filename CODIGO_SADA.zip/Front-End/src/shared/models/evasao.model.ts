
export class Evasao{
  constructor(
    public grr?: string,
    public periodo?: number,
    public evasao?: string,
    public integra?: string,
    public nome?: string,
    public ira?: number,
    public indice?: string,
    public reprova_nota?: string,
    public jubilameto?: string,
    public situacao?: string,
    public retencao?: number,
    public reprova_frequencia?: number
  ) {

  }
}
