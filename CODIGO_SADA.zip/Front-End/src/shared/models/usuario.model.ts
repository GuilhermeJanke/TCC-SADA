import { Curso } from "./curso.model";
import { Pessoa } from "./pessoa.model";

export class Usuario extends Pessoa {
  constructor(
    public id?: number,
    public nome?: string,
    public cpf?: string,
    public email?: string,
    public telefone?: string,
    public curso?: Curso[],
    public senha?: string,
    public tipo?: string
  ) {
    super(id, nome, cpf, email, telefone, curso);
  }
}
