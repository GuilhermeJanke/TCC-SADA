import { Usuario } from "./usuario.model";

export class LoginResponse {
  constructor(
    public usuario?: Usuario,
    public refresh?: string,
    public access?: string
  ) {}
}
