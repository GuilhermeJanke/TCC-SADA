export class Curso {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public sigla?: string,
    public ch_semestre?: number,
    public ch_max_semeste?: number,
    public ch_total?: number,
    public ch_max?: number,
    public qtd_semestres?: number,
    public qtd_max_semestres?: number,
    public ch_disciplinas_obrigatorias?: number,
    public ch_disciplinas_optativas?: number,
  ) {}
}
