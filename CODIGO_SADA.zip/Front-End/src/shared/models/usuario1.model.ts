export interface Usuario1 {
  id: number;
  cpf: string;
  email: string;
  senha: string;
}
