import { Curso } from "./curso.model";
import { Modalidade } from "./modalidade.model";

export class Disciplina {
  constructor(
    public id?: number,
    public codigo?: string,
    public nome?: string,
    public periodo?: string,
    public natureza?: string,
    public ch?: string,
    public ch_semanal?: string,
    public ch_EAD?: string,
    public ch_campo?: string,
    public ch_estagio?: string,
    public ch_estagio_pedagogico?: string,
    public ch_extensao?: string,
    public ch_laboratorio?: string,
    public ch_orientada?: string,
    public ch_padrao?: string,
    public ch_pratica_específica?: string,
    public pre_requisito?: Disciplina[],
    public modalidade?: Modalidade,
    public curso?: Curso
  ) {}
}
