export class Login {
  constructor(
    public login?: string,
    public senha?: string) {}
}
