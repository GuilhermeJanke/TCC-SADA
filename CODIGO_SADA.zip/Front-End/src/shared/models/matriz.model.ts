import { Curso } from "./curso.model";
import { Disciplina } from "./disciplina.model";
import { Modalidade } from "./modalidade.model";

export class Matriz {
  constructor(
    public id?: number,
    public curriculo?: string,
    public ano_versao?: number,
    public departamento?: string,
    public disciplina?: Disciplina[],
    public modalidade?: Modalidade[],
    public curso?: Curso
  ) {}
}
