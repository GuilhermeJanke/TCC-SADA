
export class Modalidade {
  constructor(
    public id?: number,
    public nome?: string
    ) {}
}
