import { NumericoAdminDirective } from './numerico-admin.directive';

describe('NumericoAdminDirective', () => {
  it('should create an instance', () => {
    const directive = new NumericoAdminDirective();
    expect(directive).toBeTruthy();
  });
});
