export * from "./numerico.directive";
export * from "./numerico-admin.directive";
