require("dotenv-safe").config();
const jwt = require('jsonwebtoken');
var http = require('http');
const express = require('express')
const httpProxy = require('express-http-proxy');
const app = express();
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var logger = require('morgan');
var helmet = require('helmet');
const cors = require('cors');

app.use(cors({
  origin: 'http://localhost:4200'
}));



// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())


const authServiceProxy = httpProxy('http://localhost:8000/login/', {

  proxyReqBodyDecorator: function (bodyContent, srcReq) {
    try {
      retBody = {};
      retBody.email = bodyContent.data.email;
      retBody.senha = bodyContent.data.senha;
      bodyContent = retBody;
      // console.log(retBody)

    }
    catch (e) {
      console.log('- ERRO: ' + e);
    }
    // console.log(bodyContent);

    return bodyContent;
  },
  proxyReqOptDecorator: function (proxyReqOpts, srcReq) {
    proxyReqOpts.headers['Content-Type'] = 'application/json';
    proxyReqOpts.method = 'POST';
    return proxyReqOpts;
  },
  userResDecorator: function (proxyRes, proxyResData, userReq, userRes) {
    console.log(proxyRes.statusCode);
    if (proxyRes.statusCode == 200) {
      console.log(proxyRes.statusCode);
      var str = Buffer.from(proxyResData).toString('utf-8');
      var objBody = JSON.parse(str);
      const id = objBody.id;

      console.log("ID IMPRIME AQUI");
      console.log(id);

      const token = jwt.sign({ id }, process.env.SECRET, {
        expiresIn: 2400 // expira em 20 min
      });
      userRes.status(200);
      return { auth: true, token: token, data: objBody };
    }
    else {
      userRes.status(401);
      return { message: 'Login inválido!' };
    }
  }
});

const usuariosServiceProxy = httpProxy('http://localhost:8000/usuarios/');

const usuariosPostServiceProxy = httpProxy('http://localhost:8000/usuarios/', {
  proxyReqBodyDecorator: function (bodyContent, srcReq) {
    try {
      retBody = {};
      retBody.id = bodyContent.id;
      retBody.nome = bodyContent.nome;
      retBody.cpf = bodyContent.cpf;
      retBody.email = bodyContent.email;
      retBody.senha = bodyContent.senha;
      retBody.grr = bodyContent.grr;
      retBody.curso = bodyContent.curso;
      //retBody.endereco = {
        //id: bodyContent.endereco.id,
        //tipo: bodyContent.endereco.tipo,
        //logradouro: bodyContent.endereco.logradouro,
      retBody.telefone = bodyContent.telefone;
      retBody.tipo = bodyContent.tipo;

      bodyContent = retBody;
    }
    catch (e) {
      console.log('- ERRO: ' + e);
    }
    return bodyContent;
  },
  proxyReqOptDecorator: function (proxyReqOpts, srcReq) {
    proxyReqOpts.headers['Content-Type'] = 'application/json';
    proxyReqOpts.method = 'POST';
    return proxyReqOpts;
  },
  usuariosResDecator: function(req, res){
    console.log(res);
  }
});


const cursosServiceProxy = httpProxy('http://localhost:8000/curso/');

const cursosPostServiceProxy = httpProxy('http://localhost:8000/curso/', {

  proxyReqBodyDecorator: function (bodyContent, srcReq) {
    try {
      retBody = {};
      retBody.id = bodyContent.id;
      retBody.codigo = bodyContent.codigo;
      retBody.sigla = bodyContent.sigla;
      retBody.nome = bodyContent.nome;
      bodyContent = retBody;
    }
    catch (e) {
      console.log('- ERRO: ' + e);
    }
    return bodyContent;
  },
  proxyReqOptDecorator: function (proxyReqOpts, srcReq) {
    proxyReqOpts.headers['Content-Type'] = 'application/json';
    proxyReqOpts.method = 'POST';
    return proxyReqOpts;
  }
});

// AUTH

app.post('/login', (req, res, next) => {
  authServiceProxy(req, res, next);
});

app.post('/logout', function (req, res) {
  res.json({ auth: false, token: null });
});

// USUARIOS

app.post('/usuarios', function (req, res, next) {
  usuariosPostServiceProxy(req, res, next);
});

app.get('/usuarios', function (req, res, next) {
  usuariosServiceProxy(req, res, next);
});

// CURSOS

//app.post('/cursos', verifyJWT, function (req, res, next) {
 // cursosPostServiceProxy(req, res, next);
//});


// Configurações do app
app.use(logger('dev'));
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// Cria o servidor na porta 3000
var server = http.createServer(app);
server.listen(3000);
