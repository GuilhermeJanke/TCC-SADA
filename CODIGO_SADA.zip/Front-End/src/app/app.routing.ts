import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { Routes, RouterModule } from "@angular/router";
import { ListarUsuarioComponent } from "./components/admin/listar-usuario/listar-usuario.component";
import { InserirUsuarioComponent } from "./components/admin/inserir-usuario/inserir-usuario.component";
import { EditarUsuarioComponent } from "./components/admin/editar-usuario/editar-usuario.component";
import { AuthGuard } from "./components/auth/auth.guard";
import { LoginRoutes } from "./components/auth/login/auth-routing.module";
import { InserirCursoComponent } from "./components/admin/inserir-curso/inserir-curso.component";
import { EditarCursoComponent } from "./components/admin/editar-curso/editar-curso.component";
import { LoginComponent } from "./components/auth/login/login.component";
import { HomeComponent } from "./components/others/home/home.component";
import { ImportarMatrizCurricularComponent } from "./components/others/importar-matriz-curricular/importar-matriz-curricular.component";
import { DesempenhoGeralComponent } from "./components/others/desempenho-geral/desempenho-geral.component";
import { ImportarHistoricoComponent } from "./components/others/importar-historico/importar-historico.component";
import { ImportarTurmaComponent } from "./components/others/importar-turma/importar-turma.component";
import { JubilamentoComponent } from "./components/others/jubilamento/jubilamento.component";
import { RetencaoComponent } from "./components/others/retencao/retencao.component";
import { EvasaoComponent } from "./components/others/evasao/evasao.component";
import { DesempenhoDetalhadoComponent } from "./components/others/desempenho-detalhado/desempenho-detalhado.component";
import { HistoricoAlunoComponent } from "./components/others/historico-aluno/historico-aluno.component";
import { MatrizCurricularComponent } from "./components/others/matriz-curricular/matriz-curricular.component";
import { AtendimentoCoaComponent } from "./components/others/atendimento-coa/atendimento-coa.component";
import { PrevisaoDesempenhoComponent } from "./components/others/previsao-desempenho/previsao-desempenho.component";
import { PerfilComponent } from "./components/others/perfil/perfil.component";
import { VerModalidadeComponent } from "./components/others/importar-matriz-curricular/ver-modalidade/ver-modalidade.component";
import { CriarModalidadeComponent } from "./components/others/importar-matriz-curricular/criar-modalidade/criar-modalidade.component";
import { CalculoJubilamentoComponent } from "./components/others/jubilamento/calculo-jubilamento/calculo-jubilamento.component";
import { IntegralizacaoComponent } from "./components/others/desempenho-geral/integralizacao/integralizacao.component";
import { ReprovacaoPorModalidadeComponent } from "./components/others/desempenho-geral/reprovacao-por-modalidade/reprovacao-por-modalidade.component";
import { ReprovacaoPorNotaEFrequenciaComponent } from "./components/others/desempenho-geral/reprovacao-por-nota-e-frequencia/reprovacao-por-nota-e-frequencia.component";
import { AprovacaoPorModalidadeComponent } from "./components/others/desempenho-geral/aprovacao-por-modalidade/aprovacao-por-modalidade.component";
import { VerMatrizComponent } from "./components/others/matriz-curricular/ver-matriz/ver-matriz.component";
import { PotencialJubilamentoComponent } from "./components/others/previsao-desempenho/potencial-jubilamento/potencial-jubilamento.component";
import { PotencialRetencaoComponent } from "./components/others/previsao-desempenho/potencial-retencao/potencial-retencao.component";
import { DesempenhoPorModalidadeDisciplinaComponent } from "./components/others/desempenho-detalhado/desempenho-por-modalidade-disciplina/desempenho-por-modalidade-disciplina.component";
import { DesempenhoGeral } from "./components/others/desempenho-detalhado/desempenho-geral/desempenho-geral.component";
import { GerarRelatorioRetencaoComponent } from "./components/others/retencao/gerar-relatorio-retencao/gerar-relatorio-retencao.component";
import { GerarRelatorioEvasaoComponent } from "./components/others/evasao/gerar-relatorio-evasao/gerar-relatorio-evasao.component";
import { CriarAtendimentoComponent } from "./components/others/atendimento-coa/criar-atendimento/criar-atendimento.component";
import { VerHistoricoComponent } from "./components/others/historico-aluno/ver-historico/ver-historico.component";
import { EditarModalidadeComponent } from "./components/others/importar-matriz-curricular/editar-modalidade/editar-modalidade.component";
import { EsqueceuSenhaComponent } from "./components/auth/esqueceu-senha/esqueceu-senha.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full",
  },
  {
    path: "login/esqueci-senha",
    component: EsqueceuSenhaComponent,
  },
  {
    path: "coordenador",
    redirectTo: "coordenador/home",
    canActivate: [AuthGuard],
    data: { role: "coordenador" },
  },
  {
    path: "coordenador/home",
    component: HomeComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "usuarios/listar",
    component: ListarUsuarioComponent,
    canActivate: [AuthGuard],
    data: { role: "admin" },
  },
  {
    path: "usuarios/inserir",
    component: InserirUsuarioComponent,
    canActivate: [AuthGuard],
    data: { role: "admin" },
  },
  {
    path: "usuarios/editar/:id",
    component: EditarUsuarioComponent,
    canActivate: [AuthGuard],
    data: { role: "admin" },
  },
  {
    path: "cursos/inserir-curso",
    component: InserirCursoComponent,
    canActivate: [AuthGuard],
    data: { role: "admin" },
  },
  {
    path: "cursos/editar-curso/:id",
    component: EditarCursoComponent,
    canActivate: [AuthGuard],
    data: { role: "admin" },
  },
  {
    path: "coordenador/perfil",
    component: PerfilComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },

  // detalhamento gráficos Inicio
  {
    path: "coordenador/integralizacao",
    redirectTo: "coordenador/desempenho-geral/integralizacao",
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/desempenho-geral/integralizacao",
    component: IntegralizacaoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/reprovacao-por-modalidade",
    redirectTo: "coordenador/desempenho-geral/reprovacao-por-modalidade",
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/desempenho-geral/reprovacao-por-modalidade",
    component: ReprovacaoPorModalidadeComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/reprovacao-por-nota-e-frequencia",
    redirectTo: "coordenador/desempenho-geral/reprovacao-por-nota-e-frequencia",
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/desempenho-geral/reprovacao-por-nota-e-frequencia",
    component: ReprovacaoPorNotaEFrequenciaComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/aprovacao-por-modalidade",
    redirectTo: "coordenador/desempenho-geral/aprovacao-por-modalidade",
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/desempenho-geral/aprovacao-por-modalidade",
    component: AprovacaoPorModalidadeComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },

  // Importar Dados
  {
    path: "coordenador/importar-dados",
    redirectTo: "coordenador/importar-dados/matriz-curricular",
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/importar-dados/matriz-curricular",
    component: ImportarMatrizCurricularComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/importar-dados/matriz-curricular/criar-modalidade/:id",
    component: CriarModalidadeComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/importar-dados/matriz-curricular/editar-modalidade/:id_matriz/:id_modalidade",
    component: EditarModalidadeComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/importar-dados/matriz-curricular/ver-modalidade/:id",
    component: VerModalidadeComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/importar-dados/historico",
    component: ImportarHistoricoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/importar-dados/turma",
    component: ImportarTurmaComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/desempenho-geral",
    component: DesempenhoGeralComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/jubilamento",
    component: JubilamentoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/calculo-jubilamento",
    component: CalculoJubilamentoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/retencao",
    component: RetencaoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/retencao/gerar-relatorio-retencao",
    component: GerarRelatorioRetencaoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/evasao",
    component: EvasaoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/evasao/gerar-relatorio-evasao",
    component: GerarRelatorioEvasaoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/desempenho-detalhado",
    component: DesempenhoDetalhadoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/desempenho-detalhado/desempenho-geral",
    component: DesempenhoGeral,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/desempenho-detalhado/desempenho-por-modalidade-disciplina",
    component: DesempenhoPorModalidadeDisciplinaComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/previsao-desempenho",
    component: PrevisaoDesempenhoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/previsao-desempenho/potencial-retencao",
    component: PotencialRetencaoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/previsao-desempenho/potencial-jubilamento",
    component: PotencialJubilamentoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/historico-aluno",
    component: HistoricoAlunoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/historico-aluno/ver-historico/:id",
    component: VerHistoricoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/matriz-curricular",
    component: MatrizCurricularComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/matriz-curricular/ver-matriz/:id",
    component: VerMatrizComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/atendimento-coa",
    component: AtendimentoCoaComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },
  {
    path: "coordenador/atendimento-coa/criar-atendimento",
    component: CriarAtendimentoComponent,
    canActivate: [AuthGuard],
    data: { role: "coordenador, admin" },
  },

  {
    path: "login",
    component: LoginComponent,
  },
  ...LoginRoutes,
];

@NgModule({
  imports: [CommonModule, BrowserModule, RouterModule.forRoot(routes)],
  exports: [],
})
export class AppRoutingModule {}
