import { FileUploadModule } from "ng2-file-upload";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { SharedModule } from "../shared/shared.module";
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { ToastrModule } from "ngx-toastr";
import { AppRoutingModule } from "./app.routing";
import { HelpersModule } from "./helpers/helpers.module";
import { AppComponent } from "./app.component";
import { AuthModule } from "./components/auth/auth.module";
import { AdminModule } from "./components/admin/admin.module";
import { OthersModule } from "./components/others/others.module";
import { NgSelectModule } from "@ng-select/ng-select";
import { MatTabsModule } from "@angular/material/tabs";


@NgModule({
  imports: [
    BrowserAnimationsModule,
    SharedModule,
    FormsModule,
    HttpClientModule,
    HelpersModule,
    RouterModule,
    AppRoutingModule,
    NgbModule,
    ToastrModule.forRoot(),
    AdminModule,
    OthersModule,
    NgSelectModule,
    FileUploadModule,
    MatTabsModule,
    AuthModule
  ],
  declarations: [AppComponent],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
