import { Component, OnInit } from "@angular/core";

declare interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  class: string;
}
export const ROUTES: RouteInfo[] = [
  {
    path: "/coordenador/desempenho-geral",
    title: "Início",
    icon: "design_app",
    class: "",
  },
  {
    path: "/coordenador/importar-dados",
    title: "Importar Dados",
    icon: "education_atom",
    class: "",
  },
  {
    path: "/coordenador/jubilamento",
    title: "Jubilamento",
    icon: "location_map-big",
    class: "",
  },
  {
    path: "/coordenador/retencao",
    title: "Retenção",
    icon: "ui-1_bell-53",
    class: "",
  },

  {
    path: "/coordenador/evasao",
    title: "Evasão",
    icon: "users_single-02",
    class: "",
  },
  {
    path: "/coordenador/desempenho-detalhado",
    title: "Desempenho Detalhado",
    icon: "design_bullet-list-67",
    class: "",
  },
  {
    path: "/coordenador/previsao-desempenho",
    title: "Previsão de Desempenho",
    icon: "text_caps-small",
    class: "",
  },

  {
    path: "/coordenador/historico-aluno",
    title: "Histórico do Aluno",
    icon: "education_atom",
    class: "",
  },
  {
    path: "/coordenador/matriz-curricular",
    title: "Matriz Curricular",
    icon: "location_map-big",
    class: "",
  },
  {
    path: "/coordenador/atendimento-coa",
    title: "Atendimento COA",
    icon: "ui-1_bell-53",
    class: "",
  },
];

@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.css"],
})
export class SidebarComponent implements OnInit {
  menuItems: any[];

  constructor() {}

  ngOnInit() {
    this.menuItems = ROUTES.filter((menuItem) => menuItem);
  }
  isMobileMenu() {
    if (window.innerWidth > 991) {
      return false;
    }
    return true;
  }
}
