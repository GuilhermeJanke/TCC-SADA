import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Curso, Usuario } from "../../../../shared";
import { CursoService, UsuarioService } from "../../../../shared";
import { MatDialog } from "@angular/material/dialog";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";


@Component({
  selector: "app-editar-usuario",
  templateUrl: "./editar-usuario.component.html",
  styleUrls: ["./editar-usuario.component.css"],
})
export class EditarUsuarioComponent implements OnInit {
  @ViewChild("formAlterar") formAlterar!: NgForm;
  usuario: Usuario = new Usuario();
  cursos: Curso[] = [];
  cursosSelecionados: Curso[] = [];
  isCursosSelecionados: boolean = false;

  constructor(
    private usuarioService: UsuarioService,
    private cursoService: CursoService,
    private route: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    let id = +this.route.snapshot.params["id"];

    const res = this.usuarioService
      .buscarPorId(id)
      .subscribe((user: Usuario) => {
        if (user != null) {
          this.usuario = user[0];
        } else {
          throw new Error("Usuario não encontrado: id = " + id);
        }
      });
  }

  searchCursos(content): void {
    this.cursos = [];
    this.cursoService.listar().subscribe({
      next: (cursos: Curso[]) => {
        this.cursos = cursos;
        if (this.cursos.length > 0) {
          this.isCursosSelecionados = true;
          this.modalService.open(content, {
            scrollable: true,
            size: "xl",
            centered: true,
          });
        } else {
          console.log(this.cursos);
        }
      },
      error: (error: any) => {
        console.log(error);
      },
    });
  }

  removeCurso(item) {
    this.cursos.splice(item, 1);
  }

  atualizar(): void {
    if (this.formAlterar.form.valid) {
      this.usuarioService.atualizar(this.usuario).subscribe((usuario) => {
        this.router.navigate(["/usuarios/listar"]);
      });
    }
  }
}
