import { Component, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Curso } from "../../../../shared";
import { CursoService } from "../../../../shared";
import { Router } from "@angular/router";

@Component({
  selector: "app-inserir-curso",
  templateUrl: "./inserir-curso.component.html",
  styleUrls: ["./inserir-curso.component.scss"],
})
export class InserirCursoComponent {
  @ViewChild("formCurso") formCurso!: NgForm;
  curso!: Curso;

  constructor(private cursoService: CursoService, private router: Router) {}

  ngOnInit(): void {
    this.curso = new Curso();
  }

  cadastrarCursos(): void {
    if (this.formCurso.form.valid) {
      this.cursoService
        .cadastrar(this.curso)
        .subscribe((curso: Curso) => {
        this.curso = curso;
        this.router.navigate(["/usuarios/listar"]);
      });
    }
  }
}
