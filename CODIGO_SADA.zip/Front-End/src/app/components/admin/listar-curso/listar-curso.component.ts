import { Curso } from "../../../../shared";
import { Component, OnInit } from "@angular/core";
import { CursoService } from "../../../../shared";

@Component({
  selector: "app-listar-curso",
  templateUrl: "./listar-curso.component.html",
  styleUrls: ["./listar-curso.component.scss"],
})
export class ListarCursoComponent implements OnInit {
  cursos: Curso[] = [];
  constructor(private cursoService: CursoService) {}

  ngOnInit(): void {
    this.cursos = this.listarCursos();
  }

  listarCursos(): Curso[] {
    this.cursoService.listar().subscribe((data: Curso[]) => {
      if (data == null) {
        this.cursos = [];
      } else {
        this.cursos = data;
      }
    });
    return this.cursos;
  }

  removerCursos($event: any, curso: Curso): void {
    $event.preventDefault();
    if (confirm(`Deseja realmente remover ${curso.nome} ?`)) {
      this.cursoService.remover(curso.id!).subscribe({
        complete: () => {
          this.listarCursos();
        },
      });
    }
  }
}
