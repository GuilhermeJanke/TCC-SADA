import { Component, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Curso } from "../../../../shared";
import { CursoService } from "../../../../shared";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: "app-editar-curso",
  templateUrl: "./editar-curso.component.html",
  styleUrls: ["./editar-curso.component.scss"],
})
export class EditarCursoComponent {
  @ViewChild("formAlterarCurso") formAlterarCurso!: NgForm;
  curso: Curso = new Curso();
  loading!: boolean;

  constructor(
    private cursoService: CursoService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    let id = +this.route.snapshot.params["id"];
    this.loading = false;
    const res = this.cursoService
      .buscarPorId(id)
      .subscribe((curso: Curso) => {
      if (curso != null) {
        this.curso = curso[0];
      } else {
        throw new Error("Curso não encontrado: id = " + id);
      }
    });
  }

  atualizarCursos(): void {
    this.loading = true;
    if (this.formAlterarCurso.form.valid) {
      this.cursoService.atualizar(this.curso).subscribe((curso: Curso) => {
        this.loading = false;
        this.router.navigate(["/usuarios/listar"]);
      });
    }
    this.loading = false;
  }
}
