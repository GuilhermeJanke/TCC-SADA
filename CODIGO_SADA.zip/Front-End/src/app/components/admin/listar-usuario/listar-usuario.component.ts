import { Component, OnInit } from "@angular/core";
import { UsuarioService } from "../../../../shared";
import { Usuario } from "../../../../shared";

@Component({
  selector: "app-listar-usuario",
  templateUrl: "./listar-usuario.component.html",
  styleUrls: ["./listar-usuario.component.css"],
})
export class ListarUsuarioComponent implements OnInit {
  usuarios: Usuario[] = [];
  constructor(private usuarioService: UsuarioService) {}

  ngOnInit(): void {
    this.usuarios = [];
    this.listarUsuarios();
  }

  listarUsuarios(): Usuario[] {
    this.usuarioService.listar().subscribe({
      next: (data: Usuario[]) => {
        if (data == null) {
          this.usuarios = [];
        } else {
          this.usuarios = data;
        }
      },
    });
    return this.usuarios;
  }

  remover($event: any, usuario: Usuario): void {
    $event.preventDefault();
    if (confirm(`Deseja realmente remover ${usuario.nome} ?`)) {
      this.usuarioService.remover(usuario.id!).subscribe({
        complete: () => {
          this.listarUsuarios();
        },
      });
    }
  }
}
