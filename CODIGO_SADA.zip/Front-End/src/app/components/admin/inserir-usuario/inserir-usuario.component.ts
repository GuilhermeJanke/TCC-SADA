import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { Curso, Usuario } from "../../../../shared";
import { CursoService, UsuarioService } from "../../../../shared";
import { MatDialog } from "@angular/material/dialog";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";


@Component({
  selector: "app-inserir-usuario",
  templateUrl: "./inserir-usuario.component.html",
  styleUrls: ["./inserir-usuario.component.css"],
})
export class InserirUsuarioComponent implements OnInit {
  @ViewChild("formUsuario") formUsuario!: NgForm;
  usuario: Usuario = new Usuario();
  cursos: Curso[] = [];
  cursosSelecionados: Curso[] = [];
  isCursosSelecionados: boolean = false;

  constructor(
    private cursoService: CursoService,
    private usuarioService: UsuarioService,
    private router: Router,
    public dialog: MatDialog,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {}

  searchCursos(content): void {
    this.cursos = [];
    this.cursoService.listar().subscribe({
      next: (cursos: Curso[]) => {
        this.cursos = cursos;
        if (this.cursos.length > 0) {
          this.isCursosSelecionados = true;
          this.modalService.open(content, {
            scrollable: true,
            size: "xl",
            centered: true,
          });
        } else {
          console.log(this.cursos);
        }
      },
      error: (error: any) => {
        console.log(error);
      },
    });
  }

  removeCurso(item) {
    this.cursos.splice(item, 1);
  }

  transformarUsuarioParaEnvio(usuario: Usuario): any {
    const usuarioEnviado = { ...usuario }; // Copiar o objeto do usuário original
    // Converter a lista de objetos de cursos para uma lista de IDs de cursos
    usuarioEnviado.curso = usuarioEnviado.curso.map((curso) => ({
      id: curso.id,
    }));
    return usuarioEnviado;
  }

  cadastrar(): void {
    if (this.formUsuario.form.valid) {
      this.usuarioService
        .cadastrar(this.usuario)
        .subscribe((usuario: Usuario) => {
          usuario.curso = this.cursos;
          usuario.senha = this.usuario.senha;
          this.usuarioService
            .atualizarCursosDoUsuario(usuario)
            .subscribe(() => {
              this.router.navigate(["/usuarios/listar"]);
            });
        });
    }
  }
}
