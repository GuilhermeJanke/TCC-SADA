import { NumericoAdminDirective } from './../../../shared/directives/numerico-admin.directive';
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ListarUsuarioComponent } from "./listar-usuario/listar-usuario.component";
import { RouterModule } from "@angular/router";
import { FormsModule } from "@angular/forms";
import { HelpersModule } from "../../helpers/helpers.module";
import { InserirUsuarioComponent } from "./inserir-usuario/inserir-usuario.component";
import { EditarUsuarioComponent } from "./editar-usuario/editar-usuario.component";
import { ListarCursoComponent } from "./listar-curso/listar-curso.component";
import { InserirCursoComponent } from "./inserir-curso/inserir-curso.component";
import { EditarCursoComponent } from "./editar-curso/editar-curso.component";
import { MatDialogModule } from "@angular/material/dialog";
import { CursoService, UsuarioService } from "../../../shared";

@NgModule({
  declarations: [
    ListarUsuarioComponent,
    InserirUsuarioComponent,
    EditarUsuarioComponent,
    ListarCursoComponent,
    InserirCursoComponent,
    EditarCursoComponent,
    NumericoAdminDirective
  ],
  providers: [UsuarioService, CursoService],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    HelpersModule,
    MatDialogModule,
  ],
})
export class AdminModule {}
