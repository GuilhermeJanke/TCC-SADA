import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Login, LoginResponse, LoginService } from "../../../../shared";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  @ViewChild("formLogin", { static: true }) formLogin!: NgForm;
  login: Login = new Login();
  loading: boolean = false;
  mensagemDeErro!: string;
  exibirMensagemDeErro: boolean = false;

  constructor(
    private loginService: LoginService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    if (this.loginService.usuarioLogado) {
      this.router.navigate(["/home"]);
    }
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe(
      (params) => (this.mensagemDeErro = params["errors"])
    );
  }

  logar(): void {
    console.log(this.login);
    this.loading = true;
    if (this.formLogin.form.valid) {
      this.loading = false;
      this.loginService.login(this.login).subscribe(
        (loginResponse: LoginResponse) => {
          if (loginResponse != null) {
            this.loginService.userToken = loginResponse.access;
            this.loginService.usuarioLogado = loginResponse.usuario;
            this.loading = false;
            this.router.navigate(["/coordenador/home"]);
          } else {
            console.log("loginResponse está nulo.");
          }
        },
        (error) => {
          this.mensagemDeErro = "Usuário ou Senha inválidos.";
          this.exibirMensagemDeErro = true;
        }
      );
    }
    this.loading = false;
  }

  // permiter logar clicando em enter
  onEnter(event: any): void {
    if (event.keyCode === 13) {
      this.logar();
    }
  }

  onChange() {
    this.exibirMensagemDeErro = false;
  }
}
