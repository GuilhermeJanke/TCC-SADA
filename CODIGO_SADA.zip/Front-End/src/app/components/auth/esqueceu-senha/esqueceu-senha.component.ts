import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Usuario1, UsuarioService } from '../../../../shared';


@Component({
  selector: 'app-esqueceu-senha',
  templateUrl: './esqueceu-senha.component.html',
  styleUrls: ['./esqueceu-senha.component.scss']
})
export class EsqueceuSenhaComponent implements OnInit {
  id: number;
  cpf: string;
  email: string;
  senhaEnviada: boolean = false;

  constructor(
    private usuarioService: UsuarioService,
    private http: HttpClient
  ) { }

  ngOnInit(): void { }

  buscarEmail(cpf: string): void {
    this.usuarioService.buscarPorCPF(cpf).subscribe(
      (response: Usuario1) => {
        if (response && response.email && response.id) {
          this.id = response.id;
          this.email = response.email;
        } else {
          this.email = '';
        }
      },
      error => {
        console.log('Erro ao buscar o email:', error);
        this.email = '';
      }
    );
  }

  recuperarSenha(): void {
    const novaSenha = this.gerarNovaSenha();

    this.usuarioService.enviarEmailNovaSenha(this.email, novaSenha);
  }

  private gerarNovaSenha(): string {
    const caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let novaSenha = '';
    for (let i = 0; i < 8; i++) {
      novaSenha += caracteres.charAt(Math.floor(Math.random() * caracteres.length));
    }
    return novaSenha;
  }
}
