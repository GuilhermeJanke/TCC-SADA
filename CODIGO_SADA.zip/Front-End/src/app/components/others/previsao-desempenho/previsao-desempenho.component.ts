import { Component, OnInit } from "@angular/core";
import { Aluno, AlunoService, ArmazenarIdService } from "../../../../shared";

@Component({
  selector: "app-previsao-desempenho",
  templateUrl: "./previsao-desempenho.component.html",
  styleUrls: ["./previsao-desempenho.component.scss"],
})
export class PrevisaoDesempenhoComponent implements OnInit {

  selectedAluno: string = null;

  paginaAtual = 1;
  pageSize = 5; // exibe 5 alunos por página por padrão
  alunos: Aluno[] = [];
  listaAux = [];
  num = 0;
  p1 = 0;
  p2 = 0;
  p3 = 0;
  p4 = 0;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  ordenacaoSelecionada = "nome";

  altoRiscoSelecionado = true;
  medioRiscoSelecionado = true;
  baixoRiscoSelecionado = true;
  jubiladoSelecionado = true;
  checkboxSelecionado = "";

  constructor(
    private alunoService: AlunoService,
    private armazenarIdService: ArmazenarIdService,
  ) { }

  ngOnInit(): void {
    this.carregarAlunos();
  }

  carregarAlunos(): void {
    this.alunoService
      .listarAlunos()
      .subscribe((alunos) => {
        this.alunos = alunos;
        this.listaAux = this.alunos;
        this.listaAux = this.listaAux.sort((a, b) => a.nome.localeCompare(b.nome));
        this.listaAux = this.listaAux.slice(0, 10);
      });
  }


  listarAlunos(): void {
    this.alunoService
      .listarAlunos()
      .subscribe((alunos) => {
        this.alunos = alunos;
      });
  }

  isEnabled(): boolean {
    return (
      this.selectedAluno !== null
    );
  }

  //Quantidade por pagina

  onPageSizeChange() {
    this.listaAux = this.alunos.slice(0, this.pageSize);
  }

  //Ordenar por nome, grr e potencial de jubilamento

  ordenarPorNome() {
    this.listaAux = this.listaAux.sort((a, b) => a.nome.localeCompare(b.nome));
  }

  ordenarPorGrr() {
    this.listaAux = this.listaAux.sort((a, b) => b.grr.localeCompare(a.grr));
  }

  ordenarPorIndice() {
    this.listaAux = this.listaAux.sort((a, b) => {
      const riscoMap = {
        "ALTO_RISCO": 3,
        "MEDIO_RISCO": 2,
        "BAIXO_RISCO": 1,
        "EVADIDO_OU_CALOURO": 0
      };

      const riscoA = riscoMap[a.potencial_evasao];
      const riscoB = riscoMap[b.potencial_evasao];

      if (riscoA === riscoB) {
        return a.potencial_evasao.localeCompare(b.potencial_evasao);
      } else {
        return riscoB - riscoA; // Classifica em ordem decrescente de risco
      }
    });
  }


  ordenar() {
    switch (this.ordenacaoSelecionada) {
      case "nome":
        this.ordenarPorNome();
        break;
      case "grr":
        this.ordenarPorGrr();
        break;
      case 'indice':
        this.ordenarPorIndice();
        break;
      default:
        break;
    }
  }

  //Função para ordenar por todas as funções

  selectionsChange() {
    this.listaAux = this.alunos.filter(a => {
      const isAltoRisco = this.altoRiscoSelecionado && a.potencial_evasao === "ALTO_RISCO";
      const isMedioRisco = this.medioRiscoSelecionado && a.potencial_evasao === "MEDIO_RISCO";
      const isBaixoRisco = this.baixoRiscoSelecionado && a.potencial_evasao === "BAIXO_RISCO";
      return isAltoRisco || isMedioRisco || isBaixoRisco;
    });
    switch (this.ordenacaoSelecionada) {
      case "nome":
        this.ordenarPorNome();
        break;
      case "grr":
        this.ordenarPorGrr();
        break;
      case 'indice':
        this.ordenarPorIndice();
        break;
      default:
        break;
    }
    this.listaAux = this.listaAux.slice(0, this.pageSize);

  }

  onCheckboxChange() { }

  setClass(valor): string {
    if (valor === "ALTO_RISCO") {
      return 'AltoRisco';
    } else if (valor === "MEDIO_RISCO") {
      return 'MeioRisco';
    } else if (valor === "BAIXO_RISCO") {
      return 'Risco';
    } else if (valor === "EVADIDO_OU_CALOURO") {
      return 'EvadidoCalouro';
    }
  }

}
