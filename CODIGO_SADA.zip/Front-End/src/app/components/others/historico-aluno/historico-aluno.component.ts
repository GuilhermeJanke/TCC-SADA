import { Component, OnInit } from "@angular/core";
import { AlunoService, ArmazenarIdService } from "../../../../shared/services";
import { Aluno } from "../../../../shared/models";


@Component({
  selector: "app-historico-aluno",
  templateUrl: "./historico-aluno.component.html",
  styleUrls: ["./historico-aluno.component.scss"],
})
export class HistoricoAlunoComponent implements OnInit {
  alunos: Aluno[] = []

  selectedAluno: string = null;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  constructor(
    private armazenarIdService: ArmazenarIdService,
    private alunoService: AlunoService
  ) {
  }

  ngOnInit(): void {
    this.listarAlunos();
  }

  listarAlunos(): void {
    this.alunoService.buscarPorIdCurso(this.id_curso).subscribe(
      (res: Aluno[]) => {
        this.alunos = res;
      },
      (error: any) => {
        console.error(error);
      }
    );
  }

  isEnabled(): boolean {
    return (
      this.selectedAluno !== null
    );
  }
}
