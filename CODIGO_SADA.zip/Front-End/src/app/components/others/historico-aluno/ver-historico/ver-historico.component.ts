import { Component, OnInit } from "@angular/core";
import { Chart } from "chart.js";
import { ActivatedRoute } from "@angular/router";
import { AlunoService, ChartService } from "../../../../../shared/services";
import { Aluno } from "../../../../../shared/models";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';


@Component({
  selector: "app-ver-historico",
  templateUrl: "./ver-historico.component.html",
  styleUrls: ["./ver-historico.component.scss"],
})
export class VerHistoricoComponent implements OnInit {
  id_aluno: number;
  aluno: Aluno;

  grafico1: HTMLCanvasElement;
  grafico2: HTMLCanvasElement;

  constructor(
    private alunoService: AlunoService,
    private route: ActivatedRoute,
    private chartService: ChartService
  ) {}

  ngOnInit() {
    this.id_aluno = +this.route.snapshot.params["id"];
    this.buscarAluno()

    this.grafico1 = document.getElementById("barChartCanvas") as HTMLCanvasElement;
    this.chartService.chartAprovacaoNaturezaDisciplina(this.grafico1, this.id_aluno);
  }

  buscarAluno(): void {
    this.alunoService.buscarPorId(this.id_aluno).subscribe(
      (res: Aluno) => {
        this.aluno = res[0];

        this.grafico2 = document.getElementById("chartDados") as HTMLCanvasElement;
        this.chartService.chartAprovacaoReprovacaoCancelamento(this.grafico2, this.aluno);
      },
      (error: any) => {
        console.error(error);
      }
    );
  }

  gerarPDF() {
    const infoAluno = document.getElementById("infoAluno");
    const grafico1 = document.getElementById("barChartCanvas");
    const infoHistorico = document.getElementById("infoHistorico");
    const grafico2 = document.getElementById("chartDados");

    html2canvas(infoAluno).then((canvasInfoAluno) => {
      html2canvas(grafico1).then((canvasGrafico1) => {
        html2canvas(infoHistorico).then((canvasInfoHistorico) => {
          html2canvas(grafico2).then((canvasGrafico2) => {
            const imgDataInfoAluno = canvasInfoAluno.toDataURL('image/png');
            const imgDataGrafico1 = canvasGrafico1.toDataURL('image/png');
            const imgDataInfoHistorico = canvasInfoHistorico.toDataURL('image/png');
            const imgDataGrafico2 = canvasGrafico2.toDataURL('image/png');

            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = pdfWidth / 2;

            // Adiciona o cabeçalho
            pdf.setFontSize(16);
            pdf.text('SADA - Relatório de Histórico do Aluno', 10, 15);

            // Define as alturas das imagens
            const imgHeight = pdfHeight - 15; // Altura dos gráficos
            const imgInfoHeight = pdfHeight - 70; // Altura das infos

            // Adiciona a infoAluno
            pdf.addImage(imgDataInfoAluno, 'PNG', 10, 30, pdfWidth - 20, imgInfoHeight);

            // Adiciona o primeiro gráfico
            pdf.addImage(imgDataGrafico1, 'PNG', 10, 40 + imgInfoHeight + 10, pdfWidth - 20, imgHeight);

            // Adiciona a infoHistorico
            pdf.addPage();
            pdf.addImage(imgDataInfoHistorico, 'PNG', 10, 30, pdfWidth - 20, imgInfoHeight);

            // Adiciona o segundo gráfico
            pdf.addImage(imgDataGrafico2, 'PNG', 10, 40 + imgInfoHeight + 10, pdfWidth - 20, imgHeight);

            pdf.save('historico-aluno.pdf');
          });
        });
      });
    });
  }
}
