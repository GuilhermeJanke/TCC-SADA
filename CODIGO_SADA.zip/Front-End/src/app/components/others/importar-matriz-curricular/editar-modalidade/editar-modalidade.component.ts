import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import {
  DisciplinaService,
  MatrizService,
  ModalidadeService,
} from "../../../../../shared";
import { Disciplina, Matriz, Modalidade } from "../../../../../shared";
import { ActivatedRoute } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "app-editar-modalidade",
  templateUrl: "./editar-modalidade.component.html",
  styleUrls: ["./editar-modalidade.component.scss"],
})
export class EditarModalidadeComponent implements OnInit {
  @ViewChild("formModalidade") formModalidade!: NgForm;
  modalidade!: Modalidade;
  matriz!: Matriz;
  disciplinas: Disciplina[] = [];
  disciplinasRemovidas: Disciplina[] = [];
  id_matriz: number;
  id_modalidade: number;
  disciplinasSelecionadas: boolean = false;

  constructor(
    private modalidadeService: ModalidadeService,
    private matrizService: MatrizService,
    private disciplinaService: DisciplinaService,
    private route: ActivatedRoute,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.id_matriz = +this.route.snapshot.params["id_matriz"];
    this.id_modalidade = +this.route.snapshot.params["id_modalidade"];
    this.modalidade = new Modalidade();

    this.matrizService
      .buscarPorId(this.id_matriz)
      .subscribe((matriz: Matriz) => {
        if (matriz != null) {
          this.matriz = matriz[0];
        } else {
          throw new Error("Matriz não encontrada: id = " + this.id_matriz);
        }
      });

    this.disciplinaService
      .buscarDisciplinaMatrizModalidade(this.id_matriz, this.id_modalidade)
      .subscribe({
        next: (disciplinas: Disciplina[]) => {
          this.disciplinas = disciplinas;

          if (this.disciplinas.length > 0) {
            this.disciplinasSelecionadas = true;
          } else {
            console.log(this.disciplinas);
          }
        },
        error: (error: any) => {
          console.log(error);
        },
      });
  }

  searchDisciplinas(content): void {
    this.disciplinas = [];
    this.disciplinaService
      .buscarDisciplinaMatrizModalidade(this.id_matriz, this.id_modalidade)
      .subscribe({
        next: (disciplinas: Disciplina[]) => {
          this.disciplinas = disciplinas;

          if (this.disciplinas.length > 0) {
            this.disciplinasSelecionadas = true;
            this.modalService.open(content, {
              scrollable: true,
              size: "xl",
              centered: true,
            });
          } else {
            console.log(this.disciplinas);
          }
        },
        error: (error: any) => {
          console.log(error);
        },
      });
  }

  removeDisciplina(item) {
    this.disciplinasRemovidas.push(this.disciplinas.splice(item, 1)[0]);
  }

  editar(): void {
    if (this.formModalidade.form.valid) {
      this.modalidadeService
        .atualizar(this.id_modalidade, this.modalidade)
        .subscribe({
          next: (modalidade: Modalidade) => {
            this.disciplinasRemovidas.forEach((disciplina) => {
              disciplina.modalidade = null;

              this.disciplinaService
                .atualizar(disciplina.id, disciplina)
                .subscribe({
                  next: (disciplina: Disciplina) => {
                    console.log(disciplina);
                  },
                  error: (error: any) => {
                    // Tratar erros
                    console.log(error);
                  },
                });
            });
          },
          error: (error: any) => {
            // Tratar erros
            console.log(error);
          },
        });
    } else {
      // Lidar com o formulário inválido
      console.log(this.formModalidade);
    }
  }
}
