import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { MatrizService, ModalidadeService } from "../../../../../shared";
import { Matriz, Modalidade } from "../../../../../shared";

@Component({
  selector: "app-ver-modalidade",
  templateUrl: "./ver-modalidade.component.html",
  styleUrls: ["./ver-modalidade.component.scss"],
})
export class VerModalidadeComponent implements OnInit {
  modalidades: Modalidade[] = [];
  matrizes: Matriz[] = [];
  modalidadeSelecionada: number;
  matriz!: Matriz;
  paramId: number;

  constructor(
    private route: ActivatedRoute,
    private matrizService: MatrizService,
    private modalidadeService: ModalidadeService
  ) {}

  ngOnInit() {
    this.paramId = +this.route.snapshot.params["id"];
    this.listar();
  }

  listar() {
    this.matrizService.buscarPorId(this.paramId).subscribe((matriz: Matriz) => {
      if (matriz != null) {
        this.matriz = matriz[0];
        this.modalidades = this.matriz.modalidade;
      } else {
        throw new Error("Matriz não encontrada: id = " + this.paramId);
      }
    });
  }

  remover($event: any, modalidade: Modalidade): void {
    $event.preventDefault();
    if (confirm(`Deseja realmente remover ${modalidade.nome}?`)) {
      this.modalidadeService.remover(modalidade.id!).subscribe({
        complete: () => {
          this.listar();
        },
        error: (error: any) => {
          console.log(error);
        },
      });
    }
  }
}
