import { HttpEvent, HttpEventType } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { environment } from "../../../../environments/environment";
import {
  ArmazenarIdService,
  MatrizService,
  UploadFileService,
} from "../../../../shared";
import { Matriz } from "../../../../shared";

@Component({
  selector: "app-importar-matriz-curricular",
  templateUrl: "./importar-matriz-curricular.component.html",
  styleUrls: ["./importar-matriz-curricular.component.css"],
})
export class ImportarMatrizCurricularComponent implements OnInit {
  matrizes: Matriz[] = [];
  files: Set<File>;
  progress = 0;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  constructor(
    private uploadService: UploadFileService,
    private matrizService: MatrizService,
    private armazenarIdService: ArmazenarIdService
  ) {}

  ngOnInit() {
    console.log(this.id_curso);
    this.matrizes = [];
    this.listarMatriz();
  }

  onChange(event) {
    console.log(event);

    const selectedFiles = <FileList>event.srcElement.files;
    // document.getElementById('customFileLabel').innerHTML = selectedFiles[0].name;

    const fileNames = [];
    this.files = new Set();
    for (let i = 0; i < selectedFiles.length; i++) {
      fileNames.push(selectedFiles[i].name);
      this.files.add(selectedFiles[i]);
    }
    document.getElementById("customFileLabel").innerHTML = fileNames.join(", ");

    this.progress = 0;
  }

  onUpload() {
    if (this.files && this.files.size > 0) {
      this.uploadService
        .upload(this.files, environment.BASE_URL + "matriz/")
        .subscribe((event: HttpEvent<Object>) => {
          if (event.type === HttpEventType.UploadProgress) {
            const percentDone = Math.floor((event.loaded * 50) / event.total);
            console.log("Progresso", percentDone);
            this.progress = percentDone;
          } else if (event.type === HttpEventType.Response) {
            console.log("Upload Concluído");
            this.progress = 100; // Define o progresso como 100% quando o upload for concluído
          }
        });
    }
  }

  listarMatriz(): void {
    // const id_curso = this.armazenarIdService.getCursoID();
    this.matrizService.buscarMatrizPorCurso(this.id_curso).subscribe({
      next: (data: Matriz[]) => {
        if (data == null) {
          this.matrizes = [];
        } else {
          // Filtrar currículos não repetidos
          const curriculos = data.map((matriz) => matriz.curriculo);
          const curriculosUnicos = curriculos.filter(
            (curriculo, index) => curriculos.indexOf(curriculo) === index
          );

          // Criar nova lista de matrizes com os currículos não repetidos
          const matrizesUnicas: Matriz[] = curriculosUnicos.map((curriculo) => {
            return data.find((matriz) => matriz.curriculo === curriculo);
          });

          // Ordenar a lista de matrizes pelo ano_versao mais novo para o mais antigo
          this.matrizes = matrizesUnicas.sort(
            (a, b) => b.ano_versao - a.ano_versao
          );
        }
      },
    });
  }

  // listarMatriz(): void {
  //   const id_curso = this.armazenarIdService.getCursoID();
  //   console.log(id_curso);
  //   this.matrizService.listar().subscribe({
  //     next: (data: Matriz[]) => {
  //       if (data == null) {
  //         this.matrizes = [];
  //       } else {
  //         // Filtrar matrizes pelo ID do curso
  //         this.matrizes = data.filter(matriz => matriz.curso.id === parseInt(id_curso));
  //         // Ordenar a lista de matrizes pelo ano_versao mais novo para o mais antigo
  //         this.matrizes.sort((a, b) => b.ano_versao - a.ano_versao);
  //       }
  //     },
  //   });
  // }

  remover($event: any, matriz: Matriz): void {
    $event.preventDefault();
    if (confirm(`Deseja realmente remover ${matriz.curriculo} ?`)) {
      this.matrizService.remover(matriz.id!).subscribe({
        complete: () => {
          this.listarMatriz();
        },
      });
    }
  }
}
