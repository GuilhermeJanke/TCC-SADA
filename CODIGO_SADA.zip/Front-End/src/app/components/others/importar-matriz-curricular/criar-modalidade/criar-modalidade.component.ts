import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import {
  DisciplinaService,
  MatrizService,
  ModalidadeService,
} from "../../../../../shared";
import { Disciplina, Matriz, Modalidade } from "../../../../../shared";
import { ActivatedRoute } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "app-criar-modalidade",
  templateUrl: "./criar-modalidade.component.html",
  styleUrls: ["./criar-modalidade.component.scss"],
})
export class CriarModalidadeComponent implements OnInit {
  @ViewChild("formModalidade") formModalidade!: NgForm;
  modalidade!: Modalidade;
  matriz!: Matriz;
  disciplinas: Disciplina[] = [];
  paramId: number;
  disciplinasSelecionadas: boolean = false;

  constructor(
    private modalidadeService: ModalidadeService,
    private matrizService: MatrizService,
    private disciplinaService: DisciplinaService,
    private route: ActivatedRoute,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.paramId = +this.route.snapshot.params["id"];
    this.modalidade = new Modalidade();

    this.matrizService.buscarPorId(this.paramId).subscribe((matriz: Matriz) => {
      if (matriz != null) {
        this.matriz = matriz[0];
      } else {
        throw new Error("Matriz não encontrada: id = " + this.paramId);
      }
    });
  }

  searchDisciplinas(content): void {
    this.disciplinas = [];
    this.disciplinaService
      .buscarDisciplinaMatrizModalidade(this.paramId, null)
      .subscribe({
        next: (disciplinas: Disciplina[]) => {
          this.disciplinas = disciplinas;

          if (this.disciplinas.length > 0) {
            this.disciplinasSelecionadas = true;
            this.modalService.open(content, {
              scrollable: true,
              size: "xl",
              centered: true,
            });
          } else {
            console.log(this.disciplinas);
          }
        },
        error: (error: any) => {
          console.log(error);
        },
      });
  }

  removeDisciplina(item) {
    this.disciplinas.splice(item, 1);
  }

  cadastrar(): void {
    if (this.formModalidade.form.valid) {
      this.modalidadeService.cadastrar(this.modalidade).subscribe({
        next: (modalidade: Modalidade) => {
          this.matriz.modalidade.push(modalidade);

          this.matrizService.atualizar(this.paramId, this.matriz).subscribe({
            next: (matriz: Matriz) => {
              this.disciplinas.forEach((disciplina) => {
                disciplina.modalidade = modalidade;

                this.disciplinaService
                  .atualizar(disciplina.id, disciplina)
                  .subscribe({
                    next: (disciplina: Disciplina) => {
                      console.log("Sucesso!");
                    },
                    error: (error: any) => {
                      // Tratar erros
                      console.log(error);
                    },
                  });
              });
            },
            error: (error: any) => {
              // Tratar erros
              console.log(error);
            },
          });
        },
        error: (error: any) => {
          // Tratar erros
          console.log(error);
        },
      });
    } else {
      // Lidar com o formulário inválido
      console.log(this.formModalidade);
    }
  }
}
