import { Component } from "@angular/core";

@Component({
  selector: "app-calculo-jubilamento",
  templateUrl: "./calculo-jubilamento.component.html",
  styleUrls: ["./calculo-jubilamento.component.scss"],
})
export class CalculoJubilamentoComponent {}
