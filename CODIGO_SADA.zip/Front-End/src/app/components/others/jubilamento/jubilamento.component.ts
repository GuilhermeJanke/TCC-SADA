import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { AlunoService, ArmazenarIdService, HistoricoService, CursoService, Pessoa } from "../../../../shared";
import { Curso, Historico, Aluno } from "../../../../shared";
import * as Chart from "chart.js";
import jsPDF from "jspdf";
import html2canvas from 'html2canvas';
import { Observable } from "rxjs";
import { IntegralizacaoData } from "../../../../shared/models/chart_data_types";

@Component({
  selector: "app-jubilamento",
  templateUrl: "./jubilamento.component.html",
  styleUrls: ["./jubilamento.component.scss"],
})
export class JubilamentoComponent implements OnInit {
  @ViewChild("barChartCanvas") barChartCanvas!: ElementRef;

  paginaAtual = 1;
  pageSize = 5; // exibe 5 alunos por página por padrão
  alunos: Aluno[] = [];
  listaAux = [];
  num = 0;
  p1 = 0;
  p2 = 0;
  p3 = 0;
  p4 = 0;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  ordenacaoSelecionada = "nome";

  altoRiscoSelecionado = true;
  medioRiscoSelecionado = true;
  baixoRiscoSelecionado = true;
  jubiladoSelecionado = true;
  checkboxSelecionado = "";

  constructor(
    private alunoService: AlunoService,
    private armazenarIdService: ArmazenarIdService,
    ) { }

  ngOnInit(): void {
    this.carregarAlunos();
    // this.calculaRisco();

  }

  createBarChart() {
    const porcentagens = this.getPorcentagens();
    const data = [
        {
          label: "ALTO RISCO",
          data: [porcentagens[0]],
          backgroundColor: "rgba(240, 130, 5, 0.6)",
        },
        {
          label: "MÉDIO RISCO",
          data: [porcentagens[1]],
          backgroundColor: "rgba(255, 206, 86, 0.6)",
        },
        {
          label: "RISCO",
          data: [porcentagens[2]],
          backgroundColor: "rgba(54, 162, 235, 0.6)",
        },
        {
          label: "JUBILADO",
          data: [porcentagens[3]],
          backgroundColor: "rgba(255, 99, 132, 0.6)",
        },
      ];

    const ctx = document.getElementById("grafico") as HTMLCanvasElement;
    new Chart(ctx, {
      type: "horizontalBar",
      data: {
        labels: ["% de jubilamento"],
        datasets: data,
      },
      options: {
        legend: {
          display: true,
          position: "bottom",
        },
        scales: {
          xAxes: [
            {
              stacked: true,
              ticks: {
                beginAtZero: true,
                min: 0,
                max: 100,
                callback: function (value) {
                  return value + "%";
                },
              },
            },
          ],
          yAxes: [
            {
              stacked: true,
            },
          ],
        },
        responsive: true,
        tooltips: {
          enabled: true,
          mode: "single",
          callbacks: {
            label: function (tooltipItems, data) {
              return tooltipItems.xLabel + "%";
            },
          },
        },
      },
    });
  }

  carregarAlunos(): void {
    this.alunoService
      .listarAlunos()
      .subscribe((alunos) => {
        this.alunos = alunos;
        this.calculaRisco();
        this.createBarChart();
        this.listaAux = this.alunos;
        this.listaAux = this.listaAux.sort((a, b) => a.nome.localeCompare(b.nome));
        this.listaAux = this.listaAux.slice(0, 10);
      });
  }


  listarAlunos(): void {
    this.alunoService
      .listarAlunos()
      .subscribe((alunos) => {
        this.alunos = alunos;
        this.calculaRisco();
      });
  }



// Gerar PDF - Relatório de Jubilamento
  gerarPDF() {
    const tabela = document.getElementById("tabela");
    const grafico = document.getElementById("grafico");

    html2canvas(tabela).then((canvasTabela) => {
      html2canvas(grafico).then((canvasGrafico) => {
        const imgDataTabela = canvasTabela.toDataURL('image/png');
        const imgDataGrafico = canvasGrafico.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdfWidth / 2;

        // Adicione o cabeçalho
        pdf.setFontSize(16);
        pdf.text('SADA - Relatório de Indice de Jubilamento', 10, 20);

        // Adicione a imagem da tabela
        pdf.addImage(imgDataTabela, 'PNG', 10, 30, pdfWidth - 20, pdfHeight - 20);

        // Adicione o título do gráfico
        pdf.setFontSize(14);
        pdf.text('Gráfico de Relação de Percentual de Jubilamento', 10, pdfHeight + 35);

        // Adicione a imagem do gráfico
        pdf.addImage(imgDataGrafico, 'PNG', 10, pdfHeight + 50, pdfWidth - 40, pdfHeight - 80);

        // Salve o arquivo PDF
        pdf.save('jubilamento.pdf');
      });
    });
  }



//Quantidade por pagina

  onPageSizeChange() {
    this.listaAux = this.alunos.slice(0, this.pageSize);
  }

//Ordenar por nome, grr e potencial de jubilamento

  ordenarPorNome() {
    this.listaAux = this.listaAux.sort((a, b) => a.nome.localeCompare(b.nome));
  }

  ordenarPorGrr() {
    this.listaAux = this.listaAux.sort((a, b) => b.grr.localeCompare(a.grr));
  }

  ordenarPorIndice() {
    this.listaAux = this.listaAux.sort((a, b) => {
      const riscoMap = {
        "ALTO_RISCO": 3,
        "MEDIO_RISCO": 2,
        "BAIXO_RISCO": 1,
        "JUBILADO": 0
      };

      const riscoA = riscoMap[a.potencial_jubilamento];
      const riscoB = riscoMap[b.potencial_jubilamento];

      if (riscoA === riscoB) {
        return a.potencial_jubilamento.localeCompare(b.potencial_jubilamento);
      } else {
        return riscoB - riscoA; // Classifica em ordem decrescente de risco
      }
    });
  }


  ordenar() {
    switch (this.ordenacaoSelecionada) {
      case "nome":
        this.ordenarPorNome();
        break;
      case "grr":
        this.ordenarPorGrr();
        break;
      case 'indice':
        this.ordenarPorIndice();
        break;
      default:
        break;
    }
  }

  calculaRisco(): void {

    this.alunos.forEach((al) => {
      if (al.nome === "ALTO_RISCO") {
        this.p1 += 1;
      } else if (al.potencial_jubilamento === "MEDIO_RISCO") {
        this.p2 += 1;
      } else if (al.potencial_jubilamento === "BAIXO_RISCO") {
        this.p3 += 1;
      } else if (al.potencial_jubilamento === "JUBILADO") {
        this.p4 += 1;
      }
    });

    this.num = this.alunos.length;

  }


  getPorcentagens(): number[] {
    // Lógica para obter as porcentagens
    const p1 = Math.round((this.p1 / this.num) * 100);
    const p2 = Math.round((this.p2 / this.num) * 100);
    const p3 = Math.round((this.p3 / this.num) * 100);
    const p4 = Math.round((this.p4 / this.num) * 100);

    console.log((this.p1 / this.num) * 100);
    console.log((this.p2 / this.num) * 100);
    console.log((this.p3 / this.num) * 100);
    console.log((this.p4 / this.num) * 100);

    return [p1,p2,p3, p4];
  }

//Função para ordenar por todas as funções

selectionsChange() {
  this.listaAux = this.alunos.filter(a => {
    const isAltoRisco = this.altoRiscoSelecionado && a.potencial_jubilamento === "ALTO_RISCO";
    const isMedioRisco = this.medioRiscoSelecionado && a.potencial_jubilamento=== "MEDIO_RISCO";
    const isBaixoRisco = this.baixoRiscoSelecionado && a.potencial_jubilamento === "BAIXO_RISCO";
    const isJubilado = this.jubiladoSelecionado && a.potencial_jubilamento === "JUBILADO";
    return isAltoRisco || isMedioRisco || isBaixoRisco || isJubilado;
  });
    switch (this.ordenacaoSelecionada) {
      case "nome":
        this.ordenarPorNome();
        break;
      case "grr":
        this.ordenarPorGrr();
        break;
      case 'indice':
        this.ordenarPorIndice();
        break;
      default:
        break;
    }
    this.listaAux = this.listaAux.slice(0, this.pageSize);

  }

  onCheckboxChange() { }

  setClass(valor): string {
    if (valor === "ALTO_RISCO") {
      return 'AltoRisco';
    } else if (valor === "MEDIO_RISCO") {
      return 'MeioRisco';
    } else if (valor === "BAIXO_RISCO") {
      return 'Risco';
    } else if (valor === "JUBILADO") {
      return 'Jubilado';
    }
  }

}
