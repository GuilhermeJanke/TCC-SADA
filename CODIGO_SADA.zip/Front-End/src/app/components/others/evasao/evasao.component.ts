import { Component, OnInit } from "@angular/core";
import { SomaEvasao } from "../../../../shared/models/retencao.model";
import { ArmazenarIdService, ChartService, HistoricoService } from "../../../../shared";

@Component({
  selector: "app-evasao",
  templateUrl: "./evasao.component.html",
  styleUrls: ["./evasao.component.scss"],
})

export class EvasaoComponent implements OnInit {
  id_curso = parseInt(this.armazenarIdService.getCursoID());
  somaEvasao: number = 0;
  somaTrancamento: number = 0;
  somaAtivos: number = 0;
  somaConclusao: number = 0;
  chartEvasaoProfessor: HTMLCanvasElement;
  chartEvasaoTurno: HTMLCanvasElement;
  chartEvasaoDisciplina: HTMLCanvasElement;

  constructor(
    private historicoService: HistoricoService,
    private chartService: ChartService,
    private armazenarIdService: ArmazenarIdService
    ) { }

  ngOnInit(): void {
    this.buscaSomaEvasao();

    this.chartEvasaoProfessor = document.getElementById("chartEvasaoProfessor") as HTMLCanvasElement;
    this.chartService.chartEvasaoProfessor(this.chartEvasaoProfessor);

    this.chartEvasaoTurno = document.getElementById("chartEvasaoTurno") as HTMLCanvasElement;
    this.chartService.chartEvasaoTurno(this.chartEvasaoTurno);

    this.chartEvasaoDisciplina = document.getElementById("chartEvasaoDisciplina") as HTMLCanvasElement;
    this.chartService.chartEvasaoDisciplina(this.chartEvasaoDisciplina);
  }

  buscaSomaEvasao(): void {
    this.historicoService.buscarSomaEvasao(this.id_curso).subscribe(
      (somaEvasao: SomaEvasao[]) => {
        this.somaEvasao = somaEvasao[0]?.SomaEvasao || 0;
      },
      (error: any) => {
        console.error(error);
      }
    );

    this.historicoService.buscarSomaEvasao(this.id_curso).subscribe(
      (somaTrancamento: SomaEvasao[]) => {
        this.somaTrancamento = somaTrancamento[0]?.SomaTrancamento || 0;
      },
      (error: any) => {
        console.error(error);
      }
    );

    this.historicoService.buscarSomaEvasao(this.id_curso).subscribe(
      (somaAtivos: SomaEvasao[]) => {
        this.somaAtivos = somaAtivos[0]?.SomaRegistroAtivo || 0;
      },
      (error: any) => {
        console.error(error);
      }
    );

    this.historicoService.buscarSomaEvasao(this.id_curso).subscribe(
      (somaConclusao: SomaEvasao[]) => {
        this.somaConclusao = somaConclusao[0]?.SomaConclusaoFormatura || 0;
      },
      (error: any) => {
        console.error(error);
      }
    );
  }
}
