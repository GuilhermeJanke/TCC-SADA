import { Component, OnInit } from "@angular/core";
import { Aluno, AlunoService, HistoricoService, DataGeradaService, ArmazenarIdService } from "../../../../../shared";
import { Curso, Historico, Evasao } from "../../../../../shared";
import jsPDF from "jspdf";
import html2canvas from 'html2canvas';

@Component({
  selector: "app-gerar-relatorio-evasao",
  templateUrl: "./gerar-relatorio-evasao.component.html",
  styleUrls: ["./gerar-relatorio-evasao.component.scss"],
})
export class GerarRelatorioEvasaoComponent implements OnInit {
  paginaAtual = 1;
  pageSize = 10; // exibe 10 alunos por página por padrão
  alunos: Aluno[] = [];
  listaAux = [];

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  ordenacaoSelecionada = "indice";
  selectedAluno: string = null;

  nome = false;
  situacao = false;
  ira = false;
  potencialRetencao = false;
  potencialJubilamento = false;
  reprovacaoFreq = false;
  reprovacaoNota = false;
  percentIntegralizacao = false;
  disciplinasCanceladas = false;

  checkboxCount: number = 0;
  checkboxSelecionado = "";

  constructor(
    private alunoService: AlunoService,
    private armazenarIdService: ArmazenarIdService,
  ) { }

  ngOnInit(): void {
    this.listarAlunos();
  }

  carregarAlunos(): void {
    this.alunoService
      .listarAlunos()
      .subscribe((alunos) => {
        this.alunos = alunos;
        this.listaAux = this.alunos;
        this.listaAux = this.listaAux.sort((a, b) => a.nome.localeCompare(b.nome));
        this.listaAux = this.listaAux.slice(0, 10);
      });
  }


  listarAlunos(): void {
    this.alunoService
      .listarAlunos()
      .subscribe((alunos) => {
        this.alunos = alunos;
        this.listaAux = this.alunos;
        this.listaAux = this.listaAux.sort((a, b) => a.nome.localeCompare(b.nome));
        this.listaAux = this.listaAux.slice(0, 10);
      });
  }

  isEnabled(): boolean {
    return (
      this.selectedAluno !== null
    );
  }

  // Gerar PDF - Relatório de Retenção
  gerarPDF() {
    const tabela = document.getElementById("tabela");

    html2canvas(tabela).then((canvasTabela) => {
      const imgDataTabela = canvasTabela.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdfWidth / 2;

      // Adicione o cabeçalho
      pdf.setFontSize(16);
      pdf.text('SADA - Relatório de Potêncial de Retenção', 10, 20);

      // Adicione a imagem da tabela
      pdf.addImage(imgDataTabela, 'PNG', 10, 30, pdfWidth - 20, pdfHeight - 20);

      // Salve o arquivo PDF
      pdf.save('Potenciao-Evasao.pdf');
    });
  }



  //Quantidade por pagina

  onPageSizeChange() {
    this.listaAux = this.alunos.slice(0, this.pageSize);
  }

  //Ordenar por nome, grr e potencial de jubilamento

  ordenarPorNome() {
    this.listaAux = this.listaAux.sort((a, b) => a.nome.localeCompare(b.nome));
  }

  ordenarPorGrr() {
    this.listaAux = this.listaAux.sort((a, b) => b.grr.localeCompare(a.grr));
  }

  ordenarPorIndice() {
    this.listaAux = this.listaAux.sort((a, b) => {
      const riscoMap = {
        "ALTO_RISCO": 3,
        "MEDIO_RISCO": 2,
        "BAIXO_RISCO": 1,
        "EVADIDO_OU_CALOURO": 0
      };

      const riscoA = riscoMap[a.potencial_evasao];
      const riscoB = riscoMap[b.potencial_evasao];

      if (riscoA === riscoB) {
        return a.potencial_evasao.localeCompare(b.potencial_evasao);
      } else {
        return riscoB - riscoA; // Classifica em ordem decrescente de risco
      }
    });
  }


  ordenar() {
    switch (this.ordenacaoSelecionada) {
      case "nome":
        this.ordenarPorNome();
        break;
      case "grr":
        this.ordenarPorGrr();
        break;
      case 'indice':
        this.ordenarPorIndice();
        break;
      default:
        break;
    }
  }


  //Função para ordenar por todas as funções

  selectionsChange() {
    this.listaAux = this.alunos;
    switch (this.ordenacaoSelecionada) {
      case "nome":
        this.ordenarPorNome();
        break;
      case "grr":
        this.ordenarPorGrr();
        break;
      case 'indice':
        this.ordenarPorIndice();
        break;
      default:
        break;
    }
    this.listaAux = this.listaAux.slice(0, this.pageSize);
  }

  onCheckboxChange(checked: boolean) {
    if (checked) {
      this.checkboxCount++;
    } else {
      this.checkboxCount--;
    }
  }

  setClass(valor): string {
    if (valor === "ALTO_RISCO") {
      return 'AltoRisco';
    } else if (valor === "MEDIO_RISCO") {
      return 'MeioRisco';
    } else if (valor === "BAIXO_RISCO") {
      return 'Risco';
    } else if (valor === "EVADIDO_OU_CALOURO") {
      return 'EvadidoCalouro';
    }

  }

}

class AlunoInfo {
  aluno: number;
  reprovacaoPorNota: number = 0;
  reprovacaoPorFrequencia: number = 0;
  disciplinasCanceladas: number = 0;
  situacao: string = "?";
}
