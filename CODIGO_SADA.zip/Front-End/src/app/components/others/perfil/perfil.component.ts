import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { NgForm } from "@angular/forms";
import { UsuarioService } from "../../../../shared";
import { Usuario } from "../../../../shared";

@Component({
  selector: "app-perfil",
  templateUrl: "./perfil.component.html",
  styleUrls: ["./perfil.component.scss"],
})
export class PerfilComponent implements OnInit {
  @ViewChild("formAtualizar") formAtualizar!: NgForm;
  usuario: Usuario = new Usuario();
  //id!: string;
  loading!: boolean;

  constructor(
    private usuarioService: UsuarioService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    let id = +this.route.snapshot.params["id"];
    this.loading = false;
    const res = this.usuarioService
      .buscarPorId(id)
      .subscribe((user: Usuario) => {
        if (user != null) {
          this.usuario = user[0];
        } else {
          throw new Error("Usuario não encontrado: id = " + id);
        }
      });
  }
  // this.usuario = new Usuario();
  // this.loading = false;
  // this.id = "2";

  // this.usuarioService.buscarPorId(+this.id).subscribe((usuario) => {
  //   this.usuario = usuario;
  // });
  // }

  atualizar(): void {
    this.loading = true;
    if (this.formAtualizar.form.valid) {
      this.usuarioService.atualizar(this.usuario).subscribe((usuario) => {
        this.loading = false;
        this.router.navigate(["/coordenador/home"]);
      });
    }

    this.loading = false;
  }
}
