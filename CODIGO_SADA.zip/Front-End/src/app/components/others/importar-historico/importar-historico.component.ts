import { HttpEvent, HttpEventType } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { environment } from "../../../../environments/environment";
import {
  Aluno,
  AlunoService,
  Historico,
  HistoricoService,
  UploadFileService,
} from "../../../../shared";
import { ArmazenarIdService } from "../../../../shared";

@Component({
  selector: "app-importar-historico",
  templateUrl: "./importar-historico.component.html",
  styleUrls: ["./importar-historico.component.scss"],
})
export class ImportarHistoricoComponent implements OnInit {
  historicos: Historico[] = [];
  alunos: Aluno[] = [];
  files: Set<File>;
  progress = 0;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  constructor(
    private uploadService: UploadFileService,
    private historicoService: HistoricoService,
    private alunoService: AlunoService,
    private armazenarIdService: ArmazenarIdService
  ) {}

  ngOnInit() {
    this.alunos = [];
    this.listarAlunos();
  }


  onChange(event) {
    console.log(event);

    const selectedFiles = <FileList>event.srcElement.files;
    // document.getElementById('customFileLabel').innerHTML = selectedFiles[0].name;

    const fileNames = [];
    this.files = new Set();
    for (let i = 0; i < selectedFiles.length; i++) {
      fileNames.push(selectedFiles[i].name);
      this.files.add(selectedFiles[i]);
    }
    document.getElementById("customFileLabel").innerHTML = fileNames.join(", ");

    this.progress = 0;
  }

  onUpload() {
    if (this.files && this.files.size > 0) {
      this.uploadService
        .upload(
          this.files,
          environment.BASE_URL + `historico/?id_curso=${this.id_curso}`
        )
        .subscribe((event: HttpEvent<Object>) => {
          if (event.type === HttpEventType.UploadProgress) {
            const percentDone = Math.floor((event.loaded * 50) / event.total);
            console.log("Progresso", percentDone);
            this.progress = percentDone;
          } else if (event.type === HttpEventType.Response) {
            console.log("Upload Concluído");
            this.progress = 100; // Define o progresso como 100% quando o upload for concluído
          }
        });
      }
  }

  listarHistorico(): Historico[] {
    this.historicoService.buscarHistoricoPorCurso(this.id_curso).subscribe({
      next: (data: Historico[]) => {
        if (data == null) {
          this.historicos = [];
        } else {
          this.historicos = data;
        }
      },
    });
    return this.historicos;
  }

  listarAlunos(): Aluno[] {
    this.alunoService.listarAlunos().subscribe({
      next: (data: Aluno[]) => {
        if (data == null) {
          this.alunos = [];
        } else {
          this.alunos = data;
        }
      },
    });
    return this.alunos;
  }

  remover($event: any, al: Aluno): void {
    $event.preventDefault();
    if (confirm(`Deseja realmente remover ${al.grr} ?`)) {
      this.alunoService.remover(al.id!).subscribe({
        complete: () => {
          this.listarAlunos();
        },
      });
    }
  }
}
