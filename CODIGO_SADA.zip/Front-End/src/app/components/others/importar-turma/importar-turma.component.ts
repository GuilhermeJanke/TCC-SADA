import { HttpEvent, HttpEventType } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { environment } from "../../../../environments/environment";
import {
  ArmazenarIdService,
  TurmaService,
  UploadFileService,
} from "../../../../shared";
import { Turma } from "../../../../shared";

@Component({
  selector: "app-importar-turma",
  templateUrl: "./importar-turma.component.html",
  styleUrls: ["./importar-turma.component.scss"],
})
export class ImportarTurmaComponent implements OnInit {
  turmas: Turma[] = [];
  files: Set<File>;
  progress = 0;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  constructor(
    private uploadService: UploadFileService,
    private turmaService: TurmaService,
    private armazenarIdService: ArmazenarIdService
  ) {}

  ngOnInit() {
    this.listarTurma();
  }

  onChange(event) {
    console.log(event);

    const selectedFiles = <FileList>event.srcElement.files;
    // document.getElementById('customFileLabel').innerHTML = selectedFiles[0].name;

    const fileNames = [];
    this.files = new Set();
    for (let i = 0; i < selectedFiles.length; i++) {
      fileNames.push(selectedFiles[i].name);
      this.files.add(selectedFiles[i]);
    }
    document.getElementById("customFileLabel").innerHTML = fileNames.join(", ");

    this.progress = 0;
  }

  onUpload() {
    if (this.files && this.files.size > 0) {
      this.uploadService
        .upload(
          this.files,
          environment.BASE_URL + `turma/?id_curso=${this.id_curso}`
        )
        .subscribe((event: HttpEvent<Object>) => {
          if (event.type === HttpEventType.UploadProgress) {
            const percentDone = Math.floor((event.loaded * 50) / event.total);
            console.log("Progresso", percentDone);
            this.progress = percentDone;
          } else if (event.type === HttpEventType.Response) {
            console.log("Upload Concluído");
            this.progress = 100; // Define o progresso como 100% quando o upload for concluído
          }
        });
    }
  }

  listarTurma(): Turma[] {
    this.turmaService.buscarTurmaPorCurso(this.id_curso).subscribe({
      next: (data: Turma[]) => {
        if (data == null) {
          this.turmas = [];
        } else {
          this.turmas = data;
        }
      },
    });
    return this.turmas;
  }

  remover($event: any, turma: Turma): void {
    $event.preventDefault();
    if (confirm(`Deseja realmente remover ${turma.nome} ?`)) {
      this.turmaService.remover(turma.id!).subscribe({
        complete: () => {
          this.listarTurma();
        },
      });
    }
  }
}
