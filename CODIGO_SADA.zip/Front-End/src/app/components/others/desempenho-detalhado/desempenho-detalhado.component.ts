import { Component } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-desempenho-detalhado",
  templateUrl: "./desempenho-detalhado.component.html",
  styleUrls: ["./desempenho-detalhado.component.scss"],
})
export class DesempenhoDetalhadoComponent {
  constructor(private router: Router) {}

  redirect() {
    const tipoDesempenho = (document.getElementById(
      "tipoDesempenho"
    ) as HTMLSelectElement).value;

    if (tipoDesempenho === "geral") {
      this.router.navigate(["/coordenador/desempenho-detalhado/desempenho-geral"]);
    } else if (tipoDesempenho === "modalidade") {
      this.router.navigate([
        "/coordenador/desempenho-detalhado/desempenho-por-modalidade-disciplina",
      ]);
    }
  }
}
