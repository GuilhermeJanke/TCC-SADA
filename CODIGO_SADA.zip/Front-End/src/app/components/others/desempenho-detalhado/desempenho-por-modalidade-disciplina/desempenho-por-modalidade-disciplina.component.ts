import { Component, OnInit, Renderer2, ElementRef } from '@angular/core';
import { Modalidade, Professor, Turma } from "../../../../../shared/models";
import { ArmazenarIdService, ChartService, ModalidadeService, HistoricoService, ProfessorService, TurmaService } from "../../../../../shared/services";
import { forkJoin } from "rxjs";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: "app-desempenho-por-modalidade-disciplina",
  templateUrl: "./desempenho-por-modalidade-disciplina.component.html",
  styleUrls: ["./desempenho-por-modalidade-disciplina.component.scss"],
})
export class DesempenhoPorModalidadeDisciplinaComponent implements OnInit {
  professores: Professor[] = []
  anos: string[] = []
  turmas: Turma[] = []
  turnos: string[] = []
  modalidades: Modalidade[] = []

  selectedProfessor: number = null;
  selectedAno: string = null;
  selectedTurma: string = null;
  selectedTurno: string = null;
  selectedModalidade: number = null;

  mediaNotas: number = 0;
  porcentagemAprovados: number = 0;
  porcentagemCancelados: number = 0;
  alunosReprovados: number = 0;

  grafico1: HTMLCanvasElement;
  grafico1Data = {}
  grafico2: HTMLCanvasElement;
  grafico2Data = {}

  divData;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  constructor(
    private armazenarIdService: ArmazenarIdService,
    private chartService: ChartService,
    private historicoService: HistoricoService,
    private professorService: ProfessorService,
    private turmaService: TurmaService,
    private modalidadeService: ModalidadeService,
    private renderer: Renderer2,
    private el: ElementRef
  ) {
  }

  ngOnInit(): void {
    this.listarProfessores();
    this.listarAnos();
    this.listarTurmas();
    this.listarTurnos();
    this.listarModalidades();

    this.divData = this.el.nativeElement.querySelector('#desempenhoModalidade');
    this.renderer.setStyle(this.divData, 'display', 'none');
  }

  listarProfessores() {
    this.professorService.buscarPorIdCurso(this.id_curso).subscribe(
      (res: Professor[]) => {
        res = res.sort((a, b) => a.nome.localeCompare(b.nome));
        this.professores = res;
      },
      (error: any) => {
        console.error(error);
      }
    );
  }

  listarAnos() {
    this.historicoService.buscarPorAnos(this.id_curso).subscribe(
      (res: string[]) => {
        this.anos = res;
      },
      (error: any) => {
        console.error(error);
      }
    );
  }

  listarTurmas() {
    this.turmaService.buscarTurmaPorCurso(this.id_curso).subscribe(
      (res: Turma[]) => {
        res = res.filter((item, index, self) =>
          index === self.findIndex((t) => t.nome === item.nome)
        );
        res = res.sort((a, b) => a.nome.localeCompare(b.nome));
        this.turmas = res;
      },
      (error: any) => {
        console.error(error);
      }
    );
  }

  listarTurnos() {
    this.turmaService.buscarPorTurnos(this.id_curso).subscribe(
      (res: string[]) => {
        this.turnos = res;
      },
      (error: any) => {
        console.error(error);
      }
    );
  }

  listarModalidades() {
    this.modalidadeService.buscarModalidadePorCurso(this.id_curso).subscribe(
      (res: Modalidade[]) => {
        res = res.sort((a, b) => a.nome.localeCompare(b.nome));
        this.modalidades = res;
      },
      (error: any) => {
        console.error(error);
      }
    );
  }

  isEnabled(): boolean {
    return (
      this.selectedProfessor !== null &&
      this.selectedAno !== null &&
      this.selectedTurma !== null &&
      this.selectedTurno !== null &&
      this.selectedModalidade !== null
    );
  }

  atualizar() {
    forkJoin([
      this.turmaService.buscarQuartisModalidade(
        this.selectedTurma,
        this.selectedModalidade,
        this.selectedTurno,
        this.selectedAno,
        this.selectedProfessor
      ),
      this.turmaService.buscarPorcentagensModalidade(
        this.selectedTurma,
        this.selectedModalidade,
        this.selectedTurno,
        this.selectedAno,
        this.selectedProfessor
      )
    ]).subscribe(
      ([quartisModalidadeRes, porcentagensModalidadeRes]) => {
        this.mediaNotas = porcentagensModalidadeRes.mediaNotas;
        this.porcentagemAprovados = porcentagensModalidadeRes.porcentagemAprovados;
        this.porcentagemCancelados = porcentagensModalidadeRes.porcentagemCancelados;
        this.alunosReprovados = porcentagensModalidadeRes.alunosReprovados;

        this.grafico1Data = {
          "0-25": quartisModalidadeRes.quartil_0_25,
          "26-50": quartisModalidadeRes.quartil_26_50,
          "51-75": quartisModalidadeRes.quartil_51_75,
          "76-100": quartisModalidadeRes.quartil_76_100
        };

        this.grafico1 = document.getElementById("grafico1") as HTMLCanvasElement;
        this.chartService.chartQuartil(this.grafico1, this.grafico1Data);

        this.grafico2Data = {
          "Aprovados": porcentagensModalidadeRes.aprovados,
          "Reprovados por nota": porcentagensModalidadeRes.rep_nota,
          "Reprovados por frequência": porcentagensModalidadeRes.rep_freq,
          "Cancelados": porcentagensModalidadeRes.cancelados
        };

        this.grafico2 = document.getElementById("grafico2") as HTMLCanvasElement;
        this.chartService.chartPorcentagemDesempenho(this.grafico2, this.grafico2Data);

        if (this.mediaNotas !== null
          || this.porcentagemAprovados !== null
          || this.porcentagemCancelados !== null
        ) {
          this.renderer.setStyle(this.divData, 'display', 'block');
        } else {
          this.renderer.setStyle(this.divData, 'display', 'none');
        }
      },
      (error: any) => {
        console.error(error);
      }
    );
  }

  gerarPDF() {
    const grafico1 = document.getElementById("grafico1");
    const grafico2 = document.getElementById("grafico2");
    const medias = document.getElementById("medias");

    html2canvas(grafico1).then((canvasGrafico1) => {
      html2canvas(grafico2).then((canvasGrafico2) => {
        html2canvas(medias).then((canvasMedias) => {
          const imgDataGrafico1 = canvasGrafico1.toDataURL('image/png');
          const imgDataGrafico2 = canvasGrafico2.toDataURL('image/png');
          const imgDataMedias = canvasMedias.toDataURL('image/png');

          const pdf = new jsPDF('p', 'mm', 'a4');
          const pdfWidth = pdf.internal.pageSize.getWidth();
          const pdfHeight = pdfWidth / 2;

          // Adiciona o cabeçalho
          pdf.setFontSize(16);
          pdf.text('SADA - Relatório de Desempenho Detalhado', 10, 15);

          // Define as alturas das imagens
          const imgHeight = pdfHeight - 15; // Altura dos gráficos
          const imgMediasHeight = pdfHeight - 70; // Altura das médias

          // Adiciona as médias
          pdf.addImage(imgDataMedias, 'PNG', 10, 30, pdfWidth - 10, imgMediasHeight);

          // Adiciona o primeiro gráfico
          pdf.addImage(imgDataGrafico1, 'PNG', 10, 40 + imgMediasHeight, pdfWidth - 10, imgHeight);

          // Adiciona o segundo gráfico
          pdf.addImage(imgDataGrafico2, 'PNG', 10, 50 + imgMediasHeight + imgHeight, pdfWidth - 10, imgHeight);

          pdf.save('desempenho-detalhado.pdf');
        });
      });
    });
  }
}
