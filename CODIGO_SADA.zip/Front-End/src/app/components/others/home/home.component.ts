import { Component, OnInit } from "@angular/core";
import { ArmazenarIdService, LoginService } from "../../../../shared";
import { Curso, Usuario } from "../../../../shared";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"],
})
export class HomeComponent implements OnInit {
  usuario: Usuario = new Usuario();
  cursos: Curso[] = [];
  cursoSelecionado: Curso;

  constructor(
    private loginService: LoginService,
    private armazenarIdService: ArmazenarIdService
  ) {}

  ngOnInit(): void {
    this.cursos = this.loginService.usuarioLogado.curso;
    console.log(this.armazenarIdService.getCursoID());
  }

  buscarCurso() {
    console.log(this.loginService.usuarioLogado);
    this.armazenarIdService.setCursoID(JSON.stringify(this.cursoSelecionado));
  }
}
