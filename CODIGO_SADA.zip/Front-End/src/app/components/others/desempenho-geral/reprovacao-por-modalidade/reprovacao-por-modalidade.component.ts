import { Component } from "@angular/core";
import { AlunoDisciplinas, AlunoService, ChartService, HistoricoService, Modalidade, ModalidadeService } from "../../../../../shared";
import { Historico, Aluno } from "../../../../../shared";
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';

@Component({
  selector: "app-reprovacao-por-modalidade",
  templateUrl: "./reprovacao-por-modalidade.component.html",
  styleUrls: ["./reprovacao-por-modalidade.component.css"],
})
export class ReprovacaoPorModalidadeComponent {
  chart: HTMLCanvasElement;

  pageSize = 5;
  paginaAtual = 1;

  alunos: Aluno[] = [];
  alunosBackup: Aluno[] = [];
  historicos: Historico[] = [];
  modalidades: Modalidade[] = [];
  anos: number[];

  anoInicio: number;
  anoFim: number;

  grr = true;
  nome = true;
  periodo = false;
  ira = false;
  potencialJubilamento = false;
  potencialRetencao = false;
  potencialEvasao = false;
  aprovacao = true;
  percentIntegralizacao = false;
  percentReprovacaoFreq = false;
  percentReprovacaoNota = false;
  disciplinasCanceladas = false;

  checkboxCount: number = 4;

  constructor(
    private alunoService: AlunoService,
    private chartService: ChartService,
    private historicoService: HistoricoService,
    private modalidadeService: ModalidadeService
  ) {
    this.modalidadeService.listar().subscribe({
      next: (lista: Modalidade[]) => {
        this.modalidades = lista;
      }
    });
  }

  ngOnInit(): void {
    this.carregarHistoricos();
    this.listarAlunos();

    this.chart = document.getElementById("chart") as HTMLCanvasElement;
  }

  listarAlunos(): void {
    this.alunoService.listarAlunos().subscribe((alunos) => {
      // Ordena os alunos pelo ID
      this.alunos = alunos.sort((a, b) => a.id - b.id);
      this.alunosBackup = this.alunos;

      this.filtrarTabela();
    });
  }

  filtrarTabela() {
    this.historicoService.buscarDisciplinasPorAnos(this.anoInicio, this.anoFim).subscribe({
      next: (res: AlunoDisciplinas[]) => {
        this.alunos = this.alunosBackup.filter(aluno => res.some(disciplina => disciplina.idAluno === aluno.id));
      }
    });
  }

  carregarHistoricos(): void {
    this.historicoService
      .listar()
      .subscribe((historicos) => {
        this.historicos = historicos;

        this.anos = [...new Set(historicos.map(historico => parseInt(historico.ano, 10)))];

        this.anoInicio = this.anos[0];
        this.anoFim = this.anos[this.anos.length - 1];

        this.chartService.chartReprovadosData(this.chart, this.anoInicio, this.anoFim);
      });
  }

  onCheckboxChange(checked: boolean) {
    if (checked) {
      this.checkboxCount++;
    } else {
      this.checkboxCount--;
    }
  }

  anoChange() {
    this.chartService.chartReprovadosData(this.chart, this.anoInicio, this.anoFim);
    
    this.filtrarTabela();
  }

  gerarPDF() {
    const grafico = document.getElementById("chart");

    html2canvas(grafico, { scale: 2 }).then((canvasGrafico) => {
      const imgDataGrafico = canvasGrafico.toDataURL('image/jpeg', 1.0);

      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdfWidth / 2;

      // Adiciona o cabeçalho
      pdf.setFontSize(16);
      pdf.text('SADA - Relatório de Reprovação por Modalidade de Disciplina', 10, 20);

      pdf.addImage(imgDataGrafico, 'JPEG', 10, 30, pdfWidth - 20, pdfHeight);

      autoTable(pdf, {
        html: '#tabela',
        startY: pdfHeight + 50
      });

      pdf.save('seu-arquivo.pdf');
    });
  }
}
