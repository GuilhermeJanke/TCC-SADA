import { Component, OnInit } from "@angular/core";
import { ModalidadeService, ChartService, ArmazenarIdService } from "../../../../shared";
import { Modalidade } from "../../../../shared";

@Component({
  selector: "app-desempenho-geral",
  templateUrl: "./desempenho-geral.component.html",
  styleUrls: ["./desempenho-geral.component.scss"],
})
export class DesempenhoGeralComponent implements OnInit {
  modalidades: Modalidade[] = [];

  modalidadeSelecionada: number;

  chart1: HTMLCanvasElement;
  chart2: HTMLCanvasElement;
  chart3: HTMLCanvasElement;
  chart4: HTMLCanvasElement;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  constructor(
    private modalidadeService: ModalidadeService,
    private chartService: ChartService,
    private armazenarIdService: ArmazenarIdService
  ) {}

  ngOnInit(): void {
    this.listarModalidade();

    this.chart1 = document.getElementById("chart1") as HTMLCanvasElement;
    this.chartService.chartIntegralizacao(this.chart1);

    this.chart2 = document.getElementById("chart2") as HTMLCanvasElement;

    this.chart3 = document.getElementById("chart3") as HTMLCanvasElement;
    this.chartService.chartReprovados(this.chart3);

    this.chart4 = document.getElementById("chart4") as HTMLCanvasElement;
    this.chartService.chartAprovadosPorModalidade(this.chart4);
  }

  listarModalidade() {
    this.modalidadeService.buscarModalidadePorCurso(this.id_curso).subscribe({
      next: (res: Modalidade[]) => {
        this.modalidades = res;

        if (this.modalidades) {
          this.modalidadeSelecionada = this.modalidades[0]?.id
          this.chartService.chartReprovadosPorModalidade(this.modalidadeSelecionada, this.chart2);
        }
      },
    });
  }

  onModalidadeSelecionada(id: any) {
    this.chartService.chartReprovadosPorModalidade(id, this.chart2);
  }
}
