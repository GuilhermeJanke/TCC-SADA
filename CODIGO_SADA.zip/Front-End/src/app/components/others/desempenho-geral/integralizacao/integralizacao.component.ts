import { Component } from "@angular/core";
import { AlunoService, ChartService } from "../../../../../shared";
import { Curso, Aluno } from "../../../../../shared";
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';

@Component({
  selector: "app-integralizacao",
  templateUrl: "./integralizacao.component.html",
  styleUrls: ["./integralizacao.component.css"],
})
export class IntegralizacaoComponent {
  chart: HTMLCanvasElement;

  pageSize = 5;
  paginaAtual = 1;
  cursos: Curso[] = [];

  checkboxSelecionado = "";
  grr = true;
  nome = true;
  periodo = false;
  ira = false;
  potencialJubilamento = false;
  potencialRetencao = false;
  potencialEvasao = false;
  aprovacao = true;
  percentIntegralizacao = false;
  percentReprovacaoFreq = false;
  percentReprovacaoNota = false;
  percentAprovacao = false;
  disciplinasCanceladas = false;

  alunos: Aluno[];
  checkboxCount: number = 3;

  constructor(
    private chartService: ChartService,
    private alunoService: AlunoService
  ) {
  }

  ngOnInit(): void {
    this.listarAlunos();

    this.chart = document.getElementById("chart") as HTMLCanvasElement;
    this.chartService.chartIntegralizacao(this.chart);
  }

  listarAlunos(): void {
    this.alunoService
      .listarAlunos()
      .subscribe((alunos) => {
        // Ordena os alunos pelo ID
        this.alunos = alunos.sort((a, b) => a.id - b.id);
      });
  }

  onCheckboxChange(checked: boolean) {
    if (checked) {
      this.checkboxCount++;
    } else {
      this.checkboxCount--;
    }
  }

  gerarPDF() {
    const grafico = document.getElementById("chart");

    html2canvas(grafico, { scale: 2 }).then((canvasGrafico) => {
      const imgDataGrafico = canvasGrafico.toDataURL('image/jpeg', 1.0);

      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdfWidth / 2;

      // Adiciona o cabeçalho
      pdf.setFontSize(16);
      pdf.text('SADA - Relatório de Integralização', 10, 20);

      pdf.addImage(imgDataGrafico, 'JPEG', 10, 30, pdfWidth - 20, pdfHeight);

      autoTable(pdf, {
        html: '#tabela',
        startY: pdfHeight + 50
      });

      pdf.save('Integralização.pdf');
    });
  }
}
