import { Component, OnInit } from "@angular/core";
import { AlunoService, ArmazenarIdService, ChartService, Modalidade, ModalidadeService, HistoricoService } from "../../../../../shared";
import { Aluno, AlunoDisciplinas } from "../../../../../shared";
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';

@Component({
  selector: "app-reprovacao-por-nota-e-frequencia",
  templateUrl: "./reprovacao-por-nota-e-frequencia.component.html",
  styleUrls: ["./reprovacao-por-nota-e-frequencia.component.css"],
})
export class ReprovacaoPorNotaEFrequenciaComponent implements OnInit {
  chart: HTMLCanvasElement;

  pageSize = 5;
  paginaAtual = 1;

  alunos: Aluno[] = [];
  alunosBackup: Aluno[] = [];
  modalidades: Modalidade[] = [];

  modalidadeSelecionada: number = 2;
  checkboxCount: number = 3;

  grr = true;
  nome = true;
  situacao = false;
  periodo = false;
  ira = false;
  potencialRetencao = false;
  potencialEvasao = false;
  potencialJubilamento = false;
  reprovacaoFreq = false;
  reprovacaoNota = false;
  percentIntegralizacao = false;
  disciplinasCanceladas = false;

  id_curso = parseInt(this.armazenarIdService.getCursoID());

  constructor(
    private alunoService: AlunoService,
    private armazenarIdService: ArmazenarIdService,
    private chartService: ChartService,
    private modalidadeService: ModalidadeService,
    private historicoService: HistoricoService
  ) {
  }

  ngOnInit(): void {
    this.listarAlunos();
    this.listarModalidade();

    this.chart = document.getElementById("chart") as HTMLCanvasElement;
    this.chartService.chartReprovadosPorModalidade(2, this.chart);
  }

  listarModalidade() {
    this.modalidadeService.buscarModalidadePorCurso(this.id_curso).subscribe({
      next: (res: Modalidade[]) => {
        this.modalidades = res;

        if (this.modalidades) {
          this.modalidadeSelecionada = this.modalidades[0]?.id
          this.chartService.chartReprovadosPorModalidade(this.modalidadeSelecionada, this.chart);
        }
      },
    });
  }

  listarAlunos(): void {
    this.alunoService.listarAlunos().subscribe((alunos) => {
      // Ordena os alunos pelo ID
      this.alunos = alunos.sort((a, b) => a.id - b.id);
      this.alunosBackup = this.alunos;

      this.filtrarTabela(this.modalidadeSelecionada);
    });
  }

  filtrarTabela(id: number) {
    this.historicoService.buscarDisciplinasPorModalidade(id).subscribe({
      next: (res: AlunoDisciplinas[]) => {
        this.alunos = this.alunosBackup.filter(aluno => res.some(disciplina => disciplina.idAluno === aluno.id));
      }
    });
  }

  modalidadeChange(id: number) {
    this.chartService.chartReprovadosPorModalidade(id, this.chart);

    this.filtrarTabela(id);
  }

  onCheckboxChange(checked: boolean) {
    if (checked) {
      this.checkboxCount++;
    } else {
      this.checkboxCount--;
    }
  }

  gerarPDF() {
    const grafico = document.getElementById("chart");

    html2canvas(grafico, { scale: 2 }).then((canvasGrafico) => {
      const imgDataGrafico = canvasGrafico.toDataURL('image/jpeg', 1.0);

      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdfWidth / 2;

      // Adiciona o cabeçalho
      pdf.setFontSize(16);
      pdf.text('SADA - Relatório de Reprovação por Nota e por Frequência', 10, 20);

      pdf.addImage(imgDataGrafico, 'JPEG', 10, 30, pdfWidth - 20, pdfHeight);

      autoTable(pdf, {
        html: '#tabela',
        startY: pdfHeight + 50
      });

      pdf.save('Reprovação-Nota-e-Frequência.pdf');
    });
  }
}
