import { Component, OnInit } from "@angular/core";
import { MatrizService } from "../../../../shared";
import { Curso, Disciplina, Matriz } from "../../../../shared";

@Component({
  selector: "app-matriz-curricular",
  templateUrl: "./matriz-curricular.component.html",
  styleUrls: ["./matriz-curricular.component.scss"],
})
export class MatrizCurricularComponent implements OnInit {
  matrizes: Matriz[] = [];
  matrize: Matriz = new Matriz();
  curso: Curso = new Curso();
  disciplina: Disciplina = new Disciplina();

  constructor(private matrizService: MatrizService) {}

  ngOnInit() {
    this.matrizes = [];
    this.listarMatriz();
  }

  listarMatriz(): void {
    this.matrizService.listar().subscribe({
      next: (data: Matriz[]) => {
        if (data == null) {
          this.matrizes = [];
        } else {
          // Filtrar currículos não repetidos
          const curriculos = data.map((matriz) => matriz.curriculo);
          const curriculosUnicos = curriculos.filter(
            (curriculo, index) => curriculos.indexOf(curriculo) === index
          );

          // Criar nova lista de matrizes com os currículos não repetidos
          const matrizesUnicas: Matriz[] = curriculosUnicos.map((curriculo) => {
            return data.find((matriz) => matriz.curriculo === curriculo);
          });

          // Ordenar a lista de matrizes pelo ano_versao mais novo para o mais antigo
          this.matrizes = matrizesUnicas.sort(
            (a, b) => b.ano_versao - a.ano_versao
          );
        }
      },
    });
  }

  remover($event: any, matriz: Matriz): void {
    $event.preventDefault();
    if (confirm(`Deseja realmente remover ${matriz.curso.nome} ?`)) {
      this.matrizService.remover(matriz.id!).subscribe({
        complete: () => {
          this.listarMatriz();
        },
      });
    }
  }
}
