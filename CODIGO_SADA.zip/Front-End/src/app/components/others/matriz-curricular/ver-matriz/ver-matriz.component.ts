import { Component, OnInit } from "@angular/core";
import { DisciplinaService } from "../../../../../shared";
import { Disciplina, Matriz } from "../../../../../shared";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-ver-matriz",
  templateUrl: "./ver-matriz.component.html",
  styleUrls: ["./ver-matriz.component.scss"],
})
export class VerMatrizComponent implements OnInit {
  matrizes: Matriz[] = [];
  matriz: Matriz = new Matriz();
  disciplinas: Disciplina[] = [];

  constructor(
    private disciplinaService: DisciplinaService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.listarDisciplinas();
  }

  listarDisciplinas(): void {
    let id = +this.route.snapshot.params["id"];
    console.log(id);
    this.disciplinaService.buscarDisciplinaMatriz(id).subscribe({
      next: (data: Disciplina[]) => {
        if (data == null) {
          this.disciplinas = [];
        } else {
          this.disciplinas = data;
        }
      },
      error: (error: any) => {
        console.log(error);
      },
    });
  }

  getPeriodos(): string[] {
    // Cria um array com todos os períodos encontrados nas disciplinas
    const periodosSet = new Set<string>();
    this.disciplinas.forEach(disciplina => {
      periodosSet.add(disciplina.periodo);
    });

    return Array.from(periodosSet);
  }

  getDisciplinasByPeriodo(periodo: string): Disciplina[] {
    return this.disciplinas.filter(disciplina => disciplina.periodo === periodo);
  }
}
