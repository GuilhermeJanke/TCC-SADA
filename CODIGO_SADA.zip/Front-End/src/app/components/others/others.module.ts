import { NgxPaginationModule } from 'ngx-pagination';
import { NgModule } from "@angular/core";
import { CommonModule, DatePipe } from "@angular/common";
import { HomeComponent } from "./home/home.component";
import { HelpersModule } from "../../helpers/helpers.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { HttpClientModule } from "@angular/common/http";
import {
  AlunoService,
  ArmazenarIdService,
  ChartService,
  CoaService,
  CursoService,
  DataGeradaService,
  DisciplinaService,
  HistoricoService,
  LoginService,
  MatrizService,
  ModalidadeService,
  NumericoDirective,
  ProfessorService,
  TurmaService,
  UploadFileService,
  UsuarioService,
} from "../../../shared";
import { NgSelectModule } from "@ng-select/ng-select";
import { ImportarMatrizCurricularComponent } from "./importar-matriz-curricular/importar-matriz-curricular.component";
import { DesempenhoGeralComponent } from "./desempenho-geral/desempenho-geral.component";
import { FileUploadModule } from "ng2-file-upload";
import { ImportarHistoricoComponent } from "./importar-historico/importar-historico.component";
import { ImportarTurmaComponent } from "./importar-turma/importar-turma.component";
import { JubilamentoComponent } from "./jubilamento/jubilamento.component";
import { RetencaoComponent } from "./retencao/retencao.component";
import { EvasaoComponent } from "./evasao/evasao.component";
import { DesempenhoDetalhadoComponent } from "./desempenho-detalhado/desempenho-detalhado.component";
import { PrevisaoDesempenhoComponent } from "./previsao-desempenho/previsao-desempenho.component";
import { HistoricoAlunoComponent } from "./historico-aluno/historico-aluno.component";
import { MatrizCurricularComponent } from "./matriz-curricular/matriz-curricular.component";
import { AtendimentoCoaComponent } from "./atendimento-coa/atendimento-coa.component";
import { PerfilComponent } from "./perfil/perfil.component";
import { CriarModalidadeComponent } from "./importar-matriz-curricular/criar-modalidade/criar-modalidade.component";
import { EditarModalidadeComponent } from "./importar-matriz-curricular/editar-modalidade/editar-modalidade.component";
import { VerModalidadeComponent } from "./importar-matriz-curricular/ver-modalidade/ver-modalidade.component";
import { CalculoJubilamentoComponent } from "./jubilamento/calculo-jubilamento/calculo-jubilamento.component";
import { IntegralizacaoComponent } from "./desempenho-geral/integralizacao/integralizacao.component";
import { ReprovacaoPorNotaEFrequenciaComponent } from "./desempenho-geral/reprovacao-por-nota-e-frequencia/reprovacao-por-nota-e-frequencia.component";
import { ReprovacaoPorModalidadeComponent } from "./desempenho-geral/reprovacao-por-modalidade/reprovacao-por-modalidade.component";
import { AprovacaoPorModalidadeComponent } from "./desempenho-geral/aprovacao-por-modalidade/aprovacao-por-modalidade.component";
import { VerMatrizComponent } from "./matriz-curricular/ver-matriz/ver-matriz.component";
import { PotencialRetencaoComponent } from "./previsao-desempenho/potencial-retencao/potencial-retencao.component";
import { PotencialJubilamentoComponent } from "./previsao-desempenho/potencial-jubilamento/potencial-jubilamento.component";
import { DesempenhoPorModalidadeDisciplinaComponent } from "./desempenho-detalhado/desempenho-por-modalidade-disciplina/desempenho-por-modalidade-disciplina.component";
import { DesempenhoGeral } from "./desempenho-detalhado/desempenho-geral/desempenho-geral.component";
import { GerarRelatorioEvasaoComponent } from "./evasao/gerar-relatorio-evasao/gerar-relatorio-evasao.component";
import { GerarRelatorioRetencaoComponent } from "./retencao/gerar-relatorio-retencao/gerar-relatorio-retencao.component";
import { CriarAtendimentoComponent } from "./atendimento-coa/criar-atendimento/criar-atendimento.component";
import { VerHistoricoComponent } from "./historico-aluno/ver-historico/ver-historico.component";
import { NgbModalModule } from "@ng-bootstrap/ng-bootstrap";

@NgModule({
  declarations: [
    HomeComponent,
    ImportarMatrizCurricularComponent,
    DesempenhoGeralComponent,
    ImportarHistoricoComponent,
    ImportarTurmaComponent,
    JubilamentoComponent,
    RetencaoComponent,
    EvasaoComponent,
    DesempenhoDetalhadoComponent,
    PrevisaoDesempenhoComponent,
    HistoricoAlunoComponent,
    MatrizCurricularComponent,
    VerMatrizComponent,
    AtendimentoCoaComponent,
    PerfilComponent,
    VerModalidadeComponent,
    CriarModalidadeComponent,
    CalculoJubilamentoComponent,
    IntegralizacaoComponent,
    ReprovacaoPorNotaEFrequenciaComponent,
    ReprovacaoPorModalidadeComponent,
    AprovacaoPorModalidadeComponent,
    DesempenhoGeral,
    DesempenhoPorModalidadeDisciplinaComponent,
    PotencialRetencaoComponent,
    PotencialJubilamentoComponent,
    GerarRelatorioEvasaoComponent,
    GerarRelatorioRetencaoComponent,
    CriarAtendimentoComponent,
    VerHistoricoComponent,
    EditarModalidadeComponent,
    NumericoDirective,

  ],
  imports: [
    CommonModule,
    HelpersModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgSelectModule, // Importa o SelectModule explicitamente
    FileUploadModule,
    NgbModalModule,
    DatePipe,
    NgxPaginationModule,
  ],

  providers: [
    ArmazenarIdService,
    AlunoService,
    ChartService,
    CoaService,
    CursoService,
    DisciplinaService,
    HistoricoService,
    LoginService,
    MatrizService,
    ModalidadeService,
    ProfessorService,
    TurmaService,
    UploadFileService,
    UsuarioService,
    DataGeradaService,
  ],
})
export class OthersModule {}
