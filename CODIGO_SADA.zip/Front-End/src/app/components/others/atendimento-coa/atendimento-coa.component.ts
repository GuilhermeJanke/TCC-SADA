import { Component, OnInit, TemplateRef, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import { AtendimentoCoa } from "../../../../shared/models/atendimento-coa.model";
import { CoaService,  } from "../../../../shared/services/coa.service";
import { NgForm } from "@angular/forms";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: "app-atendimento-coa",
  templateUrl: "./atendimento-coa.component.html",
  styleUrls: ["./atendimento-coa.component.scss"],
})
export class AtendimentoCoaComponent implements OnInit {
  @ViewChild('content') content!: TemplateRef<any>;
  //coa: AtendimentoCoa = new AtendimentoCoa();
  selectedAluno: string = null;
  paginaAtual = 1;
  pageSize = 5; // exibe 5 alunos por página por padrão
  atendimentos: AtendimentoCoa[] = [];
  listaAux = [];
  ordenacaoSelecionada = "nome";

  statusAbertoSelecionado = true;
  statusFechadoSelecionado = true;
  checkboxSelecionado = "";


  constructor(
    private coaService: CoaService,
    private router: Router,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    //this.atendimentos = [];
    this.carregarAtendimentos();
  }

  listarAtendimentos(): void {
    this.coaService.listarAtendimentos()
    .subscribe((atendimento) => {
      this.atendimentos = atendimento;
    });
}

  carregarAtendimentos(): void {
    this.coaService
    .listarAtendimentos()
      .subscribe((atendimento) => {
        this.atendimentos = atendimento;
        this.listaAux = this.atendimentos;
        this.listaAux = this.listaAux.sort((a, b) => a.aluno.nome.localeCompare(b.aluno.nome));
        this.listaAux = this.listaAux.slice(0, 10);
      });
  }


  atualizarSituacao(atendimentoId: number): void {
    const atendimento = this.atendimentos.find(a => a.id === atendimentoId);
    if (atendimento) {
      this.modalService.open(this.content).result.then((result) => {
        if (result === 'confirm') {
          atendimento.situacao = false;
          this.coaService.atualizarSituacao(atendimento.id).subscribe((coa: AtendimentoCoa) => {
            atendimento.situacao = coa.situacao; // Atualiza o valor do atendimento atualizado
            // Lógica adicional após a atualização do atendimento
            this.router.navigate(['/coordenador/atendimento-coa/']);
          });
        }
      }, (reason) => {
        // Tratamento caso o modal seja fechado sem confirmação
      });
    }
  }

  isEnabled(): boolean {
    return (
      this.selectedAluno !== null
    );
  }

  redirecionarParaHistorico(alunoId: number) {
    this.router.navigate(['/coordenador/historico-aluno/ver-historico', alunoId]);
  }

  remover($event: any, coa: AtendimentoCoa): void {
    $event.preventDefault();
    if (confirm(`Deseja realmente remover o atendimento ${coa.id} ?`)) {
      this.coaService.remover(coa.id!).subscribe({
        complete: () => {
          this.listarAtendimentos(); // Chame listarAtendimentos() após a remoção ser concluída
        },
      });
    }
    //this.listarAtendimentos();
  }

  onPageSizeChange() {
    this.listaAux = this.atendimentos.slice(0, this.pageSize);
  }

  //Ordenar por nome, data de criação

  ordenarPorNome() {
    this.listaAux = this.listaAux.sort((a, b) => a.aluno.nome.localeCompare(b.aluno.nome));
  }

  ordenarPorData() {
    this.listaAux = this.listaAux.sort((a, b) => {
      if (a.data_atendimento < b.data_atendimento) {
        return -1; // 'a' vem antes de 'b'
      } else if (a.data_atendimento > b.data_atendimento) {
        return 1; // 'a' vem depois de 'b'
      } else {
        return 0; // 'a' e 'b' são iguais em termos de data
      }
    });
  }

ordenar() {
  switch (this.ordenacaoSelecionada) {
    case "nome":
      this.ordenarPorNome();
      break;
    case "data":
      this.ordenarPorData();
      break;
    default:
      break;
  }
}
selectionsChange() {
  this.listaAux = this.atendimentos.filter(a => {
    const isAberto = this.statusAbertoSelecionado && a.situacao === true;
    const isFechado = this.statusFechadoSelecionado && a.situacao=== false;
    return isAberto || isFechado;
  });
    switch (this.ordenacaoSelecionada) {
      case "nome":
        this.ordenarPorNome();
        break;
      case "data":
        this.ordenarPorData();
        break;
      default:
        break;
    }
    this.listaAux = this.listaAux.slice(0, this.pageSize);
  }

  onCheckboxChange() { }


}
