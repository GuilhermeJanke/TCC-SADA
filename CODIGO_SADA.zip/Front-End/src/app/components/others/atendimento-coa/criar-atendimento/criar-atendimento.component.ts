import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { AtendimentoCoa } from "../../../../../shared/models/atendimento-coa.model";
import { Aluno, AlunoService, CoaService, Professor, ProfessorService } from "../../../../../shared";
import { Router } from "@angular/router";


@Component({
  selector: "app-criar-atendimento",
  templateUrl: "./criar-atendimento.component.html",
  styleUrls: ["./criar-atendimento.component.scss"],
})
export class CriarAtendimentoComponent implements OnInit {
  @ViewChild("formCoa") formCoa!: NgForm;
  atendimentoCoa: AtendimentoCoa;
  alunos: Aluno[] = [];
  alunoSelecionado: Aluno;
  professores: Professor[] = [];
  professoresSelecionados: Professor[] = [];
  dataAtual: string;
  anexosSelecionados: File[] = [];

  constructor(
    private coaService: CoaService,
    private professorService: ProfessorService,
    private alunoService: AlunoService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.atendimentoCoa = new AtendimentoCoa();
    this.alunoSelecionado = new Aluno();
    this.dataAtual = new Date().toISOString().substring(0, 10);
    this.carregarAlunos();
    this.carregarProfessores();
  }

  carregarAlunos(): void {
    this.alunoService.listarAlunos().subscribe((alunos: Aluno[]) => {
      this.alunos = alunos;
    });
  }

  carregarProfessores(): void {
    this.professorService.listar().subscribe((professores: Professor[]) => {
      this.professores = professores;
    });
  }

  cadastrar(): void {
    if (this.formCoa.form.valid) {
      this.atendimentoCoa.aluno = this.alunoSelecionado; // Atribui o aluno selecionado ao atendimento
      let numP : Professor[] = [];
      this.professoresSelecionados.forEach(professor => {
          numP.push(professor)
      });
      this.atendimentoCoa.professor = numP; // Atribui os professores selecionados ao atendimento
      this.atendimentoCoa.situacao = true;
      // anexos, situacion
      this.coaService.cadastrar(this.atendimentoCoa, this.anexosSelecionados).subscribe((coa: AtendimentoCoa) => {
        // Lógica para tratamento de sucesso após cadastrar o atendimento
        this.router.navigate(["/coordenador/atendimento-coa/"]);
      });
    }
  }

  onAnexosSelecionados(event: any): void {
    this.anexosSelecionados = Array.from(event.target.files);
  }

}
