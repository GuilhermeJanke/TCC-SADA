import { Component, OnInit } from "@angular/core";

import { SomaEvasao } from "../../../../shared/models/retencao.model";
import { ArmazenarIdService, ChartService, HistoricoService } from "../../../../shared";

@Component({
  selector: "app-retencao",
  templateUrl: "./retencao.component.html",
  styleUrls: ["./retencao.component.scss"],
})
export class RetencaoComponent implements OnInit {
  id_curso = parseInt(this.armazenarIdService.getCursoID());
  somaEvasao: number = 0;
  somaTrancamento: number = 0;
  somaAtivos: number = 0;
  somaConclusao: number = 0;
  chartRetencaoModalidade: HTMLCanvasElement;
  chartRetencaoTurno: HTMLCanvasElement;
  chartRetencaoDisciplina: HTMLCanvasElement;
  constructor(private historicoService: HistoricoService, private chartService: ChartService, private armazenarIdService: ArmazenarIdService) { }

  ngOnInit(): void {
    this.buscaSomaEvasao();

    this.chartRetencaoModalidade = document.getElementById("chartRetencaoModalidade") as HTMLCanvasElement;
    this.chartService.chartRetencaoModalidade(this.chartRetencaoModalidade);

    this.chartRetencaoTurno = document.getElementById("chartRetencaoTurno") as HTMLCanvasElement;
    this.chartService.chartRetencaoTurno(this.chartRetencaoTurno);

    this.chartRetencaoDisciplina = document.getElementById("chartRetencaoDisciplina") as HTMLCanvasElement;
    this.chartService.chartRetencaoDisciplina(this.chartRetencaoDisciplina);
  }

  buscaSomaEvasao(): void {
    this.historicoService.buscarSomaEvasao(this.id_curso).subscribe(
      (somaEvasao: SomaEvasao[]) => {
        this.somaEvasao = somaEvasao[0]?.SomaEvasao || 0;
      },
      (error: any) => {
        console.error(error);
      }
    );

    this.historicoService.buscarSomaEvasao(this.id_curso).subscribe(
      (somaTrancamento: SomaEvasao[]) => {
        this.somaTrancamento = somaTrancamento[0]?.SomaTrancamento || 0;
      },
      (error: any) => {
        console.error(error);
      }
    );

    this.historicoService.buscarSomaEvasao(this.id_curso).subscribe(
      (somaAtivos: SomaEvasao[]) => {
        this.somaAtivos = somaAtivos[0]?.SomaRegistroAtivo || 0;
      },
      (error: any) => {
        console.error(error);
      }
    );

    this.historicoService.buscarSomaEvasao(this.id_curso).subscribe(
      (somaConclusao: SomaEvasao[]) => {
        this.somaConclusao = somaConclusao[0]?.SomaConclusaoFormatura || 0;
      },
      (error: any) => {
        console.error(error);
      }
    );
  }
}
