# Front-End

## Passos para executar o projeto:

* Clonar o repositório;

* Ter instalado o node e npm (v18: https://nodejs.org/en/download);
    * Verificar versão do Node instalado: $ node --version
    * Verificar versão do NPM instalado: $ npm --version

* Ter instalado Angular CLI: $ npm install -g @angular/cli

* Abrir o projeto na IDE VSCode (atalho code . em um terminal dentro da pasta do projeto);

* No terminal da IDE, dentro da pasta tcc-frontend, executar o comando: 
npm i  para instalar as dependências. (npm install --force se der erro);

* Executar o comando ng ou ng serve, para executar o projeto, ou ainda ng s -o para abrir direto no navegador após o build;

* Abrirá no navegador direto ou será gerado um link no terminal, para acessar o navegador.