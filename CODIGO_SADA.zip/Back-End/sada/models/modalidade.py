from django.db import models


#
# Modalidade
#
class Modalidade(models.Model):
    """
    Modelo de representação de uma Modalidade.
    """
    nome = models.CharField(max_length=200, unique=True)

