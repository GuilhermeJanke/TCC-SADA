from django.db import models


#
# Curso
#
class Curso(models.Model):
    """
    Modelo de representação de um Curso.
    """
    codigo = models.CharField(max_length=10, unique=True)
    nome = models.CharField(max_length=200, unique=True)
    sigla = models.CharField(max_length=10, unique=True)
    ch_semestre = models.IntegerField()
    ch_max_semeste = models.IntegerField()
    ch_total = models.IntegerField()
    ch_max = models.IntegerField()
    qtd_semestres = models.IntegerField()
    qtd_max_semestres = models.IntegerField()
    ch_disciplinas_obrigatorias = models.IntegerField()
    ch_disciplinas_optativas = models.IntegerField()

    class Meta:
        ordering = ['nome']

    def __str__(self):
        return self.nome

