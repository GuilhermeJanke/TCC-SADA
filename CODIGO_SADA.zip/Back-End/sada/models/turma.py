from django.db import models

from sada.models.curso import Curso
from sada.models.professor import Professor
from sada.models.disciplina import Disciplina

#
# Turma
#
class Turma(models.Model):
    """
    Modelo de representação de uma Turma.
    """
    nome = models.CharField(max_length=200)
    departamento = models.CharField(max_length=200)
    ano = models.CharField(max_length=4)
    periodo = models.CharField(max_length=30)
    turno = models.CharField(max_length=30)
    ### Foreign Key ###
    disciplina = models.ForeignKey(Disciplina, on_delete=models.PROTECT)
    professor = models.ForeignKey(Professor, on_delete=models.PROTECT)
    curso = models.ForeignKey(Curso, on_delete=models.PROTECT)

