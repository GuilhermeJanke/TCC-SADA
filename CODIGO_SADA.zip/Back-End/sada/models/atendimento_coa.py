from django.db import models

from sada.models.aluno import Aluno
from sada.models.professor import Professor


#
# AtendimentoCOA
#
class AtendimentoCOA(models.Model):
    """
    Modelo de representação de um AtendimentoCOA.
    """
    descricao = models.CharField(max_length=500)
    data_atendimento = models.DateField()
    situacao = models.BooleanField()
    anexo = models.FileField(upload_to='')
    ### Foreign Key ###
    aluno = models.ForeignKey(Aluno, on_delete=models.PROTECT, null=True, related_name='atendimentos_coa')
    professor = models.ManyToManyField(Professor, related_name='professor', blank=True)

    def __str__(self):
        return self.descricao

