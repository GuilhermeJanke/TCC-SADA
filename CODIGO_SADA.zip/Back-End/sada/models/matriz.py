from django.db import models

from sada.models.curso import Curso
from sada.models.modalidade import Modalidade
from sada.models.disciplina import Disciplina


#
# MatrizCurricular
#
class MatrizCurricular(models.Model):
    """
    Modelo de representação de uma MatrizCurricular.
    """
    curriculo = models.CharField(max_length=200)
    ano_versao = models.CharField(max_length=4)
    departamento = models.CharField(max_length=200)
    ### Foreign Key ###
    disciplina = models.ManyToManyField(Disciplina, blank=True)
    modalidade = models.ManyToManyField(Modalidade, related_name='modalidade', blank=True)
    curso = models.ForeignKey(Curso, on_delete=models.PROTECT)

