from sada.models.pessoa import Pessoa


#
# Professor
#
class Professor(Pessoa):
    """
    Modelo de representação de um Professor.
    """
    def __str__(self):
        return self.nome

