from django.db import models

from sada.models.aluno import Aluno
from sada.models.disciplina import Disciplina
from sada.models.turma import Turma


#
# HistoricoEscolar
#
class HistoricoEscolar(models.Model):
    """
    Modelo de representação de um HistoricoEscolar.
    """
    periodo = models.CharField(max_length=30)
    ano = models.CharField(max_length=4)
    data_atualizacao = models.DateTimeField()
    ch = models.IntegerField()
    nota = models.FloatField()
    frequencia = models.FloatField()
    status = models.CharField(max_length=50)
    tipo = models.CharField(max_length=20)
    observacao = models.CharField(max_length=500)
    natureza = models.CharField(max_length=50)
    situacao_aluno = models.CharField(max_length=20)
    curriculo_atual = models.CharField(max_length=5)
    ### Foreign Key ###
    aluno = models.ForeignKey(Aluno, on_delete=models.PROTECT)
    disciplina = models.ForeignKey(Disciplina, on_delete=models.PROTECT)
    turma = models.ForeignKey(Turma, on_delete=models.PROTECT)
