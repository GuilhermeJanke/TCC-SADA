from django.db import models

from sada.models.curso import Curso


#
# Pessoa
#
class Pessoa(models.Model):
    """
    Modelo de representação de uma Pessoa.
    """
    nome = models.CharField(max_length=80)
    cpf = models.CharField(max_length=14)
    email = models.EmailField()
    telefone = models.CharField(max_length=30)
    ### Foreign Key ###
    curso = models.ManyToManyField(Curso, related_name='curso', blank=True)

    def to_dict(self):
        curso = list(self.curso.values('id', 'codigo', 'nome', 'sigla', 'ch_semestre', 'ch_max_semeste', 'ch_total', 'ch_max', 'qtd_semestres', 'qtd_max_semestres'))

        return {
            'id': self.id,
            'nome': self.nome,
            'cpf': self.cpf,
            'email': self.email,
            'curso': curso,
            'telefone': self.telefone
        }

    def __str__(self):
        return self.nome

