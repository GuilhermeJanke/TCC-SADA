from django.contrib.auth.hashers import make_password
from django.db import models

from sada.models.pessoa import Pessoa
from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver
from django.contrib.auth.models import User


#
# Usuario
#
class Usuario(Pessoa):
    """
    Modelo de representação de um Usuario.
    """
    senha = models.CharField(max_length=255)
    tipo = models.CharField(max_length=25)

    def to_dict(self):
        data = super().to_dict()
        data.update({
            'senha': self.senha,
            'tipo': self.tipo
        })
        return data

    def save(self, *args, **kwargs):
        # Criptografa a senha antes de salvar
        self.senha = make_password(self.senha)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nome

@receiver(post_save, sender=Usuario)
def create_django_user(sender, instance, created, **kwargs):
    if created:
        # Cria uma instância do modelo de usuário do Django
        django_user = User.objects.create(
            username=instance.cpf, 
            password=instance.senha
        )

@receiver(pre_delete, sender=Usuario)
def delete_django_user(sender, instance, **kwargs):
    # Busca a instância do modelo de usuário do Django correspondente
    django_user = User.objects.filter(
        username=instance.cpf, 
        password=instance.senha
    ).first()
    
    if django_user:
        # Exclui a instância do modelo de usuário do Django
        django_user.delete()

