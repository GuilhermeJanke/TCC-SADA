from django.db import models
from django.db import connection
from rest_framework.response import Response

from sada.models.pessoa import Pessoa


#
# Aluno
#
class Aluno(Pessoa):
    """
    Modelo de representação de um Aluno.
    """
    grr = models.CharField(max_length=20, unique=True)
    ch_integralizada = models.IntegerField(blank=True, null=True)
    periodo_atual = models.IntegerField(blank=True, null=True)
    potencial_retencao = models.CharField(max_length=20, blank=True, null=True)
    potencial_evasao = models.CharField(max_length=40, blank=True, null=True)
    potencial_jubilamento = models.CharField(max_length=20, blank=True, null=True)
    ira = models.FloatField(blank=True, null=True)
    total_disciplinas_aprovadas = models.FloatField(blank=True, null=True)
    total_disciplinas_repovada_freq = models.FloatField(blank=True, null=True)
    total_disciplinas_repovada_nota = models.FloatField(blank=True, null=True)
    total_disciplinas_canceladas = models.FloatField(blank=True, null=True)
    curriculo_aluno = models.CharField(max_length=5)

    def __str__(self):
        return self.nome
    
    def calcular_carga_horaria_integralizada(self):
        with connection.cursor() as cursor:
            sql = """
                SELECT SUM(ch) AS carga_horaria_integralizada
                FROM sada_historicoescolar
                WHERE aluno_id = %s AND status = 'Aprovado'
            """
            cursor.execute(sql, [self.id])
            result = cursor.fetchone()

        return result[0] or 0

    def calcular_periodo_atual(self, id_curso):
        periodo_atual = 1
        
        with connection.cursor() as cursor:
            while True:
                total_disciplinas_sql = """
                    SELECT COUNT(*) AS total_disciplinas
                    FROM sada_disciplina d
                    JOIN sada_matrizcurricular_disciplina md ON d.id = md.disciplina_id
                    JOIN sada_matrizcurricular m ON md.matrizcurricular_id = m.id
                    JOIN sada_aluno a ON m.id = a.curriculo_aluno
                    WHERE d.periodo = %s AND a.pessoa_ptr_id = %s;
                """
                cursor.execute(total_disciplinas_sql, [str(periodo_atual), self.id])
                total_disciplinas = cursor.fetchone()[0]

                disciplinas_vencidas_sql = """
                    SELECT COUNT(*) AS disciplinas_vencidas
                    FROM sada_historicoescolar AS he
                    INNER JOIN sada_disciplina AS d ON he.disciplina_id = d.id
                    WHERE he.aluno_id = %s AND he.status = 'Aprovado' 
                        AND d.periodo = %s AND d.curso_id = %s
                """
                cursor.execute(disciplinas_vencidas_sql, [self.id, str(periodo_atual), id_curso])
                disciplinas_vencidas = cursor.fetchone()[0]

                if total_disciplinas == 0 or (disciplinas_vencidas / total_disciplinas) <= 0.5:
                    break

                periodo_atual += 1

        return periodo_atual

    def calcular_potencial_jubilamento(self):
        # Obter as informações do curso
        curso = self.curso.first()
        if not curso:
            return "Curso não encontrado"

        ch_max = curso.ch_max_semeste
        qtd_max_semestres = curso.qtd_max_semestres
        ch_total = curso.ch_total

        # Obter a carga horária integralizada do aluno
        if self.ch_integralizada is None:
            return "Carga horária integralizada não encontrada"

        # Calcular o número de semestres cursados
        semestres_cursados = self.calculo_semestres_cursados()
        if semestres_cursados is None:
            return "Não foi possível calcular o número de semestres cursados"

        # Verificar se o denominador é igual a zero
        if (ch_total - self.ch_integralizada) == 0:
            return -1

        # Calcular o índice jubilamento
        indice_jubilamento = (ch_max * (qtd_max_semestres - semestres_cursados)) / (ch_total - self.ch_integralizada)

        if 1 <= indice_jubilamento < 1.11:
            potencial_jubilamento = "ALTO_RISCO"
        elif 1.11 <= indice_jubilamento < 1.22:
            potencial_jubilamento = "MEDIO_RISCO"
        elif indice_jubilamento >= 1.22:
            potencial_jubilamento = "BAIXO_RISCO"
        elif indice_jubilamento < 1:
            potencial_jubilamento = "JUBILADO"

        return potencial_jubilamento

    def calcular_potencial_retencao(self):
        # Obter as informações do curso
        curso = self.curso.first()
        if not curso:
            return Response({'detail': 'Curso não encontrado'})
        ch_max = curso.ch_max_semeste
        qtd_semestres = curso.qtd_semestres
        ch_total = curso.ch_total

        # Obter a carga horária integralizada do aluno

        if self.ch_integralizada is None:
            return Response({'detail': 'Carga horária integralizada não encontrada'})

        # Calcular o número de semestres cursados
        semestres_cursados = self.calculo_semestres_cursados()
        if semestres_cursados is None:
            return Response({'detail': 'Não foi possível calcular o número de semestres cursados'})

        # Calcular o índice de retenção
        indice_retencao = (ch_max * (qtd_semestres - semestres_cursados)) - (ch_total - self.ch_integralizada)

        potencial_retencao = ""

        if 0 <= indice_retencao <= 30:
            potencial_retencao = "ALTO_RISCO"
        elif 30 < indice_retencao <= 60:
            potencial_retencao = "MEDIO_RISCO"
        elif indice_retencao > 60:
            potencial_retencao = "BAIXO_RISCO"
        elif indice_retencao < 0:
            potencial_retencao = "RETIDO"

        return potencial_retencao

    def obter_semestre_anterior(self):
        with connection.cursor() as cursor:
            # Consulta para obter o maior ano do aluno
            cursor.execute("""
                SELECT MAX(ano) AS maior_ano
                FROM sada_historicoescolar
                WHERE aluno_id = %s
            """, [self.id])

            result = cursor.fetchone()
            maior_ano = result[0]

            # Verificar se possui os períodos "1° Semestre" e "2° Semestre" no maior ano
            cursor.execute("""
                SELECT periodo
                FROM sada_historicoescolar
                WHERE aluno_id = %s AND ano = %s AND periodo IN ('1° Semestre', '2° Semestre')
            """, [self.id, maior_ano])

            result = cursor.fetchall()
            periodos = [row[0] for row in result]

            # Retornar o maior ano e o período "1° Semestre" ou o ano anterior e o período "2° Semestre"
            if '1° Semestre' in periodos and '2° Semestre' in periodos:
                semestre_anterior = (int(maior_ano), '1° Semestre')
            elif '1° Semestre' in periodos:
                semestre_anterior = (int(maior_ano) - 1, '2° Semestre')
            else:
                semestre_anterior = (None, None)

            # Consulta para obter a quantidade de disciplinas cursadas no semestre anterior
            if semestre_anterior[0] and semestre_anterior[1]:
                cursor.execute("""
                    SELECT COUNT(*) AS quantidade_disciplinas
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND ano = %s AND periodo = %s
                """, (self.id, semestre_anterior[0], semestre_anterior[1]))

                result = cursor.fetchone()
                quantidade_disciplinas = result[0]
            else:
                semestre_anterior = (None, None)
                quantidade_disciplinas = 0

            return semestre_anterior[0], semestre_anterior[1], quantidade_disciplinas

    def disciplinas_aprovadas(self):
        quantidade_aprovadas = 0

        # Obter o semestre anterior e a quantidade de disciplinas cursadas
        ano_semestre_anterior, periodo_semestre_anterior, quantidade_disciplinas = self.obter_semestre_anterior()

        if ano_semestre_anterior and periodo_semestre_anterior:
            with connection.cursor() as cursor:
                # Consulta para obter a quantidade de disciplinas aprovadas no semestre anterior
                cursor.execute("""
                    SELECT COUNT(*) AS quantidade_aprovadas
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND ano = %s AND periodo = %s AND status = 'Aprovado'
                """, [self.id, ano_semestre_anterior, periodo_semestre_anterior])

                result = cursor.fetchone()
                quantidade_aprovadas = result[0]
        else:
            quantidade_aprovadas = 0
        return quantidade_aprovadas

    def disciplinas_reprovadas(self):
        quantidade_reprovadas = 0

        # Obter o semestre anterior e a quantidade de disciplinas cursadas
        ano_semestre_anterior, periodo_semestre_anterior, quantidade_disciplinas = self.obter_semestre_anterior()

        if ano_semestre_anterior and periodo_semestre_anterior:
            with connection.cursor() as cursor:
                # Consulta para obter a quantidade de disciplinas reprovadas no semestre anterior
                cursor.execute("""
                    SELECT COUNT(*) AS quantidade_reprovadas
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND ano = %s AND periodo = %s AND (status = 'Reprovado por nota' OR status = 'Reprovado por frequência')
                """, [self.id, ano_semestre_anterior, periodo_semestre_anterior])

                result = cursor.fetchone()
                quantidade_reprovadas = result[0]
        else:
            quantidade_reprovadas = 0
        return quantidade_reprovadas

    def disciplinas_reprovadas_frequencia(self):
        quantidade_reprovadas_frequencia = 0
        ano_semestre_anterior = 0
        periodo_semestre_anterior = 0
        quantidade_disciplinas = 0

        # Obter o semestre anterior e a quantidade de disciplinas cursadas
        ano_semestre_anterior, periodo_semestre_anterior, quantidade_disciplinas = self.obter_semestre_anterior()

        if ano_semestre_anterior and periodo_semestre_anterior:
            with connection.cursor() as cursor:
                # Consulta para obter a quantidade de disciplinas reprovadas por frequencia no semestre anterior
                cursor.execute("""
                    SELECT COUNT(*) AS quantidade_reprovadas_frequencia
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND ano = %s AND periodo = %s AND status = 'Reprovado por frequência'
                """, [self.id, ano_semestre_anterior, periodo_semestre_anterior])

                result = cursor.fetchone()
                quantidade_reprovadas_frequencia = result[0]
        else:
            quantidade_reprovadas_frequencia = 0
        return quantidade_reprovadas_frequencia

    def calcular_soma_carga_horaria(self):
        soma_carga_horaria = 0

        # Obter o semestre anterior e a quantidade de disciplinas cursadas
        ano_semestre_anterior, periodo_semestre_anterior, quantidade_disciplinas = self.obter_semestre_anterior()

        if ano_semestre_anterior and periodo_semestre_anterior:
            with connection.cursor() as cursor:
                # Consulta para calcular a soma da carga horária do semestre anterior
                cursor.execute("""
                    SELECT SUM(ch) AS soma_carga_horaria
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND ano = %s AND periodo = %s
                """, [self.id, ano_semestre_anterior, periodo_semestre_anterior])

                result = cursor.fetchone()
                soma_carga_horaria = result[0] or 0
        else:
            soma_carga_horaria = 0
        return soma_carga_horaria

    def calcular_potencial_evasao(self):
        potencial_evasao = 'BAIXO_RISCO'

        # Obter as informações do curso
        curso = self.curso.first()
        if not curso:
            return 'Curso não encontrado'
        ch_min = curso.ch_semestre

        # Obter as informações do semestre anterior
        ano_semestre_anterior, periodo_semestre_anterior, quantidade_disciplinas = self.obter_semestre_anterior()

        if not ano_semestre_anterior or not periodo_semestre_anterior:
            return 'EVADIDO_OU_CALOURO'

        # Calcular a quantidade de disciplinas aprovadas
        quantidade_aprovadas = self.disciplinas_aprovadas()

        # Calcular a soma da carga horária do semestre anterior
        soma_carga_horaria = self.calcular_soma_carga_horaria()

        # Calcular o índice de evasão
        if quantidade_disciplinas != 0:
            indice_evasao = (2 * (quantidade_disciplinas - quantidade_aprovadas)) / quantidade_disciplinas
        else:
            indice_evasao = 0        # Calcular a quantidade de disciplinas reprovadas por frequência
        quantidade_reprovada_frequencia = self.disciplinas_reprovadas_frequencia()

        # Calcular a quantidade de disciplinas reprovadas
        quantidade_reprovada = self.disciplinas_reprovadas()

        # Cálculo do potencial de evasão

        if (quantidade_disciplinas > 0) or \
                (soma_carga_horaria == ch_min and quantidade_reprovada_frequencia == 2) or \
                (soma_carga_horaria == ch_min and indice_evasao == 1) or \
                (indice_evasao == 1 and quantidade_reprovada_frequencia == 2) or \
                (quantidade_reprovada > 2 or indice_evasao > 1):
            potencial_evasao = 'ALTO_RISCO'
        elif indice_evasao == 1:
            potencial_evasao = 'MEDIO_RISCO'
        elif indice_evasao == 0:
            potencial_evasao = 'EVADIDO_OU_CALOURO'
        else:
            potencial_evasao = 'BAIXO_RISCO'

        return potencial_evasao

    def obter_data_semestre_x(self):
        # Consulta ao banco de dados para obter a data_atualizacao para cada aluno_id
        with connection.cursor() as cursor:
            cursor.execute("SELECT DISTINCT aluno_id, data_atualizacao FROM sada_historicoescolar")
            results = cursor.fetchall()

        datas_por_aluno = {}

        for row in results:
            aluno_id = row[0]
            data_atualizacao = row[1]

            # Obtém o ano e o mês da data_atualizacao
            ano_x = data_atualizacao.date().year
            mes_x = data_atualizacao.date().month

            semestre_x = 1 if mes_x <= 6 else 2

            # Armazena a data_atualizacao para cada aluno_id
            datas_por_aluno[aluno_id] = {"ano": int(ano_x), "semestre": int(semestre_x)}

        return datas_por_aluno

    def calculo_semestres_cursados(self):
        # Obter o ano e semestre de entrada do aluno
        ano_semestre_entrada = self.calcular_ano_semestre_entrada()

        if ano_semestre_entrada is None:
            return None

        # Obter o ano e semestre atual
        data_semestre_x = self.obter_data_semestre_x()
        aluno_data = data_semestre_x.get(self.id)
        if aluno_data is None:
            return None

        ano_x = aluno_data["ano"]
        semestre_x = aluno_data["semestre"]

        # Calcular o número de semestres cursados
        semestres_cursados = (ano_x - ano_semestre_entrada['ano_entrada']) * 2
        semestres_cursados += semestre_x - ano_semestre_entrada['semestre_entrada']

        return semestres_cursados

    def calcular_ano_semestre_entrada(self):
        # Consulta ao banco de dados para obter o menor ano e período do aluno
        with connection.cursor() as cursor:
            cursor.execute("SELECT MIN(ano) AS menor_ano, MIN(periodo) AS semestre_entrada "
                           "FROM sada_historicoescolar "
                           "WHERE aluno_id = %s", [self.id])
            result = cursor.fetchone()

        resultados = {}
        if result:
            ano_entrada = result[0]
            semestre_entrada = result[1]

            if semestre_entrada.startswith('1° Semestre'):
                semestre_entrada = 1
            else:
                semestre_entrada = 2

            resultados = {
                'ano_entrada': int(ano_entrada),
                'semestre_entrada': semestre_entrada,
            }
        else:
            resultados = {
                'ano_entrada': 0,
                'semestre_entrada': 0,
            }
        return resultados
    #Cálculo do ira
    from decimal import Decimal

    def calcular_ira(self):
        with connection.cursor() as cursor:
            # Obter os somatórios de (ch * nota) e ch
            sql = """
                SELECT SUM(ch * nota) AS soma_ch_nota, SUM(ch) AS soma_ch
                FROM sada_historicoescolar
                WHERE aluno_id = %s AND status NOT IN ('Cancelado', 'Matriculado') AND tipo NOT IN ('EQUIVALENCIA')
            """
            cursor.execute(sql, [self.id])
            result = cursor.fetchone()

            soma_ch_nota = float(result[0] or 0)
            soma_ch = float(result[1] or 1)  # Tratamento para evitar divisão por zero

            # Calcular o IRA
            ira = (soma_ch_nota / soma_ch)/100

        return ira

    def calcular_total_disciplinas(self):

        with connection.cursor() as cursor:
            sql = """
                SELECT COUNT(*) AS total_disciplinas
                FROM sada_historicoescolar
                WHERE aluno_id = %s AND status NOT IN ('Matriculado')
            """
            cursor.execute(sql, [self.id])
            result = cursor.fetchone()

        return result[0] or 0

    def calcular_total_disciplinas_aprovadas(self):
        total_disciplinas = self.calcular_total_disciplinas()  # Call the calcular_total_disciplinas method
        total_disciplinas_aprovadas = 0

        if total_disciplinas > 0:
            with connection.cursor() as cursor:
                sql = """
                    SELECT COUNT(*) AS total_disciplinas_aprovadas
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND status = 'Aprovado'
                """
                cursor.execute(sql, [self.id])
                result = cursor.fetchone()
                total_disciplinas_aprovadas = result[0] or 0

        # Calculate the percentage
        if total_disciplinas == 0:
            percentage = 0
        else:
            percentage = (total_disciplinas_aprovadas * 100) / total_disciplinas

        return percentage

    def calcular_total_disciplinas_reprovadas_freq(self):
        total_disciplinas = self.calcular_total_disciplinas()  # Call the calcular_total_disciplinas method
        total_disciplinas_reprovadas_freq = 0

        if total_disciplinas > 0:
            with connection.cursor() as cursor:
                sql = """
                    SELECT COUNT(*) AS total_disciplinas_reprovadas_freq
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND status = 'Reprovado por frequência'
                """
                cursor.execute(sql, [self.id])
                result = cursor.fetchone()
                total_disciplinas_reprovadas_freq = result[0] or 0

        # Calculate the percentage
        if total_disciplinas == 0:
            percentage = 0
        else:
            percentage = (total_disciplinas_reprovadas_freq * 100) / total_disciplinas

        return percentage

    def calcular_total_disciplinas_reprovadas_nota(self):
        total_disciplinas = self.calcular_total_disciplinas()  # Call the calcular_total_disciplinas method
        total_disciplinas_reprovadas_nota = 0

        if total_disciplinas > 0:
            with connection.cursor() as cursor:
                sql = """
                    SELECT COUNT(*) AS total_disciplinas_reprovadas_nota
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND status = 'Reprovado por nota'
                """
                cursor.execute(sql, [self.id])
                result = cursor.fetchone()
                total_disciplinas_reprovadas_nota = result[0] or 0

        # Calculate the percentage
        if total_disciplinas == 0:
            percentage = 0
        else:
            percentage = (total_disciplinas_reprovadas_nota * 100) / total_disciplinas

        return percentage

    def calcular_total_disciplinas_cancelada(self):
        total_disciplinas = self.calcular_total_disciplinas()  # Call the calcular_total_disciplinas method
        total_disciplinas_cancelada = 0

        if total_disciplinas > 0:
            with connection.cursor() as cursor:
                sql = """
                    SELECT COUNT(*) AS total_disciplinas_cancelada
                    FROM sada_historicoescolar
                    WHERE aluno_id = %s AND status = 'Cancelado'
                """
                cursor.execute(sql, [self.id])
                result = cursor.fetchone()
                total_disciplinas_cancelada = result[0] or 0

        # Calculate the percentage
        if total_disciplinas == 0:
            percentage = 0
        else:
            percentage = (total_disciplinas_cancelada * 100) / total_disciplinas

        return percentage




