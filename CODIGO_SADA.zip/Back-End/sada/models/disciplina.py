from django.db import models

from sada.models.curso import Curso
from sada.models.modalidade import Modalidade


#
# Disciplina
#
class Disciplina(models.Model):
    """
    Modelo de representação de uma Disciplina.
    """
    codigo = models.CharField(max_length=10, unique=True)
    nome = models.CharField(max_length=200)
    periodo = models.CharField(max_length=200)
    natureza = models.CharField(max_length=200)
    ch = models.IntegerField()
    ch_semanal = models.IntegerField()
    ch_EAD = models.IntegerField()
    ch_campo = models.IntegerField()
    ch_estagio = models.IntegerField()
    ch_estagio_pedagogico = models.IntegerField()
    ch_extensao = models.IntegerField()
    ch_laboratorio = models.IntegerField()
    ch_orientada = models.IntegerField()
    ch_padrao = models.IntegerField()
    ch_pratica_especifica = models.IntegerField()
    ### Foreign Key ###
    pre_requisito = models.ManyToManyField('self', blank=True)
    modalidade = models.ForeignKey(Modalidade, on_delete=models.SET_NULL, null=True, blank=True)
    curso = models.ForeignKey(Curso, on_delete=models.PROTECT)

