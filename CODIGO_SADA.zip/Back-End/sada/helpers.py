from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.permissions import BasePermission
import pandas as pd


#
# Helpers
#
class PostAuthenticatedPermission(IsAuthenticated):
    def has_permission(self, request, view):
        if request.method == 'POST':
            return True
        if view.action == 'buscar_por_cpf':
            return True
        if view.action == 'enviar_email_nova_senha':
            return True
        if request.method in ['PATCH', 'PUT']:
            return True
        return super().has_permission(request, view)



def ler_arquivos(arquivos: any, colunas_esperadas: list[str]):
    # Criar uma lista vazia para armazenar os DataFrames
    dataframes = []

    # Iterar sobre cada arquivo e ler os dados em um DataFrame
    for arquivo in arquivos:
        # Verificar a extensão do arquivo
        if arquivo.name.endswith('.xlsx'):
            # Ler o arquivo Excel usando a biblioteca Pandas
            df = pd.read_excel(arquivo)
        elif arquivo.name.endswith('.csv'):
            # Ler o arquivo CSV usando a biblioteca Pandas
            df = pd.read_csv(arquivo, sep=',')
        else:
            return Response(
                {'error': 'Tipo de arquivo inválido. Por favor envie um arquivo Excel (.xlsx) ou um arquivo CSV.'},
                status=status.HTTP_400_BAD_REQUEST)

        # Verificar se as colunas esperadas estão presentes
        colunas_presentes = list(df.columns)
        if not set(colunas_esperadas).issubset(set(colunas_presentes)):
            colunas_faltando = set(colunas_esperadas) - set(colunas_presentes)
            return Response({
                                'error': f'O cabeçalho do arquivo está incorreto. As colunas esperadas são: {", ".join(colunas_esperadas)}. As seguintes colunas estão faltando: {", ".join(colunas_faltando)}.'},
                            status=status.HTTP_400_BAD_REQUEST)

        # Adicionar o DataFrame à lista
        dataframes.append(df)

    # Concatenar os DataFrames em um único DataFrame e retornar
    return pd.concat(dataframes)

