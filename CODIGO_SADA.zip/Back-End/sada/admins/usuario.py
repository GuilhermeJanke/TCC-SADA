from django.contrib import admin

from sada.models.usuario import Usuario


#
# Usuario
#
class Usuarios(admin.ModelAdmin):
    """
    Classe admnistrativa para Usuarios
    """
    list_display = ('id', 'nome', 'cpf', 'email', 'telefone', 'tipo')
    list_display_links = ('id', 'nome')
    search_fields = ('nome',)

admin.site.register(Usuario, Usuarios)
