from django.contrib import admin

from sada.models.matriz import MatrizCurricular


#
# MatrizCurricular
#
class MatrizesCurriculares(admin.ModelAdmin):
    """
    Classe admnistrativa para MatrizesCurriculares
    """
    list_display = ('id', 'curriculo', 'ano_versao', 'departamento')
    list_display_links = ('id',)
    search_fields = ('id', 'ano_versao')

admin.site.register(MatrizCurricular, MatrizesCurriculares)
