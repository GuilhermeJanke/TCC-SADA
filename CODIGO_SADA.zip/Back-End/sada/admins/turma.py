from django.contrib import admin

from sada.models.turma import Turma


#
# Turma
#
class Turmas(admin.ModelAdmin):
    """
    Classe admnistrativa para Turmas
    """
    list_display = ('id', 'nome', 'departamento', 'ano', 'periodo', 'disciplina', 'turno', 'professor')
    list_display_links = ('id', 'nome')
    search_fields = ('nome',)

admin.site.register(Turma, Turmas)
