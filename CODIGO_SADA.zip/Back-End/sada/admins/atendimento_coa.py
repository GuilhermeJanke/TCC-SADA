from django.contrib import admin

from sada.models.atendimento_coa import AtendimentoCOA


#
# AtendimentoCOA
#
class AtendimentosCOA(admin.ModelAdmin):
    """
    Classe admnistrativa para AtendimentosCOA
    """
    list_display = ('id', 'descricao', 'data_atendimento', 'situacao', 'anexo')
    list_display_links = ('id',)
    search_fields = ('data_atendimento',)

admin.site.register(AtendimentoCOA, AtendimentosCOA)
