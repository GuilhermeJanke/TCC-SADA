from django.contrib import admin

from sada.models.professor import Professor


#
# Professor
#
class Professores(admin.ModelAdmin):
    """
    Classe admnistrativa para Professores
    """
    list_display = ('id', 'nome', 'cpf', 'email', 'telefone')
    list_display_links = ('id', 'nome')
    search_fields = ('nome',)

admin.site.register(Professor, Professores)
