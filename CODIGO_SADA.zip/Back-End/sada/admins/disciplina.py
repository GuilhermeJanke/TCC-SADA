from django.contrib import admin

from sada.models.disciplina import Disciplina


#
# Disciplina
#
class Disciplinas(admin.ModelAdmin):
    """
    Classe admnistrativa para Disciplinas
    """
    list_display = ('id', 'codigo', 'nome', 'periodo', 'natureza', 'ch', 'ch_semanal', 'ch_EAD', 'ch_campo',
    'ch_estagio', 'ch_estagio_pedagogico', 'ch_extensao', 'ch_laboratorio', 'ch_orientada', 'ch_padrao', 'ch_pratica_especifica')
    list_display_links = ('id', 'nome')
    search_fields = ('nome',)

admin.site.register(Disciplina, Disciplinas)
