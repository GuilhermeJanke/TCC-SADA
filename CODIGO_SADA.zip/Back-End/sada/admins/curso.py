from django.contrib import admin

from sada.models.curso import Curso

#
# Curso
#
class Cursos(admin.ModelAdmin):
    """
    Classe admnistrativa para Cursos
    """
    list_display = ('id', 'codigo', 'nome', 'sigla', 'ch_semestre', 'ch_max_semeste', 'ch_total', 'ch_max', 'qtd_semestres', 'qtd_max_semestres')
    list_display_links = ('id', 'nome')
    search_fields = ('nome',)

admin.site.register(Curso, Cursos)
