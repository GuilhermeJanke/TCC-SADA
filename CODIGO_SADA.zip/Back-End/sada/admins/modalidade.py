from django.contrib import admin

from sada.models.modalidade import Modalidade


#
# Modalidade
#
class Modalidades(admin.ModelAdmin):
    """
    Classe admnistrativa para Modalidades
    """
    list_display = ('id', 'nome')
    list_display_links = ('id', 'nome')
    search_fields = ('nome',)

admin.site.register(Modalidade, Modalidades)
