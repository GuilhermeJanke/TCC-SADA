from django.contrib import admin

from sada.models.aluno import Aluno


#
# Aluno
#
class Alunos(admin.ModelAdmin):
    """
    Classe admnistrativa para Alunos
    """
    list_display = ('id', 'nome', 'cpf', 'email', 'grr', 'telefone', 'curriculo_aluno')
    list_display_links = ('id', 'nome')
    search_fields = ('nome',)

admin.site.register(Aluno, Alunos)
