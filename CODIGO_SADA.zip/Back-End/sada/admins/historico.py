from django.contrib import admin

from sada.models.historico import HistoricoEscolar


#
# HistoricoEscolar
#
class HistoricosEscolares(admin.ModelAdmin):
    """
    Classe admnistrativa para HistoricosEscolares
    """
    list_display = ('id', 'periodo', 'ano', 'data_atualizacao', 'ch', 'nota', 'frequencia', 'status', 'tipo', 'observacao', 'natureza', 'situacao_aluno', 
    'aluno', 'disciplina', 'turma', 'curriculo_atual')
    list_display_links = ('id',)
    search_fields = ('id',)

admin.site.register(HistoricoEscolar, HistoricosEscolares)
