from rest_framework import viewsets
from rest_framework.response import Response

from sada.models.curso import Curso
from sada.models.disciplina import Disciplina
from sada.models.professor import Professor
from sada.models.turma import Turma
from sada.serializers.turma import TurmaSerializer

from sada.helpers import ler_arquivos

import pandas as pd
from django.db import connection


#
# Turma
#
class TurmaViewSet(viewsets.ModelViewSet):
    """
    Classe de view para Turma
    """
    queryset = Turma.objects.all()
    serializer_class = TurmaSerializer

    def create(self, request, *args, **kwargs):
        if 'file' in request.FILES:
            # Obter a lista de arquivos enviados através da requisição
            arquivos = request.FILES.getlist('file')

            # Definir as colunas esperadas
            colunas_esperadas = [
                'Coordenação', 'Departamento', 'Código disciplina', 'Nome disciplina',
                'Nome turma', 'Ano', 'Docente', 'Turno', 'Período'
            ]

            # Receber o DataFrame
            dataframe_final = ler_arquivos(arquivos, colunas_esperadas)

            # Receber o curso vindo do Front
            id_curso = request.query_params.get('id_curso', None)
            curso = Curso.objects.filter(id=id_curso)

            if curso is not None:
                id_curso = curso[0].id
            else:
                return Response({'message': 'Curso expecificado não foi encontrado.'})

            if type(dataframe_final) == pd.DataFrame:
                # Iterar sobre as linhas do DataFrame e criar objetos Turma
                for indice, linha in dataframe_final.iterrows():
                    # Pegar a disciplina e curso ou ir para a próxima linha caso não existam
                    try:
                        disciplina = Disciplina.objects.get(codigo=linha['Código disciplina'])
                        curso = Curso.objects.get(nome=linha['Coordenação'])
                    except Exception:
                        continue

                    # Pegar o professor ou criar um caso não exista
                    try:
                        professor = Professor.objects.get(nome=linha['Docente'])
                        # ele pode pegar vários professores com aquele nome
                        # já que o nome do professor não é unique
                        # então deve-se fazer um tratamento para quando pegar mais de um
                        # atualmente se pegar mais de um ele passa reto e pode dar erro na criação de turma
                    except Professor.DoesNotExist:
                        professor = Professor.objects.create(
                            nome=linha['Docente']
                        )

                        # Adicionar o curso ao professor
                        professor.curso.add(id_curso)

                    # Criar um novo objeto Turma
                    turma = Turma(
                        nome=linha['Nome turma'],
                        departamento=linha['Departamento'],
                        ano=linha['Ano'],
                        periodo=linha['Período'],
                        turno=linha['Turno'],
                        disciplina=disciplina,
                        professor=professor,
                        curso=curso
                    )

                    # Salvar cada turma
                    turma.save()

                # Retornar uma resposta de sucesso
                return Response({'message': 'Dados salvos com sucesso!'})
            else:
                return dataframe_final
        else:
            # Chamar o método create da classe pai para salvar os objetos Turma normalmente
            return super().create(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        id = request.query_params.get('id', None)
        id_curso = request.query_params.get('id_curso', None)
        turnos = request.query_params.get('turnos', None)
        quartil = request.query_params.get('quartil', None)
        selectedTurma = request.query_params.get('selectedTurma', None)
        selectedDisciplina = request.query_params.get('selectedDisciplina', None)
        selectedModalidade = request.query_params.get('selectedModalidade', None)
        selectedTurno = request.query_params.get('selectedTurno', None)
        selectedAno = request.query_params.get('selectedAno', None)
        selectedProfessor = request.query_params.get('selectedProfessor', None)

        if id is not None:
            queryset = queryset.filter(id=id)

        if turnos is not None and id_curso is not None:
            return self.get_turnos(id_curso)

        if id_curso is not None:
            queryset = queryset.filter(curso=id_curso)
        
        if selectedTurma is not None and \
           selectedTurno is not None and \
           selectedAno is not None and \
           selectedProfessor is not None:
            if selectedDisciplina is not None:
                if quartil is not None:
                    return self.get_quartil(
                        selectedTurma, 
                        selectedDisciplina, 
                        selectedTurno, 
                        selectedAno, 
                        selectedProfessor
                    )

                return self.get_porcentagens(
                    selectedTurma, 
                    selectedDisciplina, 
                    selectedTurno, 
                    selectedAno, 
                    selectedProfessor
                )
            
            if selectedModalidade is not None:
                if quartil is not None:
                    return self.get_quartil_modalidade(
                        selectedTurma, 
                        selectedModalidade, 
                        selectedTurno, 
                        selectedAno, 
                        selectedProfessor
                    )

                return self.get_porcentagens_modalidade(
                    selectedTurma, 
                    selectedModalidade, 
                    selectedTurno, 
                    selectedAno, 
                    selectedProfessor
                )

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
    
    def get_turnos(self, id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """select distinct(turno) from sada_turma where sada_turma.curso_id=%s;"""
            
            cursor.execute(sql, [id_curso])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            resultados.append(row[0])

        return Response(resultados)

    def get_quartil(
            self,
            selectedTurma, 
            selectedDisciplina, 
            selectedTurno, 
            selectedAno, 
            selectedProfessor, 
            *args, 
            **kwargs
        ):
        with connection.cursor() as cursor:
            sql = """
                SELECT quantidadeNotas
                FROM (
                SELECT
                    CASE
                        WHEN h.nota >= 0 AND h.nota <= 25 THEN '0-25'
                        WHEN h.nota > 25 AND h.nota <= 50 THEN '26-50'
                        WHEN h.nota > 50 AND h.nota <= 75 THEN '51-75'
                        WHEN h.nota > 75 AND h.nota <= 100 THEN '76-100'
                    END AS quartil,
                    COUNT(h.nota) AS quantidadeNotas
                FROM sada_historicoescolar h
                JOIN sada_turma t ON h.turma_id = t.id
                JOIN sada_disciplina d ON t.disciplina_id = d.id
                JOIN sada_professor pr ON t.professor_id = pr.pessoa_ptr_id
                JOIN sada_pessoa p ON pr.pessoa_ptr_id = p.id
                WHERE t.nome=%s
                    AND t.disciplina_id=%s
                    AND t.turno=%s
                    AND t.ano=%s
                    AND t.professor_id=%s
                GROUP BY quartil
                ) AS subquery
                ORDER BY
                CASE quartil
                    WHEN '0-25' THEN 1
                    WHEN '26-50' THEN 2
                    WHEN '51-75' THEN 3
                    WHEN '76-100' THEN 4
                END;
            """
            
            cursor.execute(sql, [selectedTurma, selectedDisciplina, selectedTurno, selectedAno, selectedProfessor])
            result = cursor.fetchall()

        resultado = {}

        if result:
            quartil_0_25 = result[0][0]
            quartil_26_50 = result[1][0]
            quartil_51_75 = result[2][0]
            quartil_76_100 = result[3][0]

            resultado = {
                'quartil_0_25': quartil_0_25,
                'quartil_26_50': quartil_26_50,
                'quartil_51_75': quartil_51_75,
                'quartil_76_100': quartil_76_100,
            }

        return Response(resultado)
    
    def get_porcentagens(
            self,
            selectedTurma, 
            selectedDisciplina, 
            selectedTurno, 
            selectedAno, 
            selectedProfessor, 
            *args, 
            **kwargs
        ):
        with connection.cursor() as cursor:
            sql = """
                SELECT 
                    AVG(h.nota) AS mediaNotas,
                    (COUNT(CASE WHEN h.status = 'Aprovado' THEN 1 END) / COUNT(*)) * 100 AS porcentagemAprovados,
                    (COUNT(CASE WHEN h.status = 'Cancelado' THEN 1 END) / COUNT(*)) * 100 AS porcentagemCancelados,
                    COUNT(CASE WHEN h.status = 'Reprovado por nota' OR h.status = 'Reprovado por frequencia' THEN 1 END) AS alunosReprovados,
                    COUNT(CASE WHEN h.status = 'Aprovado' THEN 1 END) AS aprovados,
                    COUNT(CASE WHEN h.status = 'Reprovado por nota' THEN 1 END) AS rep_nota,
                    COUNT(CASE WHEN h.status = 'Reprovado por frequencia' THEN 1 END) AS rep_freq,
                    COUNT(CASE WHEN h.status = 'Cancelado' THEN 1 END) AS cancelados
                FROM sada_historicoescolar h
                JOIN sada_turma t ON h.turma_id = t.id
                JOIN sada_disciplina d ON t.disciplina_id = d.id
                JOIN sada_professor pr ON t.professor_id = pr.pessoa_ptr_id
                JOIN sada_pessoa p ON pr.pessoa_ptr_id = p.id
                WHERE t.nome=%s
                    AND t.disciplina_id=%s
                    AND t.turno=%s
                    AND t.ano=%s
                    AND t.professor_id=%s;
            """
            
            cursor.execute(sql, [selectedTurma, selectedDisciplina, selectedTurno, selectedAno, selectedProfessor])
            result = cursor.fetchall()

        resultado = {}

        if result:
            mediaNotas = result[0][0]
            porcentagemAprovados = result[0][1]
            porcentagemCancelados = result[0][2]
            alunosReprovados = result[0][3]
            aprovados = result[0][4]
            rep_nota = result[0][5]
            rep_freq = result[0][6]
            cancelados = result[0][7]

            resultado = {
                'mediaNotas': round(mediaNotas, 2) if mediaNotas else mediaNotas,
                'porcentagemAprovados': round(porcentagemAprovados, 2) if porcentagemAprovados else porcentagemAprovados,
                'porcentagemCancelados': round(porcentagemCancelados, 2) if porcentagemCancelados else porcentagemCancelados,
                'alunosReprovados': alunosReprovados,
                'aprovados': aprovados,
                'rep_nota': rep_nota,
                'rep_freq': rep_freq,
                'cancelados': cancelados
            }

        return Response(resultado)

    def get_quartil_modalidade(
            self,
            selectedTurma, 
            selectedModalidade, 
            selectedTurno, 
            selectedAno, 
            selectedProfessor, 
            *args, 
            **kwargs
        ):
        with connection.cursor() as cursor:
            sql = """
                SELECT quantidadeNotas
                FROM (
                    SELECT
                        CASE
                            WHEN h.nota >= 0 AND h.nota <= 25 THEN '0-25'
                            WHEN h.nota > 25 AND h.nota <= 50 THEN '26-50'
                            WHEN h.nota > 50 AND h.nota <= 75 THEN '51-75'
                            WHEN h.nota > 75 AND h.nota <= 100 THEN '76-100'
                        END AS quartil,
                        COUNT(h.nota) AS quantidadeNotas
                    FROM sada_historicoescolar h
                    JOIN sada_turma t ON h.turma_id = t.id
                    JOIN sada_disciplina d ON t.disciplina_id = d.id
                    JOIN sada_professor pr ON t.professor_id = pr.pessoa_ptr_id
                    JOIN sada_pessoa p ON pr.pessoa_ptr_id = p.id
                    JOIN sada_modalidade m ON d.modalidade_id = m.id
                    WHERE t.nome=%s
                        AND m.nome=%s
                        AND t.turno=%s
                        AND t.ano=%s
                        AND t.professor_id=%s
                    GROUP BY quartil
                ) AS subquery
                ORDER BY
                CASE quartil
                    WHEN '0-25' THEN 1
                    WHEN '26-50' THEN 2
                    WHEN '51-75' THEN 3
                    WHEN '76-100' THEN 4
                END;
            """
            
            cursor.execute(sql, [selectedTurma, selectedModalidade, selectedTurno, selectedAno, selectedProfessor])
            result = cursor.fetchall()

        resultado = {}

        if result:
            quartil_0_25 = result[0][0]
            quartil_26_50 = result[1][0]
            quartil_51_75 = result[2][0]
            quartil_76_100 = result[3][0]

            resultado = {
                'quartil_0_25': quartil_0_25,
                'quartil_26_50': quartil_26_50,
                'quartil_51_75': quartil_51_75,
                'quartil_76_100': quartil_76_100,
            }

        return Response(resultado)
    
    def get_porcentagens_modalidade(
            self,
            selectedTurma, 
            selectedModalidade, 
            selectedTurno, 
            selectedAno, 
            selectedProfessor, 
            *args, 
            **kwargs
        ):
        with connection.cursor() as cursor:
            sql = """
                SELECT 
                    AVG(h.nota) AS mediaNotas,
                    (COUNT(CASE WHEN h.status = 'Aprovado' THEN 1 END) / COUNT(*)) * 100 AS porcentagemAprovados,
                    (COUNT(CASE WHEN h.status = 'Cancelado' THEN 1 END) / COUNT(*)) * 100 AS porcentagemCancelados,
                    COUNT(CASE WHEN h.status = 'Reprovado por nota' OR h.status = 'Reprovado por frequencia' THEN 1 END) AS alunosReprovados,
                    COUNT(CASE WHEN h.status = 'Aprovado' THEN 1 END) AS aprovados,
                    COUNT(CASE WHEN h.status = 'Reprovado por nota' THEN 1 END) AS rep_nota,
                    COUNT(CASE WHEN h.status = 'Reprovado por frequencia' THEN 1 END) AS rep_freq,
                    COUNT(CASE WHEN h.status = 'Cancelado' THEN 1 END) AS cancelados
                FROM sada_historicoescolar h
                JOIN sada_turma t ON h.turma_id = t.id
                JOIN sada_disciplina d ON t.disciplina_id = d.id
                JOIN sada_professor pr ON t.professor_id = pr.pessoa_ptr_id
                JOIN sada_pessoa p ON pr.pessoa_ptr_id = p.id
                JOIN sada_modalidade m ON d.modalidade_id = m.id
                WHERE t.nome=%s
                    AND m.nome=%s
                    AND t.turno=%s
                    AND t.ano=%s
                    AND t.professor_id=%s;
            """
            
            cursor.execute(sql, [selectedTurma, selectedModalidade, selectedTurno, selectedAno, selectedProfessor])
            result = cursor.fetchall()

        resultado = {}

        if result:
            mediaNotas = result[0][0]
            porcentagemAprovados = result[0][1]
            porcentagemCancelados = result[0][2]
            alunosReprovados = result[0][3]
            aprovados = result[0][4]
            rep_nota = result[0][5]
            rep_freq = result[0][6]
            cancelados = result[0][7]

            resultado = {
                'mediaNotas': round(mediaNotas, 2) if mediaNotas else mediaNotas,
                'porcentagemAprovados': round(porcentagemAprovados, 2) if porcentagemAprovados else porcentagemAprovados,
                'porcentagemCancelados': round(porcentagemCancelados, 2) if porcentagemCancelados else porcentagemCancelados,
                'alunosReprovados': alunosReprovados,
                'aprovados': aprovados,
                'rep_nota': rep_nota,
                'rep_freq': rep_freq,
                'cancelados': cancelados
            }

        return Response(resultado)

