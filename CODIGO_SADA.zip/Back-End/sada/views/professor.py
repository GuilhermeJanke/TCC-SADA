from sada.models.professor import Professor
from sada.serializers.professor import ProfessorSerializer
from sada.views.pessoa import PessoaViewSet

#
# Professor
#
class ProfessorViewSet(PessoaViewSet):
    """
    Classe de view para Professor
    """
    queryset = Professor.objects.all()
    serializer_class = ProfessorSerializer

