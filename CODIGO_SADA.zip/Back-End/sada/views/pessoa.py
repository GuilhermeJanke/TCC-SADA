from sada.models.pessoa import Pessoa
from sada.views.email_service import enviar_email_nova_senha
from sada.serializers.pessoa import PessoaSerializer
from rest_framework.mixins import RetrieveModelMixin

from rest_framework import viewsets, status
from rest_framework.response import Response

from rest_framework.decorators import action
from django.db import connection

#
# Pessoa
#
class PessoaViewSet(viewsets.ModelViewSet, RetrieveModelMixin):
    """
    Classe de view para Pessoa
    """
    serializer_class = PessoaSerializer
    queryset = Pessoa.objects.all()


    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # Salva a Pessoa e seus Cursos associados
        pessoa = serializer.save()
        cursos = request.data.get('curso', [])
        pessoa.curso.set(cursos)

        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        id = request.query_params.get('id', None)
        id_curso = request.query_params.get('id_curso', None)

        if id is not None:
            queryset = queryset.filter(id=id)

        if id_curso is not None:
            queryset = queryset.filter(curso=id_curso)

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()

        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)

        # Salva a Pessoa e seus Cursos associados
        pessoa = serializer.save()
        cursos = request.data.get('curso', [])
        ids = []

        if (cursos and type(cursos[0]) == dict):
            for curso in cursos:
                ids.append(curso["id"])

            pessoa.curso.set(ids)
        else:
            del ids
            pessoa.curso.set(cursos)

        return Response(serializer.data)

    @action(detail=False, methods=['post'])
    def enviar_email(self, request):
        queryset = self.get_queryset()
        email = request.data.get('email')
        nova_senha = request.data.get('nova_senha')

        # Obtém o objeto de usuário
        usuario = queryset[0]

        if usuario:
            # Atualiza os campos de e-mail e nova senha
            usuario.senha = nova_senha
            usuario.save()

            # Envia o e-mail de confirmação
            enviar_email_nova_senha(email, nova_senha)

            return Response({'message': 'E-mail enviado com sucesso'}, status=200)
        else:
            return Response({'error': 'Usuário não encontrado'}, status=404)

    @action(detail=False, methods=['GET'])
    def buscar_por_cpf(self, request):
        cpf = request.query_params.get('cpf')

        with connection.cursor() as cursor:
            sql = """
                    SELECT id, cpf, email
                    FROM sada_pessoa
                    WHERE cpf = %s
                """
            cursor.execute(sql, [cpf])
            results = cursor.fetchall()

        data = [{'id': row[0], 'cpf': row[1], 'email': row[2]} for row in results]
        return Response(data)
