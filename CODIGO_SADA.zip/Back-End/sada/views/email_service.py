import smtplib
from email.message import EmailMessage

def enviar_email_nova_senha(email, nova_senha):
    msg = EmailMessage()
    msg['Subject'] = 'Nova Senha'
    msg['From'] = 'sadaufpr@gmail.com'
    msg['To'] = email
    msg.set_content(f'Sua nova senha é: {nova_senha}')

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
            smtp.starttls()
            smtp.login('sadaufpr@gmail.com', 'SomosForte_0307')
            smtp.send_message(msg)
        print('Email enviado com sucesso')
    except smtplib.SMTPAuthenticationError:
        print('Erro de autenticação SMTP: verifique as credenciais do servidor de e-mail')
    except smtplib.SMTPException as e:
        print(f'Erro ao enviar o e-mail: {e}')
