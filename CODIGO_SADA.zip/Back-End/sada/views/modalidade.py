from rest_framework import viewsets, status
from rest_framework.response import Response
from django.db import connection

from sada.models.modalidade import Modalidade
from sada.serializers.modalidade import ModalidadeSerializer


#
# Modalidade
#
class ModalidadeViewSet(viewsets.ModelViewSet):
    """
    Classe de view para Modalidade
    """
    queryset = Modalidade.objects.all()
    serializer_class = ModalidadeSerializer

    def create(self, request, *args, **kwargs):
        nome_modalidade = request.data["nome"]
        modalidade = Modalidade.objects.filter(nome=nome_modalidade).first()

        if modalidade:
            serializer = self.get_serializer(modalidade)
            return Response(serializer.data, status=status.HTTP_200_OK)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        aprovados = request.query_params.get('aprovados', None)
        aprovados_data = request.query_params.get('aprovados_data', None)
        reprovados_modalidade = request.query_params.get('reprovados_modalidade', None)
        reprovados = request.query_params.get('reprovados', None)
        reprovados_data = request.query_params.get('reprovados_data', None)
        id = request.query_params.get('id', None)
        id_curso = request.query_params.get('id_curso', None)
        data_inicio = request.query_params.get('data_inicio', None)
        data_fim = request.query_params.get('data_fim', None)

        if aprovados is not None and id_curso is not None:
            return self.get_aprovados(id_curso)

        if aprovados_data is not None and id_curso is not None and data_inicio is not None and data_fim is not None:
            return self.get_aprovados_data(id_curso, data_inicio, data_fim)

        if reprovados_modalidade is not None:
            return self.get_reprovados_modalidade(reprovados_modalidade)
        
        if reprovados is not None and id_curso is not None:
            return self.get_reprovados(id_curso)

        if reprovados_data is not None and id_curso is not None and data_inicio is not None and data_fim is not None:
            return self.get_reprovados_data(id_curso, data_inicio, data_fim)

        if id is not None:
            queryset = queryset.filter(id__icontains=id)

        if id_curso is not None:
            modalidades = self.get_modalidades_by_id_curso(id_curso)
            serializer = ModalidadeSerializer(modalidades, many=True)
            return Response(serializer.data)

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
    
    def get_aprovados(self, id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT m.nome AS modalidade,
                    SUM(CASE WHEN he.status LIKE '%%Aprovado%%' AND he.data_atualizacao >= DATE_SUB(NOW(), INTERVAL 3 YEAR)
                                THEN 1 ELSE 0 END) AS aprovados,
                    COUNT(he.aluno_id) AS total_alunos
                FROM sada_modalidade AS m
                INNER JOIN sada_disciplina AS d ON m.id = d.modalidade_id
                LEFT JOIN sada_historicoescolar AS he ON d.id = he.disciplina_id
                WHERE d.curso_id = %s
                GROUP BY m.nome
            """
            cursor.execute(sql, [id_curso])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            modalidade = row[0]
            aprovados = row[1]
            total_alunos = row[2]
            resultados.append({
                'modalidade': modalidade,
                'aprovados': aprovados,
                'total_alunos': total_alunos
            })

        return Response(resultados)

    def get_aprovados_data(self, id_curso, data_inicio, data_fim, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT m.nome AS modalidade,
                    SUM(CASE WHEN he.status LIKE '%%Aprovado%%' AND he.data_atualizacao >= DATE_SUB(NOW(), INTERVAL 3 YEAR)
                                THEN 1 ELSE 0 END) AS aprovados,
                    COUNT(he.aluno_id) AS total_alunos
                FROM sada_modalidade AS m
                INNER JOIN sada_disciplina AS d ON m.id = d.modalidade_id
                LEFT JOIN sada_historicoescolar AS he ON d.id = he.disciplina_id
                WHERE d.curso_id = %s
                AND he.ano >= %s
                    AND he.ano <= %s
                GROUP BY m.nome
            """
            cursor.execute(sql, [id_curso, int(data_inicio), int(data_fim)])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            modalidade = row[0]
            aprovados = row[1]
            total_alunos = row[2]
            resultados.append({
                'modalidade': modalidade,
                'aprovados': aprovados,
                'total_alunos': total_alunos
            })

        return Response(resultados)

    def get_reprovados_modalidade(self, modalidade_selecionada, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT
                    SUM(CASE WHEN he.status LIKE '%%Reprovado por frequencia%%' 
                        AND he.data_atualizacao >= DATE_SUB(NOW(), INTERVAL 3 YEAR)
                                THEN 1 ELSE 0 END) AS reprovados_frequencia,
                    SUM(CASE WHEN he.status LIKE '%%Reprovado por nota%%' 
                        AND he.data_atualizacao >= DATE_SUB(NOW(), INTERVAL 3 YEAR)
                                THEN 1 ELSE 0 END) AS reprovados_nota,
                    COUNT(he.aluno_id) AS total_alunos
                FROM
                    sada_disciplina AS d
                    LEFT JOIN sada_historicoescolar AS he ON d.id = he.disciplina_id 
                    AND he.status LIKE '%%Reprovado%%' 
                    AND he.data_atualizacao >= DATE_SUB(NOW(), INTERVAL 3 YEAR)
                WHERE
                    d.modalidade_id = %s
                """
            cursor.execute(sql, [modalidade_selecionada])
            result = cursor.fetchone()

        reprovados_frequencia = result[0]
        reprovados_nota = result[1]
        total_alunos = result[2]

        resultados = [{
            'reprovados_frequencia': reprovados_frequencia,
            'reprovados_nota': reprovados_nota,
            'total_alunos': total_alunos
        }]

        return Response(resultados)
    
    def get_reprovados(self, id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT m.nome AS modalidade,
                    SUM(CASE WHEN (he.status LIKE '%%Reprovado%%'
                        OR he.status LIKE '%%Reprovado por frequencia%%' 
                        OR he.status LIKE '%%Reprovado por nota%%')
                        THEN 1 ELSE 0 END) AS reprovados,
                    COUNT(he.aluno_id) AS total_alunos
                FROM sada_modalidade AS m
                INNER JOIN sada_disciplina AS d ON m.id = d.modalidade_id
                LEFT JOIN sada_historicoescolar AS he ON d.id = he.disciplina_id
                WHERE d.curso_id = %s
                GROUP BY m.nome
            """
            cursor.execute(sql, [id_curso])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            modalidade = row[0]
            reprovados = row[1]
            total_alunos = row[2]
            resultados.append({
                'modalidade': modalidade,
                'reprovados': reprovados,
                'total_alunos': total_alunos
            })

        return Response(resultados)

    def get_reprovados_data(self, id_curso, data_inicio, data_fim, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT m.nome AS modalidade,
                    SUM(CASE WHEN (he.status LIKE '%%Reprovado%%'
                        OR he.status LIKE '%%Reprovado por frequencia%%' 
                        OR he.status LIKE '%%Reprovado por nota%%')
                        THEN 1 ELSE 0 END) AS reprovados,
                    COUNT(he.aluno_id) AS total_alunos
                FROM sada_modalidade AS m
                INNER JOIN sada_disciplina AS d ON m.id = d.modalidade_id
                LEFT JOIN sada_historicoescolar AS he ON d.id = he.disciplina_id
                WHERE d.curso_id = %s
                    AND he.ano >= %s
                    AND he.ano <= %s
                GROUP BY m.nome
            """
            cursor.execute(sql, [id_curso, int(data_inicio), int(data_fim)])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            modalidade = row[0]
            reprovados = row[1]
            total_alunos = row[2]
            resultados.append({
                'modalidade': modalidade,
                'reprovados': reprovados,
                'total_alunos': total_alunos
            })

        return Response(resultados)

    def get_modalidades_by_id_curso(self, id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT DISTINCT m.id, m.nome
                FROM sada_modalidade AS m
                INNER JOIN sada_matrizcurricular_modalidade AS mm ON m.id = mm.modalidade_id
                INNER JOIN sada_matrizcurricular AS mc ON mm.matrizcurricular_id = mc.id
                WHERE mc.curso_id = %s
                """
            cursor.execute(sql, [id_curso])
            result = cursor.fetchall()

        modalidades = []
        for row in result:
            modalidade_id = row[0]
            modalidade_nome = row[1]
            modalidades.append(Modalidade(id=modalidade_id, nome=modalidade_nome))

        return modalidades

