from rest_framework import viewsets, status
from rest_framework.response import Response

from sada.models.disciplina import Disciplina
from sada.serializers.disciplina import DisciplinaSerializer
from sada.models.modalidade import Modalidade
from sada.models.matriz import MatrizCurricular


#
# Disciplina
#
class DisciplinaViewSet(viewsets.ModelViewSet):
    """
    Classe de view para Disciplina
    """
    queryset = Disciplina.objects.all()
    serializer_class = DisciplinaSerializer

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        id = request.query_params.get('id', None)
        id_curso = request.query_params.get('id_curso', None)
        matriz_id = request.query_params.get('matriz', None)
        modalidade_id = request.query_params.get('modalidade', None)

        if id is not None:
            queryset = queryset.filter(id=id)

        if id_curso is not None:
            queryset = queryset.filter(curso=id_curso)

        if matriz_id is not None and modalidade_id is not None:
            matriz = MatrizCurricular.objects.filter(id=matriz_id)

            if modalidade_id == 'null':
                disciplinas = matriz[0].disciplina.filter(modalidade__isnull=True)
            else:
                disciplinas = matriz[0].disciplina.filter(modalidade=modalidade_id)

            serializer = self.get_serializer(disciplinas, many=True)
            return Response(serializer.data)

        if matriz_id is not None:
            matriz = MatrizCurricular.objects.filter(id=matriz_id)
            disciplinas = matriz[0].disciplina.all()

            serializer = self.get_serializer(disciplinas, many=True)
            return Response(serializer.data)

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()

        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)

        # Salva a Disciplina e sua Modalidade associada
        disciplina = serializer.save()
        modalidade_data = request.data.get('modalidade')

        if modalidade_data:
            if isinstance(modalidade_data, int):
                modalidade_id = modalidade_data
            elif isinstance(modalidade_data, dict) and 'id' in modalidade_data and 'nome' in modalidade_data:
                modalidade_id = modalidade_data['id']
            else:
                return Response({'error': 'Modalidade inválida'}, status=status.HTTP_400_BAD_REQUEST)

            try:
                modalidade = Modalidade.objects.get(id=modalidade_id)
                disciplina.modalidade = modalidade
            except Modalidade.DoesNotExist:
                return Response({'error': 'Modalidade não encontrada'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            disciplina.modalidade = None

        disciplina.save()

        return Response(serializer.data)

