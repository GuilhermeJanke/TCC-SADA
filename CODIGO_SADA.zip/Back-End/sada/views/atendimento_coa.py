from django.http import JsonResponse
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action, api_view
from rest_framework.parsers import MultiPartParser, FormParser
from jsonpatch import apply_patch
import os
from django.http import FileResponse
from django.conf import settings

from sada.helpers import PostAuthenticatedPermission
from sada.models.aluno import Aluno
from sada.models.atendimento_coa import AtendimentoCOA
from sada.serializers.atendimento_coa import AtendimentoCOASerializer


class AtendimentoCOAViewSet(viewsets.ModelViewSet):
    """
    Classe de view para AtendimentoCOA
    """
    permission_classes = (PostAuthenticatedPermission,)
    queryset = AtendimentoCOA.objects.all()
    serializer_class = AtendimentoCOASerializer
    parser_classes = [MultiPartParser, FormParser]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        atendimento_coa = serializer.save()

        aluno_data = request.data.get('aluno', None)
        professores_data = request.data.get('professor', [])

        if aluno_data and isinstance(aluno_data, dict):
            aluno = Aluno.objects.get(id=aluno_data['id'])
            atendimento_coa.aluno.id = aluno
        elif aluno_data:
            atendimento_coa.aluno.id = aluno_data

        atendimento_coa.professor.set(professores_data)

        atendimento_coa.save()

        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        id = request.query_params.get('id', None)
        id_aluno = request.query_params.get('id_aluno', None)
        id_professor = request.query_params.get('id_professor', None)

        if id is not None:
            queryset = queryset.filter(id=id)

        elif id_aluno is not None:
            queryset = queryset.filter(id_aluno)

        elif id_professor is not None:
            queryset = queryset.filter(id_professor)

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def patch(self, request, *args, **kwargs):
        # Obtém o objeto de atendimento
        instance = self.get_object()

        # Atualiza o campo de situação
        instance.situacao = request.data.get('situacao', instance.situacao)
        instance.save()

        serializer = self.get_serializer(instance, data=request.data, instance=instance)
        serializer.is_valid(raise_exception=True)

        return Response(serializer.data)

    @action(detail=False, methods=['post'])
    def upload(self, request):
        if 'file' not in request.FILES:
            return Response('Nenhum arquivo enviado.', status=400)

        file = request.FILES['file']
        if file.name == '':
            return Response('Nenhum arquivo selecionado.', status=400)

        atendimento_coa = AtendimentoCOA.objects.create(anexo=file)
        serializer = self.serializer_class(atendimento_coa)
        return Response(serializer.data, status=201)

    @api_view(['GET'])
    def download(request, file_path):
        file_full_path = os.path.join(settings.MEDIA_ROOT, file_path)
        if os.path.exists(file_full_path):
            file = open(file_full_path, 'rb')
            response = FileResponse(file)
            return response

        return JsonResponse({'error': 'Arquivo não encontrado.'}, status=404)