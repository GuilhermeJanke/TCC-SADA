from rest_framework import viewsets
from rest_framework.response import Response

from sada.models.curso import Curso
from sada.serializers.curso import CursoSerializer


#
# Curso
#
class CursoViewSet(viewsets.ModelViewSet):
    """
    Classe de view para Curso
    """
    queryset = Curso.objects.all()
    serializer_class = CursoSerializer

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        id = request.query_params.get('id', None)
        nome = request.query_params.get('nome', None)

        if nome is not None:
            queryset = queryset.filter(nome__icontains=nome)

        elif id is not None:
            queryset = queryset.filter(id=id)

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

