from rest_framework import viewsets
from rest_framework.response import Response

from sada.models.curso import Curso
from sada.models.disciplina import Disciplina
from sada.models.matriz import MatrizCurricular
from sada.serializers.matriz import MatrizCurricularSerializer

from sada.helpers import ler_arquivos

import pandas as pd


#
# MatrizCurricular
#
class MatrizCurricularViewSet(viewsets.ModelViewSet):
    """
    Classe de view para MatrizCurricular
    """
    queryset = MatrizCurricular.objects.all()
    serializer_class = MatrizCurricularSerializer

    def create(self, request, *args, **kwargs):
        if 'file' in request.FILES:
            # Obter a lista de arquivos enviados através da requisição
            arquivos = request.FILES.getlist('file')

            # Definir as colunas esperadas
            colunas_esperadas = [
                'Coordenação', 'Currículo', 'Ano da versão', 'Natureza', 'Período',
                'Departamento', 'Código da disciplina', 'Nome da disciplina', 'Ch Total',
                'Ch Semanal', 'Ch EAD', 'Ch campo', 'Ch estágio', 'Ch estágio de formação pedagógica',
                'Ch extensão', 'Ch laboratório', 'Ch orientada', 'Ch padrão', 'Ch prática específica'
            ]

            # Receber o DataFrame
            dataframe_final = ler_arquivos(arquivos, colunas_esperadas)

            if type(dataframe_final) == pd.DataFrame:
                # Iterar sobre as linhas do DataFrame e criar objetos MatrizCurricular
                for indice, linha in dataframe_final.iterrows():
                    # Pegar o curso ou ir para a próxima linha caso não exista
                    try:
                        curso = Curso.objects.get(nome=linha['Coordenação'])
                    except Curso.DoesNotExist:
                        continue

                    # Pegar a disciplina ou criar uma nova caso não exista ainda
                    try:
                        disciplina = Disciplina.objects.get(codigo=linha['Código da disciplina'])
                    except Disciplina.DoesNotExist:
                        disciplina = Disciplina.objects.create(
                            codigo=linha['Código da disciplina'],
                            nome=linha['Nome da disciplina'],
                            periodo=linha['Período'],
                            natureza=linha['Natureza'],
                            ch=linha['Ch Total'],
                            ch_semanal=linha['Ch Semanal'],
                            ch_EAD=linha['Ch EAD'],
                            ch_campo=linha['Ch campo'],
                            ch_estagio=linha['Ch estágio'],
                            ch_estagio_pedagogico=linha['Ch estágio de formação pedagógica'],
                            ch_extensao=linha['Ch extensão'],
                            ch_laboratorio=linha['Ch laboratório'],
                            ch_orientada=linha['Ch orientada'],
                            ch_padrao=linha['Ch padrão'],
                            ch_pratica_especifica=linha['Ch prática específica'],
                            curso=curso
                        )

                    # Pegar a matriz curricular do banco ou criar uma nova caso não exista
                    try:
                        matriz = MatrizCurricular.objects.get(curriculo=linha['Currículo'])
                    except MatrizCurricular.DoesNotExist:
                        # Criar um novo objeto MatrizCurricular
                        matriz = MatrizCurricular(
                            curriculo=linha['Currículo'],
                            ano_versao=linha['Ano da versão'],
                            departamento=linha['Departamento'],
                            curso=curso
                        )

                        # Salvar cada matriz na lista de matrizes
                        matriz.save()

                    # Adicionar a disciplina à matriz
                    matriz.disciplina.add(disciplina)

                # Retornar uma resposta de sucesso
                return Response({'message': 'Dados salvos com sucesso!'})
            else:
                return dataframe_final
        else:
            # Chamar o método create da classe pai para salvar os objetos MatrizCurricular normalmente
            return super().create(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        id = request.query_params.get('id', None)
        id_curso = request.query_params.get('id_curso', None)

        if id is not None:
            queryset = queryset.filter(id=id)

        if id_curso is not None:
            queryset = queryset.filter(curso=id_curso)

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()

        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)

        # Salva a Matriz e suas Modalidades associadas
        matriz = serializer.save()
        modalidades = request.data.get('modalidade', [])
        ids = set()

        if modalidades and isinstance(modalidades, list):
            for item in modalidades:
                if isinstance(item, dict) and 'id' in item and 'nome' in item:
                    if item['id'] not in ids and isinstance(item['id'], int):
                        ids.add(item['id'])
                elif item not in ids and isinstance(item, int):
                    ids.add(item)
        else:
            ids = modalidades

        matriz.modalidade.set(ids)

        return Response(serializer.data)

