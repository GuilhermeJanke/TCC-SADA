from sada.models.usuario import Usuario
from sada.serializers.usuario import CustomTokenObtainPairSerializer, UsuarioSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from sada.views.pessoa import PessoaViewSet

from sada.helpers import PostAuthenticatedPermission


#
# Usuario
#
class UsuarioViewSet(PessoaViewSet):
    """
    Classe de view para Usuario
    """
    permission_classes = (PostAuthenticatedPermission,)

    queryset = Usuario.objects.all()
    serializer_class = UsuarioSerializer


class CustomTokenObtainPairView(TokenObtainPairView):

    """
    Personalização da TokenObtainPairView que utiliza CustomTokenObtainPairSerializer
    """
    serializer_class = CustomTokenObtainPairSerializer


