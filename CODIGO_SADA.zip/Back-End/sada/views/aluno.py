from rest_framework.response import Response

from sada.models.aluno import Aluno
from sada.serializers.aluno import AlunoSerializer
from sada.views.pessoa import PessoaViewSet
from django.db import connection


#
# Aluno
#
class AlunoViewSet(PessoaViewSet):
    """
    Classe de view para Aluno
    """
    queryset = Aluno.objects.all()
    serializer_class = AlunoSerializer

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        id = request.query_params.get('id', None)
        id_curso = request.query_params.get('id_curso', None)
        integralizar = request.query_params.get('integralizar', None)
        horas = request.query_params.get('horas', None)

        if integralizar is not None and id_curso is not None:
            return self.get_integralizacao(id_curso)
        
        elif horas is not None and id is not None:
            return self.get_horas(id)

        elif id is not None:
            queryset = queryset.filter(id=id)

        elif id_curso is not None:
            queryset = queryset.filter(curso=id_curso)

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def get_integralizacao(self, id_curso, *args, **kwargs):
        # Selecionar todos os alunos do curso
        alunos = Aluno.objects.filter(curso=id_curso)

        # Lista para armazenar os resultados de cada aluno
        resultados = []

        # Loop pelos alunos
        for aluno in alunos:
            # Adicionar os resultados do aluno à lista de resultados
            resultados.append({
                'x': aluno.periodo_atual,
                'y': aluno.ch_integralizada,
                'grr': aluno.grr
            })

        # Retornar a lista de resultados
        return Response(resultados)

    def get_horas(self, id, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT
                    (obrigatorias.total_obrigatorias / c.ch_disciplinas_obrigatorias) * 100 AS obrigatoria,
                    (optativas.total_optativas / c.ch_disciplinas_optativas) * 100 AS optativa
                FROM sada_curso c
                CROSS JOIN (
                    SELECT
                        SUM(CASE WHEN d.natureza = 'Obrigatória' THEN d.ch ELSE 0 END) AS total_obrigatorias
                    FROM sada_historicoescolar h
                    JOIN sada_aluno a ON h.aluno_id = a.pessoa_ptr_id
                    JOIN sada_disciplina d ON h.disciplina_id = d.id
                    WHERE a.pessoa_ptr_id = %s
                        AND h.status = 'Aprovado'
                ) AS obrigatorias
                CROSS JOIN (
                    SELECT
                        SUM(CASE WHEN d.natureza = 'Optativa' THEN d.ch ELSE 0 END) AS total_optativas
                    FROM sada_historicoescolar h
                    JOIN sada_aluno a ON h.aluno_id = a.pessoa_ptr_id
                    JOIN sada_disciplina d ON h.disciplina_id = d.id
                    WHERE a.pessoa_ptr_id = %s
                        AND h.status = 'Aprovado'
                ) AS optativas;
            """

            cursor.execute(sql, [id, id])
            result = cursor.fetchall()

        resultado = {}

        if result:
            obrigatoria = result[0][0]
            optativa = result[0][1]

            resultado = {
                'obrigatoria': obrigatoria,
                'optativa': optativa
            }

        return Response(resultado)
