from rest_framework import viewsets, status
from rest_framework.response import Response

from sada.helpers import ler_arquivos
from sada.models.aluno import Aluno
from sada.models.curso import Curso
from sada.models.disciplina import Disciplina
from sada.models.historico import HistoricoEscolar
from sada.models.turma import Turma
from sada.serializers.historico import HistoricoEscolarSerializer

from rest_framework.decorators import action
from django.db.models import Sum

import pymysql
import pandas as pd
from django.db import connection


#
# HistoricoEscolar
#
class HistoricoEscolarViewSet(viewsets.ModelViewSet):
    """
    Classe de view para HistoricoEscolar
    """
    queryset = HistoricoEscolar.objects.all()
    serializer_class = HistoricoEscolarSerializer

    def create(self, request, *args, **kwargs):
        if 'file' in request.FILES:
            # Obter a lista de arquivos enviados através da requisição
            arquivos = request.FILES.getlist('file')

            # Definir as colunas esperadas
            colunas_esperadas = [
                'Período', 'Ano', 'Data Atualização', 'CH', 'Nota', 'Frequência', 'Status', 'Tipo',
                'Observação', 'Natureza', 'Situação Discente', 'Currículo Atual', 'Matrícula',
                'Nome', 'Código', 'Disciplina', 'Nome da Turma', 'E-mail'
            ]

            # Receber o DataFrame
            dataframe_final = ler_arquivos(arquivos, colunas_esperadas)

            # Receber o curso vindo do Front
            id_curso = request.query_params.get('id_curso', None)
            curso = Curso.objects.filter(id=id_curso)

            if curso is not None:
                id_curso = curso[0].id
            else:
                return Response({'message': 'Curso especificado não foi encontrado.'})

            if type(dataframe_final) == pd.DataFrame:
                # Iterar sobre as linhas do DataFrame e criar objetos HistoricoEscolar
                for indice, linha in dataframe_final.iterrows():
                    if linha['Data Atualização'] != '0':
                        # Pegar a disciplina e turma ou ir para a próxima linha caso não existam
                        try:
                            disciplina = Disciplina.objects.get(codigo=linha['Código'])
                            turma = Turma.objects.get(
                                periodo=linha['Período'],
                                ano=linha['Ano'],
                                nome=linha['Nome da Turma'],
                                disciplina=disciplina
                            )
                        except Exception:
                            continue

                        # Pegar o aluno ou criar um caso não exista
                        try:
                            aluno = Aluno.objects.get(grr=linha['Matrícula'])
                        except Aluno.DoesNotExist:
                            aluno = Aluno.objects.create(
                                nome=linha['Nome'],
                                email=linha['E-mail'],
                                grr=linha['Matrícula'],
                                curriculo_aluno=linha['Currículo Aluno']
                            )

                            # Adicionar o curso ao aluno
                            aluno.curso.add(id_curso)

                        # Criar um novo objeto HistoricoEscolar
                        historico = HistoricoEscolar(
                            periodo=linha['Período'],
                            ano=linha['Ano'],
                            data_atualizacao=linha['Data Atualização'],
                            ch=linha['CH'],
                            nota=linha['Nota'],
                            frequencia=linha['Frequência'],
                            status=linha['Status'],
                            tipo=linha['Tipo'],
                            observacao=linha['Observação'],
                            natureza=linha['Natureza'],
                            situacao_aluno=linha['Situação Discente'],
                            curriculo_atual=linha['Currículo Atual'],
                            aluno=aluno,
                            disciplina=disciplina,
                            turma=turma
                        )

                        # Salvar cada historico
                        historico.save()

                # Selecionar todos os alunos do curso
                alunos = Aluno.objects.filter(curso=id_curso)

                # Loop pelos alunos
                for aluno in alunos:
                    # Atualizar os cálculos
                    aluno.ch_integralizada = aluno.calcular_carga_horaria_integralizada()
                    aluno.periodo_atual = aluno.calcular_periodo_atual(id_curso)
                    aluno.ira = aluno.calcular_ira()
                    aluno.total_disciplinas_aprovadas = aluno.calcular_total_disciplinas_aprovadas()
                    aluno.total_disciplinas_repovada_freq = aluno.calcular_total_disciplinas_reprovadas_freq()
                    aluno.total_disciplinas_repovada_nota = aluno.calcular_total_disciplinas_reprovadas_nota()
                    aluno.total_disciplinas_canceladas = aluno.calcular_total_disciplinas_cancelada()

                    response_retencao = aluno.calcular_potencial_retencao()
                    if isinstance(response_retencao, str):
                        aluno.potencial_retencao = response_retencao
                    else:
                        return Response({'detail': 'Erro ao calcular o potencial de retenção'})

                    response_jubilamento = aluno.calcular_potencial_jubilamento()
                    if isinstance(response_jubilamento, str):
                        aluno.potencial_jubilamento = response_jubilamento
                    else:
                        return Response({'detail': 'Erro ao calcular o potencial de jubilamento'})

                    response_evasao = aluno.calcular_potencial_evasao()
                    if isinstance(response_evasao, str):
                        aluno.potencial_evasao = response_evasao
                    else:
                        return Response({'detail': 'Erro ao calcular o potencial de evasão'})


                    aluno.save()

                # Retornar uma resposta de sucesso
                return Response({'message': 'Dados salvos com sucesso!'})
            # else:
            #     return dataframe_final
        else:
            # Chamar o método create da classe pai para salvar os objetos HistoricoEscolar normalmente
            return super().create(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        queryset = self.queryset

        id = request.query_params.get('id', None)
        id_curso = request.query_params.get('id_curso', None)
        anos = request.query_params.get('anos', None)
        soma_evasao = request.query_params.get('soma_evasao', None)
        taxa_evasao_professor = request.query_params.get('evasao_professor', None)
        taxa_evasao_turno = request.query_params.get('evasao_turno',None)
        taxa_evasao_disciplina = request.query_params.get('evasao_disciplina', None)
        qtd_retencao_disciplina = request.query_params.get('retencao_disciplina', None)
        qtd_retencao_modalidade = request.query_params.get('retencao_modalidade', None)
        qtd_retencao_turno = request.query_params.get('retencao_turno', None)
        id_modalidade = request.query_params.get('id_modalidade', None)
        ano_ini = request.query_params.get('ano_ini', None)
        ano_fim = request.query_params.get('ano_fim', None)


        if soma_evasao is not None and id_curso is not None:
            return self.calcular_soma_evasao(id_curso)

        if id_modalidade is not None:
            return self.buscar_disciplinas_por_modalidade(id_modalidade)

        if ano_ini is not None and ano_fim is not None:
            return self.buscar_disciplinas_por_anos(ano_ini, ano_fim)

        if taxa_evasao_professor is not None and id_curso is not None:
            return self.calcular_taxa_evasao_professor(id_curso)

        if taxa_evasao_turno is not None and id_curso is not None:
            return self.calcular_taxa_evasao_turno(id_curso)

        if taxa_evasao_disciplina is not None and id_curso is not None:
            return self.calcular_taxa_evasao_disciplina(id_curso)

        if qtd_retencao_disciplina is not None and id_curso is not None:
            return self.calcula_retencao_disciplina(id_curso)

        if qtd_retencao_modalidade is not None and id_curso is not None:
            return self.calcula_retencao_modalidade(id_curso)

        if qtd_retencao_turno is not None and id_curso is not None:
            return self.calcular_taxa_retencao_turno(id_curso)

        if id is not None:
            queryset = queryset.filter(id=id)

        if anos is not None and id_curso is not None:
            return self.get_anos(id_curso)

        if id_curso is not None:
            queryset = queryset.filter(turma__curso=id_curso)

        else:
            queryset = queryset.filter()

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def calcular_ch(self, request):
        data = request.data
        aluno = data.get('aluno')
        historico = HistoricoEscolar.objects.filter(aluno=aluno).first()

        if historico is None:
            return Response({'detail': 'Aluno não encontrado ou não possui histórico escolar'},
                            status=status.HTTP_400_BAD_REQUEST)

        ch_total = HistoricoEscolar.objects.filter(aluno=aluno, status='Aprovado').aggregate(Sum('ch'))['ch__sum']

        if ch_total is None:
            ch_total = 0
        return Response({'carga_horaria_total': ch_total})

    def calcular_soma_evasao(self, id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT
                SUM(CASE WHEN situacao_aluno = 'Evasão' THEN TotalSituacoes ELSE 0 END) AS SomaEvasao,
                SUM(CASE WHEN situacao_aluno = 'Trancamento' THEN TotalSituacoes ELSE 0 END) AS SomaTrancamento,
                SUM(CASE WHEN situacao_aluno = 'Registro ativo' THEN TotalSituacoes ELSE 0 END) AS SomaRegistroAtivo,
                SUM(CASE WHEN situacao_aluno = 'Conclusão formatura' THEN TotalSituacoes ELSE 0 END) AS SomaConclusaoFormatura
                FROM (
                    SELECT aluno_id, situacao_aluno, COUNT(DISTINCT situacao_aluno) AS TotalSituacoes
                    FROM sada_historicoescolar
                    JOIN sada_turma t ON t.id = sada_historicoescolar.turma_id
                    WHERE situacao_aluno IN ('Evasão', 'Trancamento', 'Registro ativo', 'Conclusão formatura') AND t.curso_id = %s
                    GROUP BY aluno_id, situacao_aluno
                ) AS subquery;"""
            cursor.execute(sql,[id_curso])
            result = cursor.fetchone()
        
        SomaEvasao = result[0]
        SomaTrancamento = result[1]
        SomaRegistroAtivo = result[2]
        SomaConclusaoFormatura = result[3]

        resultados = [{
            'SomaEvasao': SomaEvasao,
            'SomaTrancamento': SomaTrancamento,
            'SomaRegistroAtivo': SomaRegistroAtivo,
            'SomaConclusaoFormatura': SomaConclusaoFormatura
        }]

        return Response(resultados)

    def calcular_taxa_evasao_professor(self,id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT
                pe.nome AS nome_professor,
                COUNT(*) AS numero_ocorrencias
                FROM
                sada_historicoescolar h
                JOIN
                sada_turma t ON h.turma_id = t.id
                JOIN
                sada_professor p ON t.professor_id = p.pessoa_ptr_id
                JOIN
                sada_pessoa pe ON p.pessoa_ptr_id = pe.id
                WHERE
                h.status IN ('Reprovado por frequência', 'Cancelado') AND t.curso_id = %s
                GROUP BY
                pe.nome
                ORDER BY
                numero_ocorrencias DESC;"""
            cursor.execute(sql,[id_curso])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            professor = row[0]
            ocorrencias = row[1]
            resultados.append({
                'professor': professor,
                'ocorrencias': ocorrencias,
            })

        return Response(resultados)

    def calcular_taxa_evasao_turno(self,id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                    SELECT
                    t.turno AS turno_turma,
                    COUNT(*) AS numero_ocorrencias
                    FROM
                    sada_historicoescolar h
                    JOIN
                    sada_turma t ON h.turma_id = t.id
                    WHERE
                    h.status IN ('Reprovado por frequência', 'Cancelado') AND t.curso_id = %s
                    GROUP BY
                    t.turno
                    ORDER BY
                    numero_ocorrencias DESC;"""
            cursor.execute(sql,[id_curso])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            turno = row[0]
            ocorrencias = row[1]
            resultados.append({
                'turno': turno,
                'ocorrencias': ocorrencias,
            })

        return Response(resultados)

    def calcular_taxa_retencao_turno(self,id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                    SELECT
                    'Vespertino' AS turno,
                    COUNT(*) AS total_alunos_retidos
                    FROM
                    sada_aluno sa
                    JOIN sada_pessoa_curso spc ON sa.pessoa_ptr_id = spc.pessoa_id
                    WHERE
                    sa.curriculo_aluno = 1
                    AND sa.potencial_retencao = 'RETIDO'
                    AND spc.curso_id = %s

                    UNION ALL

                    SELECT
                    'Noturno' AS turno,
                    COUNT(*) AS total_alunos_retidos
                    FROM
                    sada_aluno sa
                    JOIN sada_pessoa_curso spc ON sa.pessoa_ptr_id = spc.pessoa_id
                    WHERE
                    sa.curriculo_aluno = 2
                    AND sa.potencial_retencao = 'RETIDO'
                    AND spc.curso_id = %s;"""

            cursor.execute(sql,[id_curso,id_curso])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            noturno = row[0]
            vespertino = row[1]
            resultados.append({
                'turno': noturno,
                'quantidade': vespertino,
            })

        return Response(resultados)

    def calcular_taxa_evasao_disciplina(self, id_curso, *args, **kwargs):
        
        with connection.cursor() as cursor:
            sql = """
                    SELECT
                    d.nome AS nome_disciplina,
                    COUNT(*) AS numero_ocorrencias
                    FROM
                    sada_historicoescolar h
                    JOIN
                    sada_turma t ON h.turma_id = t.id
                    JOIN
                    sada_disciplina d ON t.disciplina_id = d.id
                    WHERE
                    h.status IN ('Reprovado por frequência', 'Cancelado') AND t.curso_id = %s
                    GROUP BY
                    d.nome
                    ORDER BY
                    numero_ocorrencias DESC;"""
            cursor.execute(sql, [id_curso])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            disciplina = row[0]
            ocorrencias = row[1]
            resultados.append({
                'disciplina': disciplina,
                'ocorrencias': ocorrencias,
            })

        return Response(resultados)

    def calcula_retencao_disciplina(self, id_curso, *args, **kwargs):
        # Lista todos os alunos do curso
        alunos = Aluno.objects.filter(curso=id_curso)

        retencao_disciplinas = {}

        # Para cada aluno
        for aluno in alunos:
            aluno_id = aluno.id
            with connection.cursor() as cursor:
                # Executa a consulta SQL para a disciplina do aluno
                query = """
                SELECT sada_disciplina.nome
                FROM sada_aluno
                JOIN sada_historicoescolar ON sada_aluno.pessoa_ptr_id = sada_historicoescolar.aluno_id
                JOIN sada_disciplina ON sada_historicoescolar.disciplina_id = sada_disciplina.id
                WHERE sada_disciplina.id NOT IN (
                    SELECT sada_disciplina.id
                    FROM sada_aluno
                    JOIN sada_historicoescolar ON sada_aluno.pessoa_ptr_id = sada_historicoescolar.aluno_id
                    JOIN sada_disciplina ON sada_historicoescolar.disciplina_id = sada_disciplina.id
                    WHERE sada_historicoescolar.status = 'Aprovado' AND sada_aluno.pessoa_ptr_id = %s
                    ORDER BY sada_disciplina.id
                ) AND (sada_disciplina.periodo < (YEAR(CURRENT_TIMESTAMP) - CAST(SUBSTRING(grr, 4, 4) AS UNSIGNED)) * 2 + periodo_atual) AND sada_aluno.pessoa_ptr_id = %s
                GROUP BY sada_disciplina.id
                ORDER BY sada_disciplina.nome
                """
            
                cursor.execute(query,[aluno_id, aluno_id])
                results = cursor.fetchall()

            # Processa os resultados
            for row in results:
                disciplina_id = row[0]

                if disciplina_id not in retencao_disciplinas:
                    retencao_disciplinas[disciplina_id] = 1
                else:
                    retencao_disciplinas[disciplina_id] += 1

        # Preenche a lista resultados
        resultados = []
        for nome, qtd in retencao_disciplinas.items():
            resultado = {
                'disciplina': nome,
                'quantidade': qtd
            }
            resultados.append(resultado)

        return Response(resultados)

    def calcula_retencao_modalidade(self, id_curso, *args, **kwargs):
        # Lista todos os alunos do curso
        alunos = Aluno.objects.filter(curso=id_curso)

        retencao_modalidade = {}

        # Para cada aluno
        for aluno in alunos:
            aluno_id = aluno.id
            with connection.cursor() as cursor:
                # Executa a consulta SQL para a disciplina do aluno
                query = """
                SELECT distinct sada_modalidade.nome
                FROM sada_aluno
                JOIN sada_historicoescolar ON sada_aluno.pessoa_ptr_id = sada_historicoescolar.aluno_id
                JOIN sada_disciplina ON sada_historicoescolar.disciplina_id = sada_disciplina.id
                JOIN sada_modalidade ON sada_disciplina.modalidade_id = sada_modalidade.id
                WHERE sada_disciplina.id NOT IN (
                    SELECT sada_disciplina.id
                    FROM sada_aluno
                    JOIN sada_historicoescolar ON sada_aluno.pessoa_ptr_id = sada_historicoescolar.aluno_id
                    JOIN sada_disciplina ON sada_historicoescolar.disciplina_id = sada_disciplina.id
                    WHERE sada_historicoescolar.status = 'Aprovado' AND sada_aluno.pessoa_ptr_id = %s
                    ORDER BY sada_disciplina.id
                ) AND (sada_disciplina.periodo < (YEAR(CURRENT_TIMESTAMP) - CAST(SUBSTRING(grr, 4, 4) AS UNSIGNED)) * 2 + periodo_atual) AND sada_aluno.pessoa_ptr_id = %s
                GROUP BY sada_disciplina.id
                ORDER BY sada_modalidade.nome
                """
            
                cursor.execute(query,[aluno_id, aluno_id])
                results = cursor.fetchall()

            # Processa os resultados
            for row in results:
                modalidade_id = row[0]

                if modalidade_id not in retencao_modalidade:
                    retencao_modalidade[modalidade_id] = 1
                else:
                    retencao_modalidade[modalidade_id] += 1

        # Preenche a lista resultados
        resultados = []
        for nome, qtd in retencao_modalidade.items():
            resultado = {
                'modalidade': nome,
                'quantidade': qtd
            }
            resultados.append(resultado)

        return Response(resultados)

    def get_anos(self, id_curso, *args, **kwargs):
        with connection.cursor() as cursor:
            sql = """
                SELECT distinct(historico.ano)
                FROM sada_historicoescolar historico
                JOIN sada_turma turma ON historico.turma_id = turma.id
                JOIN sada_curso curso ON turma.curso_id = curso.id
                WHERE curso.id = %s;"""
            
            cursor.execute(sql, [id_curso])
            result = cursor.fetchall()

        resultados = []
        for row in result:
            resultados.append(row[0])

        return Response(resultados)

    def buscar_disciplinas_por_modalidade(self, id_modalidade, *args, **kwargs):
        with connection.cursor() as cursor:
            query = """
            SELECT DISTINCT AL.pessoa_ptr_id, DIS.nome
            FROM sada_aluno as AL
            JOIN sada_historicoescolar as HE ON AL.pessoa_ptr_id = HE.aluno_id
            JOIN sada_disciplina as DIS ON HE.disciplina_id = DIS.id
            WHERE DIS.modalidade_id = %s
            """

            cursor.execute(query, [id_modalidade])
            results = cursor.fetchall()

        # Preenche a lista resultados
        resultados = []
        for row in results:
            resultado = {
                'idAluno': row[0],
                'disciplina': row[1]
            }
            resultados.append(resultado)

        return Response(resultados)


    def buscar_disciplinas_por_anos(self, ano_ini, ano_fim, *args, **kwargs):
        with connection.cursor() as cursor:
            query = """
                SELECT DISTINCT AL.pessoa_ptr_id, DIS.nome
                FROM sada_aluno as AL
                JOIN sada_historicoescolar as HE ON AL.pessoa_ptr_id = HE.aluno_id
                JOIN sada_disciplina as DIS ON HE.disciplina_id = DIS.id
                WHERE DIS.modalidade_id != ''
                AND HE.ano >= %s AND HE.ano <= %s
                """

            cursor.execute(query, [ano_ini, ano_fim])
            results = cursor.fetchall()

        # Preenche a lista resultados
        resultados = []
        for row in results:
            resultado = {
                'idAluno': row[0],
                'disciplina': row[1]
            }
            resultados.append(resultado)

        return Response(resultados)