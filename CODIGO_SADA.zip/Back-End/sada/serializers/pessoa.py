from rest_framework import serializers

from sada.serializers.curso import CursoSerializer
from sada.models.pessoa import Pessoa


#
# Pessoa
#
class PessoaSerializer(serializers.ModelSerializer):
    """
    Classe serializadora para Pessoa
    """
    curso = CursoSerializer(many=True, read_only=True)
    
    class Meta:
        model = Pessoa
        fields = ['id', 'nome', 'cpf', 'email', 'curso', 'telefone']

