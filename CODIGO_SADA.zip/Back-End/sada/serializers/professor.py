from sada.serializers.pessoa import PessoaSerializer
from sada.models.professor import Professor


#
# Professor
#
class ProfessorSerializer(PessoaSerializer):
    """
    Classe serializadora para Professor
    """
    class Meta:
        model = Professor
        fields = PessoaSerializer.Meta.fields

