from rest_framework import serializers

from sada.serializers.pessoa import PessoaSerializer
from sada.models.usuario import Usuario

from django.contrib.auth.models import User
from rest_framework_simplejwt.serializers import TokenObtainSerializer
from rest_framework_simplejwt.tokens import RefreshToken


class UsuarioSerializer(PessoaSerializer):
    """
    Classe serializadora para Usuario
    """
    senha = serializers.CharField(write_only=True)

    class Meta:
        model = Usuario
        fields = PessoaSerializer.Meta.fields + ['tipo', 'senha']


class CustomTokenObtainPairSerializer(TokenObtainSerializer):
    """
    Classe serializadora personalizada para TokenObtainPairView
    """
    token_class = RefreshToken

    def validate(self, attrs):
        cpf = attrs.get('username')
        senha = attrs.get('password')
        data = {}

        if not cpf:
            raise serializers.ValidationError("O campo 'cpf' é obrigatório.")
        if not senha:
            raise serializers.ValidationError("O campo 'senha' é obrigatório.")

        try:
            usuario = Usuario.objects.get(cpf=cpf)
            user = User.objects.get(username=usuario.cpf)
            if user.check_password(senha):
                refresh = self.get_token(usuario)
                data["usuario"] = usuario.to_dict()
                data["refresh"] = str(refresh)
                data["access"] = str(refresh.access_token)
            else:
                raise serializers.ValidationError("CPF ou senha incorretos.")
        except Usuario.DoesNotExist:
            raise serializers.ValidationError("CPF ou senha incorretos.")

        return data
