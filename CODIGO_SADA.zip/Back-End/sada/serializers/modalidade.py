from rest_framework import serializers

from sada.models.modalidade import Modalidade


#
# Modalidade
#
class ModalidadeSerializer(serializers.ModelSerializer):
    """
    Classe serializadora para Modalidade
    """
    class Meta:
        model = Modalidade
        fields = ['id', 'nome']

