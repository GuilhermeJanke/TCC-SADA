from rest_framework import serializers

from sada.serializers.modalidade import ModalidadeSerializer
from sada.models.disciplina import Disciplina


#
# Disciplina
#
class DisciplinaSerializer(serializers.ModelSerializer):
    """
    Classe serializadora para Disciplina
    """
    modalidade = ModalidadeSerializer(many=False, read_only=True)
    class Meta:
        model = Disciplina
        fields = ['id', 'codigo', 'nome', 'periodo', 'natureza', 'ch', 'ch_semanal', 'ch_EAD', 'ch_campo', 'ch_estagio', 'ch_estagio_pedagogico', 'ch_extensao', 'ch_laboratorio', 'ch_orientada', 'ch_padrao', 'ch_pratica_especifica', 'pre_requisito', 'modalidade', 'curso']

