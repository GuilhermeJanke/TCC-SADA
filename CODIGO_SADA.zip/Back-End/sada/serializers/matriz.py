from rest_framework import serializers

from sada.serializers.modalidade import ModalidadeSerializer
from sada.models.matriz import MatrizCurricular


#
# MatrizCurricular
#
class MatrizCurricularSerializer(serializers.ModelSerializer):
    """
    Classe serializadora para MatrizCurricular
    """
    modalidade = ModalidadeSerializer(many=True, read_only=True)
    class Meta:
        model = MatrizCurricular
        fields = ['id', 'curriculo', 'ano_versao', 'departamento', 'disciplina', 'modalidade', 'curso']

