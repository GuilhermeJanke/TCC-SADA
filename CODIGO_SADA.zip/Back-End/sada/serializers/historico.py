from rest_framework import serializers

from sada.models.historico import HistoricoEscolar


#
# HistoricoEscolar
#
class HistoricoEscolarSerializer(serializers.ModelSerializer):
    """
    Classe serializadora para HistoricoEscolar
    """
    class Meta:
        model = HistoricoEscolar
        fields = ['id', 'periodo', 'ano', 'data_atualizacao', 'ch', 'nota', 'frequencia', 'status', 'tipo', 'observacao', 'natureza', 'situacao_aluno', 'aluno', 'disciplina', 'turma', 'curriculo_atual']

