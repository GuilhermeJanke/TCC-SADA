from sada.serializers.pessoa import PessoaSerializer
from sada.models.aluno import Aluno


#
# Aluno
#
class AlunoSerializer(PessoaSerializer):
    """
    Classe serializadora para Aluno
    """
    class Meta:
        model = Aluno
        fields = [
                     'grr',
                     'ch_integralizada',
                     'periodo_atual',
                     'potencial_retencao',
                     'potencial_evasao',
                     'potencial_jubilamento',
                     'ira',
                     'total_disciplinas_aprovadas',
                     'total_disciplinas_repovada_freq',
                     'total_disciplinas_repovada_nota',
                     'total_disciplinas_canceladas',
                     'curriculo_aluno'
                 ] + PessoaSerializer.Meta.fields

