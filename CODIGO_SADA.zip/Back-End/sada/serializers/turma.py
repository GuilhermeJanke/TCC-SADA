from rest_framework import serializers

from sada.models.turma import Turma


#
# Turma
#
class TurmaSerializer(serializers.ModelSerializer):
    """
    Classe serializadora para Turma
    """
    class Meta:
        model = Turma
        fields = ['id', 'nome', 'departamento', 'ano', 'periodo', 'disciplina', 'turno', 'professor', 'curso']

