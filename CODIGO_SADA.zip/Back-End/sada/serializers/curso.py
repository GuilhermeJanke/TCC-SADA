from rest_framework import serializers
from sada.models.curso import Curso

#
# Curso
#
class CursoSerializer(serializers.ModelSerializer):
    """
    Classe serializadora para Curso
    """
    class Meta:
        model = Curso
        fields = ['id', 'codigo', 'nome', 'sigla', 'ch_semestre', 'ch_max_semeste', 'ch_total', 'ch_max', 'qtd_semestres', 'qtd_max_semestres', 'ch_disciplinas_obrigatorias', 'ch_disciplinas_optativas']

