from rest_framework import serializers

from sada.models.atendimento_coa import AtendimentoCOA
from sada.serializers.aluno import AlunoSerializer
from sada.serializers.professor import ProfessorSerializer


#
# AtendimentoCOA
#
class AtendimentoCOASerializer(serializers.ModelSerializer):
    """
    Classe serializadora para AtendimentoCOA
    """
    professor = ProfessorSerializer(many=True, read_only=True)
    class Meta:
        model = AtendimentoCOA
        fields = [
            'id',
            'descricao',
            'data_atendimento',
            'aluno',
            'professor',
            'situacao',
            'anexo']