from django.contrib import admin
from django.urls import path, include

from rest_framework_simplejwt.views import TokenRefreshView
from rest_framework import routers
from django.conf import settings
from django.conf.urls.static import static

from sada.views.aluno import AlunoViewSet
from sada.views.atendimento_coa import AtendimentoCOAViewSet
from sada.views.curso import CursoViewSet
from sada.views.disciplina import DisciplinaViewSet
from sada.views.email_service import enviar_email_nova_senha
from sada.views.historico import HistoricoEscolarViewSet
from sada.views.matriz import MatrizCurricularViewSet
from sada.views.modalidade import ModalidadeViewSet
from sada.views.pessoa import PessoaViewSet
from sada.views.professor import ProfessorViewSet
from sada.views.turma import TurmaViewSet
from sada.views.usuario import CustomTokenObtainPairView, UsuarioViewSet


router = routers.DefaultRouter()
router.register(r'aluno', AlunoViewSet)
router.register(r'atendimento', AtendimentoCOAViewSet)
router.register(r'curso', CursoViewSet)
router.register(r'disciplina', DisciplinaViewSet)
router.register(r'historico', HistoricoEscolarViewSet)
router.register(r'matriz', MatrizCurricularViewSet)
router.register(r'modalidade', ModalidadeViewSet)
router.register(r'professor', ProfessorViewSet)
router.register(r'turma', TurmaViewSet)
router.register(r'user', UsuarioViewSet)

urlpatterns = [
    path('admin', admin.site.urls),
    path('', include(router.urls)),
    path('token', CustomTokenObtainPairView.as_view()),
    path('token/refresh', TokenRefreshView.as_view()),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
