# Back-End

## Passos para executar o projeto:

* Clonar o repositório;

* Ter instalado java e python versão 3.10.6 (Verificar com: java --version e python --version);

* Ter o pip instalado: pip install --upgrade pip  (Verificar com: pip --version);

* Ter mysql rodando, com uma database de mesmo nome e configuração do arquivo settings.py;

* Criar virtual env no computador para o projeto: 
    * Rodar os 2 comandos a seguir no CMD como ADM: 
        - pip install virtualenv virtualenvwrapper-win
        - mkvirtualenv nome_projeto  

* Abrir o projeto no VSCode ou Pycharm;

* No terminal da IDE do projeto, instalar as dependências do projeto com:
    - pip install -r requirements.txt

* Rodar os comandos: 
    - python manage.py makemigrations
    - python manage.py migrate
   
* Executar o projeto e rodar o servidor:
    - python manage.py runserver

* Testar no postman as requisições.